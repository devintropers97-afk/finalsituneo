<?php
function formatDateIndonesian($date){return date("d F Y",strtotime($date));}