<?php
function slugify($text){return strtolower(str_replace(" ","-",$text));}