<?php
function currentUrl(){return "https://".$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"];}