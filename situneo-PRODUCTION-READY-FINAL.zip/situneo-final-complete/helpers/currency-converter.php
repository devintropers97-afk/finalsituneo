<?php
function convertCurrency($amount,$from,$to){return $amount;}