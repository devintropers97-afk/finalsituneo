<?php
function arrayGet($array,$key,$default=null){return $array[$key]??$default;}