<?php
require_once __DIR__ . '/../../includes/init.php';
requireLogin();

$user = getCurrentUser();
$wishlist = $db->fetchAll("SELECT s.*, w.created_at as added_at FROM wishlist w 
    LEFT JOIN services s ON w.service_id = s.id 
    WHERE w.user_id = {$user['id']} 
    ORDER BY w.created_at DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Wishlist - SITUNEO DIGITAL</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background: #0F3057; color: white; font-family: 'Inter', sans-serif; }
        .wishlist-card { background: rgba(15, 48, 87, 0.6); border-radius: 15px; padding: 20px; margin-bottom: 20px; border: 1px solid rgba(255, 255, 255, 0.1); }
    </style>
</head>
<body>
    <?php include __DIR__ . '/../../components/navigation/top-nav.php'; ?>
    
    <div class="container mt-4">
        <h1 class="mb-4"><i class="bi bi-heart-fill text-danger"></i> My Wishlist</h1>
        
        <?php if (empty($wishlist)): ?>
            <div class="alert alert-info">
                <i class="bi bi-info-circle"></i> Your wishlist is empty. 
                <a href="../services/browse.php" class="alert-link">Browse services</a> to add to wishlist!
            </div>
        <?php else: ?>
            <div class="row">
                <?php foreach ($wishlist as $item): ?>
                <div class="col-md-4 mb-3">
                    <div class="wishlist-card">
                        <h5><?= htmlspecialchars($item['name']) ?></h5>
                        <p class="text-muted"><?= htmlspecialchars(substr($item['description'], 0, 100)) ?>...</p>
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="text-warning fw-bold"><?= formatRupiah($item['price_setup']) ?></span>
                            <div>
                                <a href="../services/detail.php?id=<?= $item['id'] ?>" class="btn btn-sm btn-info">
                                    <i class="bi bi-eye"></i> View
                                </a>
                                <a href="../cart/add.php?service=<?= $item['id'] ?>" class="btn btn-sm btn-warning">
                                    <i class="bi bi-cart-plus"></i> Add to Cart
                                </a>
                                <a href="remove.php?service=<?= $item['id'] ?>" class="btn btn-sm btn-danger">
                                    <i class="bi bi-trash"></i>
                                </a>
                            </div>
                        </div>
                        <small class="text-muted d-block mt-2">
                            <i class="bi bi-clock"></i> Added <?= formatDate($item['added_at']) ?>
                        </small>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>