<?php
require_once __DIR__ . "/../../includes/init.php";
requireLogin();
?>
<h1>My Invoices</h1>
<p>No invoices yet</p>