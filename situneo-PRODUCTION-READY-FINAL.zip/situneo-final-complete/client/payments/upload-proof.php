<?php
require_once __DIR__ . '/../../includes/init.php';
requireLogin();

$user = getCurrentUser();
$order_id = (int)$_GET['id'];

// Verify ownership
$order = $db->fetchOne("SELECT * FROM orders WHERE id = $order_id AND user_id = {$user['id']}");

if (!$order) {
    setFlash('error', 'Order not found!');
    redirect('../orders/list.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['payment_proof'])) {
    $file = $_FILES['payment_proof'];
    
    // Validate file
    $allowed = ['image/jpeg', 'image/jpg', 'image/png', 'application/pdf'];
    if (!in_array($file['type'], $allowed)) {
        setFlash('error', 'Invalid file type! Only JPG, PNG, or PDF allowed.');
    } else if ($file['size'] > 5 * 1024 * 1024) { // 5MB max
        setFlash('error', 'File too large! Maximum 5MB.');
    } else {
        // Upload file
        $upload_dir = __DIR__ . '/../../uploads/payments/';
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }
        
        $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = 'payment_' . $order_id . '_' . time() . '.' . $ext;
        $filepath = $upload_dir . $filename;
        
        if (move_uploaded_file($file['tmp_name'], $filepath)) {
            // Update payment record
            $transaction_id = 'MANUAL-' . strtoupper(substr(md5($order_id . time()), 0, 8));
            
            $db->insert('payments', [
                'order_id' => $order_id,
                'payment_method' => 'bank_transfer',
                'payment_gateway' => 'manual',
                'transaction_id' => $transaction_id,
                'amount' => $order['final_amount'],
                'status' => 'pending',
                'proof_image' => $filename
            ]);
            
            // Update order status
            $db->update('orders', [
                'payment_status' => 'pending',
                'status' => 'pending'
            ], "id = $order_id");
            
            // Create notification for admin
            $db->insert('notifications', [
                'user_id' => 1, // Admin
                'title' => 'New Payment Proof Uploaded',
                'message' => "Payment proof for order #{$order['order_number']} has been uploaded. Please verify.",
                'type' => 'payment',
                'link' => '/admin/payments/verify.php?id=' . $db->lastInsertId()
            ]);
            
            setFlash('success', 'Payment proof uploaded successfully! Waiting for admin verification.');
            redirect('../orders/detail.php?id=' . $order_id);
        } else {
            setFlash('error', 'Failed to upload file!');
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Payment Proof - SITUNEO</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background: #0F3057; color: white; font-family: 'Inter', sans-serif; }
        .payment-card { background: rgba(15, 48, 87, 0.6); border-radius: 15px; padding: 30px; border: 1px solid rgba(255, 255, 255, 0.1); }
        .bank-info { background: rgba(255, 180, 0, 0.1); border-radius: 10px; padding: 20px; margin-bottom: 20px; }
        .upload-area { border: 2px dashed rgba(255, 255, 255, 0.3); border-radius: 10px; padding: 40px; text-align: center; cursor: pointer; }
        .upload-area:hover { border-color: #FFB400; background: rgba(255, 180, 0, 0.05); }
    </style>
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="payment-card">
                    <h2 class="mb-4"><i class="bi bi-credit-card"></i> Upload Payment Proof</h2>
                    
                    <div class="alert alert-warning">
                        <i class="bi bi-info-circle"></i> <strong>Order: <?= $order['order_number'] ?></strong><br>
                        Total Amount: <strong><?= formatRupiah($order['final_amount']) ?></strong>
                    </div>
                    
                    <div class="bank-info">
                        <h5 class="text-warning mb-3"><i class="bi bi-bank"></i> Bank Transfer Information</h5>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <strong>Bank BCA</strong><br>
                                <span class="text-muted">Account Number:</span> 1234567890<br>
                                <span class="text-muted">Account Name:</span> SITUNEO DIGITAL<br>
                            </div>
                            <div class="col-md-6 mb-3">
                                <strong>Bank Mandiri</strong><br>
                                <span class="text-muted">Account Number:</span> 0987654321<br>
                                <span class="text-muted">Account Name:</span> SITUNEO DIGITAL<br>
                            </div>
                        </div>
                        
                        <div class="alert alert-info mb-0">
                            <small><i class="bi bi-clock"></i> Please transfer exactly <strong><?= formatRupiah($order['final_amount']) ?></strong> and upload the proof below.</small>
                        </div>
                    </div>
                    
                    <form method="post" enctype="multipart/form-data" id="uploadForm">
                        <?= csrfField() ?>
                        
                        <div class="upload-area mb-4" onclick="document.getElementById('fileInput').click()">
                            <i class="bi bi-cloud-upload" style="font-size: 3rem; color: #FFB400;"></i>
                            <p class="mt-3 mb-0">Click to upload payment proof</p>
                            <small class="text-muted">JPG, PNG, or PDF (Max 5MB)</small>
                            <input type="file" id="fileInput" name="payment_proof" accept="image/jpeg,image/jpg,image/png,application/pdf" style="display: none;" required onchange="showFileName()">
                        </div>
                        
                        <div id="fileName" class="mb-3" style="display: none;">
                            <i class="bi bi-file-check text-success"></i>
                            <span id="fileNameText"></span>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Additional Notes (Optional)</label>
                            <textarea name="notes" class="form-control" rows="3" placeholder="Transfer time, bank name, account name, etc..."></textarea>
                        </div>
                        
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-warning btn-lg">
                                <i class="bi bi-upload"></i> Upload Payment Proof
                            </button>
                            <a href="../orders/list.php" class="btn btn-secondary">Cancel</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <script>
    function showFileName() {
        const input = document.getElementById('fileInput');
        const fileName = document.getElementById('fileName');
        const fileNameText = document.getElementById('fileNameText');
        
        if (input.files.length > 0) {
            fileNameText.textContent = input.files[0].name;
            fileName.style.display = 'block';
        }
    }
    </script>
</body>
</html>
