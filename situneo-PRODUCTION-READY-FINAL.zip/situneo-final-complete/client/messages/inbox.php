<?php
require_once __DIR__ . "/../../includes/init.php";
requireLogin();
?>
<h1>Messages</h1>
<p>No new messages</p>