<?php
require_once __DIR__ . "/../../includes/init.php";
requireLogin();
$ids = $_GET["ids"] ?? "";
$services = $db->fetchAll("SELECT * FROM services WHERE id IN ($ids)");
?>
<h1>Compare Services</h1>
<table class="table table-dark">
<tr><th>Feature</th><?php foreach($services as $s): ?><th><?= $s["name"] ?></th><?php endforeach; ?></tr>
<tr><td>Price</td><?php foreach($services as $s): ?><td><?= formatRupiah($s["price_setup"]) ?></td><?php endforeach; ?></tr>
</table>