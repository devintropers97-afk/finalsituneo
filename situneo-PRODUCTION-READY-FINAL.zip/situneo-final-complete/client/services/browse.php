<?php
require_once __DIR__ . "/../../includes/init.php";
requireLogin();
$services = $db->fetchAll("SELECT * FROM services WHERE status='active'");
?>
<h1>Browse Services</h1>
<?php foreach($services as $s): ?>
<div><h3><?= $s['name'] ?></h3><p><?= formatRupiah($s['price_setup']) ?></p><a href="../cart/add.php?service=<?= $s['id'] ?>">Add to Cart</a></div>
<?php endforeach; ?>