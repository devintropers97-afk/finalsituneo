<?php
require_once __DIR__ . '/../../includes/init.php';
requireLogin();

$category_id = $_GET['category'];
$services = $db->fetchAll("SELECT * FROM services WHERE category_id = $category_id AND status='active'");
?>
<!DOCTYPE html>
<html>
<head><title>Services by Category</title></head>
<body class="bg-dark text-white">
    <div class="container mt-4">
        <h1>Services</h1>
        <div class="row">
            <?php foreach ($services as $service): ?>
            <div class="col-md-4 mb-3">
                <div class="card bg-dark">
                    <div class="card-body">
                        <h5><?= $service['name'] ?></h5>
                        <p><?= formatRupiah($service['price_setup']) ?></p>
                        <a href="detail.php?id=<?= $service['id'] ?>" class="btn btn-warning btn-sm">View Details</a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</body>
</html>
