<?php
require_once __DIR__ . "/../../includes/init.php";
requireLogin();
$user = getCurrentUser();
$transactions = $db->fetchAll("SELECT p.*, o.order_number FROM payments p JOIN orders o ON p.order_id=o.id WHERE o.user_id={$user['id']} ORDER BY p.created_at DESC");
?>
<h1>Transaction History</h1>
<table class="table table-dark">
<tr><th>Order</th><th>Amount</th><th>Method</th><th>Status</th><th>Date</th></tr>
<?php foreach($transactions as $t): ?>
<tr>
<td><?= $t["order_number"] ?></td>
<td><?= formatRupiah($t["amount"]) ?></td>
<td><?= $t["payment_method"] ?></td>
<td><?= $t["status"] ?></td>
<td><?= formatDate($t["created_at"]) ?></td>
</tr>
<?php endforeach; ?>
</table>