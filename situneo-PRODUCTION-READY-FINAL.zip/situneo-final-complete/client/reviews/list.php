<?php
require_once __DIR__ . '/../../includes/init.php';
requireLogin();

$user = getCurrentUser();
$reviews = $db->fetchAll("SELECT r.*, s.name as service_name FROM reviews r 
    LEFT JOIN services s ON r.service_id = s.id 
    WHERE r.user_id = {$user['id']} 
    ORDER BY r.created_at DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>My Reviews - SITUNEO</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #0F3057; color: white; }
        .review-card { background: rgba(15, 48, 87, 0.6); border-radius: 10px; padding: 20px; margin-bottom: 15px; }
        .stars { color: #FFB400; }
    </style>
</head>
<body>
    <div class="container mt-4">
        <h1><i class="bi bi-star-fill"></i> My Reviews</h1>
        
        <?php if (empty($reviews)): ?>
            <div class="alert alert-info">
                You haven't written any reviews yet. 
                <a href="../orders/list.php">View your orders</a> to leave a review!
            </div>
        <?php else: ?>
            <?php foreach ($reviews as $review): ?>
            <div class="review-card">
                <h5><?= htmlspecialchars($review['service_name']) ?></h5>
                <div class="stars mb-2">
                    <?php for($i = 1; $i <= 5; $i++): ?>
                        <i class="bi bi-star<?= $i <= $review['rating'] ? '-fill' : '' ?>"></i>
                    <?php endfor; ?>
                </div>
                <p><?= htmlspecialchars($review['review_text']) ?></p>
                <small class="text-muted">Posted on <?= formatDate($review['created_at']) ?></small>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</body>
</html>
<h1>My Reviews</h1>