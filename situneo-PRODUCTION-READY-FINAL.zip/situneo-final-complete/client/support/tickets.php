<?php
require_once __DIR__ . '/../../includes/init.php';
requireLogin();

$user = getCurrentUser();
$tickets = $db->fetchAll("SELECT * FROM support_tickets WHERE user_id = {$user['id']} ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html>
<head><title>Support Tickets</title></head>
<body class="bg-dark text-white">
    <div class="container mt-4">
        <h1>My Support Tickets</h1>
        <a href="new-ticket.php" class="btn btn-primary mb-3">New Ticket</a>
        <table class="table table-dark">
            <thead><tr><th>Ticket #</th><th>Subject</th><th>Status</th><th>Date</th></tr></thead>
            <tbody>
                <?php foreach ($tickets as $ticket): ?>
                <tr>
                    <td>#<?= $ticket['id'] ?></td>
                    <td><?= htmlspecialchars($ticket['subject']) ?></td>
                    <td><?= $ticket['status'] ?></td>
                    <td><?= formatDate($ticket['created_at']) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
