<?php
require_once __DIR__ . "/../../includes/init.php";
requireLogin();
?>
<h1>Privacy Settings</h1>
<form method="post">
<label><input type="checkbox" name="public_profile"> Public Profile</label><br>
<label><input type="checkbox" name="show_activity"> Show Activity</label><br>
<button type="submit" class="btn btn-primary mt-3">Save</button>
</form>