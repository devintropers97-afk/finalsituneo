<?php
require_once __DIR__ . '/../../includes/init.php';
requireLogin();

unset($_SESSION['cart']);
redirect('view.php');
