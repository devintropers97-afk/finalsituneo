<?php
require_once __DIR__ . '/../../includes/init.php';
requireLogin();

$item_id = $_GET['item'];
if (isset($_SESSION['cart'])) {
    $key = array_search($item_id, $_SESSION['cart']);
    if ($key !== false) {
        unset($_SESSION['cart'][$key]);
    }
}
redirect('view.php');
