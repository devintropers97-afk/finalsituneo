<?php
require_once __DIR__ . "/../../includes/init.php";
requireLogin();
?>
<h1>Shopping Cart</h1>
<p>Your cart items will appear here</p>
<a href="checkout.php">Checkout</a>