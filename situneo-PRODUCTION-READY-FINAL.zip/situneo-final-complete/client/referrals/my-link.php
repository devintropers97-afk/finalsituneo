<?php
require_once __DIR__ . "/../../includes/init.php";
requireLogin();
$user = getCurrentUser();
$code = base64_encode($user["id"]);
$link = SITE_URL . "/register.php?ref=" . $code;
?>
<h1>My Referral Link</h1>
<p>Share and earn rewards!</p>
<input type="text" value="<?= $link ?>" class="form-control mb-3" readonly>
<button onclick="navigator.clipboard.writeText('<?= $link ?>')">Copy Link</button>