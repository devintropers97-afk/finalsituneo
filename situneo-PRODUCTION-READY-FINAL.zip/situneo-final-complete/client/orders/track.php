<?php
require_once __DIR__ . "/../../includes/init.php";
?>
<h1>Track Order</h1>
<form><input name="order_number" placeholder="Enter order number"><button>Track</button></form>