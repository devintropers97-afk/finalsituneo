<?php
require_once __DIR__ . '/../../includes/init.php';
requireLogin();

$order_id = $_GET['id'];
$order = $db->fetchOne("SELECT * FROM orders WHERE id = $order_id");
?>
<!DOCTYPE html>
<html>
<head><title>Payment</title></head>
<body class="bg-dark text-white">
    <div class="container mt-4">
        <h1>Payment</h1>
        <p>Order: <?= $order['order_number'] ?></p>
        <p>Amount: <?= formatRupiah($order['final_amount']) ?></p>
        
        <h3 class="mt-4">Select Payment Method</h3>
        <div class="row">
            <div class="col-md-6">
                <div class="card bg-secondary p-3 mb-3">
                    <h5>Bank Transfer</h5>
                    <a href="bank-transfer.php?id=<?= $order_id ?>" class="btn btn-warning">Select</a>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card bg-secondary p-3 mb-3">
                    <h5>Credit Card</h5>
                    <a href="credit-card.php?id=<?= $order_id ?>" class="btn btn-warning">Select</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
