<?php
define("REDIS_HOST","localhost");define("REDIS_PORT",6379);