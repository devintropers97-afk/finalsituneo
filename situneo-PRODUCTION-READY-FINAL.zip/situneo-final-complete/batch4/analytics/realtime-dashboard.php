<?php requireAdmin(); ?>
<h1>Real-time Dashboard</h1><div id="realtime-stats"></div>