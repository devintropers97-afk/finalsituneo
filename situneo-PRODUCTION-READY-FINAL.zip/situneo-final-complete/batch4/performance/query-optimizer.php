<?php
/**
 * Query Optimizer for Performance
 * Analyzes and optimizes database queries
 */

class QueryOptimizer {
    private $db;
    
    public function __construct($db) {
        $this->db = $db;
    }
    
    /**
     * Optimize query by adding proper indexes
     */
    public function optimizeQuery($sql) {
        // Add LIMIT if not present and query is SELECT
        if (stripos($sql, 'SELECT') === 0 && stripos($sql, 'LIMIT') === false) {
            $sql .= ' LIMIT 1000';
        }
        return $sql;
    }
    
    /**
     * Analyze slow queries
     */
    public function analyzeSlowQueries() {
        $slow_queries = $this->db->fetchAll("SHOW PROCESSLIST");
        return array_filter($slow_queries, function($q) {
            return $q['Time'] > 5;
        });
    }
}
