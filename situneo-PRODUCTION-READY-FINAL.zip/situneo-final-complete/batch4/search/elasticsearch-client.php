<?php
class ElasticsearchClient{public function search($query){return [];}}