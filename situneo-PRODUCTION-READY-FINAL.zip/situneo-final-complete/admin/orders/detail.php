<?php
require_once __DIR__ . "/../../includes/init.php";
requireAdmin();
$id = $_GET["id"];
$order = $db->fetchOne("SELECT * FROM orders WHERE id=$id");
?>
<h1>Order Detail: <?= $order['order_number'] ?></h1>
<p>Amount: <?= formatRupiah($order['final_amount']) ?></p>
<p>Status: <?= $order['status'] ?></p>