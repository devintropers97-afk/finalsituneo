<?php
require_once __DIR__ . '/../../includes/init.php';
requireAdmin();

$orders = $db->fetchAll("SELECT o.*, u.name as client_name FROM orders o LEFT JOIN users u ON o.user_id = u.id ORDER BY o.created_at DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Order Management - SITUNEO</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-dark text-white">
    <div class="container mt-4">
        <h1>Order Management</h1>
        <table class="table table-dark table-striped">
            <thead>
                <tr>
                    <th>Order #</th>
                    <th>Client</th>
                    <th>Amount</th>
                    <th>Status</th>
                    <th>Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($orders as $order): ?>
                <tr>
                    <td><?= $order['order_number'] ?></td>
                    <td><?= htmlspecialchars($order['client_name']) ?></td>
                    <td><?= formatRupiah($order['final_amount']) ?></td>
                    <td><span class="badge bg-<?= $order['status'] === 'completed' ? 'success' : 'warning' ?>"><?= $order['status'] ?></span></td>
                    <td><?= formatDate($order['created_at']) ?></td>
                    <td>
                        <a href="detail.php?id=<?= $order['id'] ?>" class="btn btn-sm btn-info">View</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
