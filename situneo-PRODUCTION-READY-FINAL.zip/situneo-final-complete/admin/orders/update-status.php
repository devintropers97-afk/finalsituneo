<?php
require_once __DIR__ . '/../../includes/init.php';
requireAdmin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $order_id = (int)$_POST['order_id'];
    $status = $_POST['status'];
    
    $db->update('orders', ['status' => $status], "id = $order_id");
    
    echo json_encode(['success' => true]);
}
