<?php
require_once __DIR__ . '/../../includes/init.php';
requireAdmin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $order_id = (int)$_POST['order_id'];
    $partner_id = (int)$_POST['partner_id'];
    
    $db->update('orders', ['partner_id' => $partner_id], "id = $order_id");
    
    setFlash('success', 'Partner assigned successfully');
    redirect('list.php');
}
