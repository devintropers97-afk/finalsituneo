<?php
require_once __DIR__ . '/../../includes/init.php';
requireAdmin();

$inquiries = $db->fetchAll("SELECT * FROM inquiries ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html>
<head><title>Inquiries</title></head>
<body class="bg-dark text-white">
    <div class="container mt-4">
        <h1>Customer Inquiries</h1>
        <table class="table table-dark">
            <thead><tr><th>Name</th><th>Email</th><th>Subject</th><th>Date</th><th>Action</th></tr></thead>
            <tbody>
                <?php foreach ($inquiries as $inq): ?>
                <tr>
                    <td><?= htmlspecialchars($inq['name']) ?></td>
                    <td><?= htmlspecialchars($inq['email']) ?></td>
                    <td><?= htmlspecialchars($inq['subject']) ?></td>
                    <td><?= formatDate($inq['created_at']) ?></td>
                    <td><a href="view.php?id=<?= $inq['id'] ?>" class="btn btn-sm btn-info">View</a></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
