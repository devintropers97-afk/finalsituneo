<?php
require_once __DIR__ . "/../../includes/init.php";
requireAdmin();
$logs = file_get_contents(__DIR__ . "/../../logs/error.log");
?>
<h1>Error Logs</h1>
<pre class="bg-dark text-white p-3" style="max-height: 600px; overflow-y: auto;"><?= htmlspecialchars($logs) ?></pre>