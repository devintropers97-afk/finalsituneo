<?php
require_once __DIR__ . "/../../includes/init.php";
requireAdmin();
?>
<h1>Access Logs</h1>
<p>System access logs will appear here</p>