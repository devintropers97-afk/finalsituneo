<?php requireAdmin(); ?>
<h1>Send Email Blast</h1><form><textarea name="message"></textarea><button>Send to All Users</button></form>