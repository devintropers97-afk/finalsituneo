<?php requireAdmin(); ?>
<h1>Marketing Campaigns</h1>