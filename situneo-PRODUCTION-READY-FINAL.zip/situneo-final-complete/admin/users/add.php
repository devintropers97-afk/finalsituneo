<?php
require_once __DIR__ . "/../../includes/init.php";
requireAdmin();
?>
<h1>Add User</h1>
<form method="post">
<input name="name" placeholder="Name" required>
<input name="email" type="email" placeholder="Email" required>
<select name="role"><option>client</option><option>partner</option></select>
<button type="submit">Add</button>
</form>