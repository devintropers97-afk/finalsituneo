<?php
require_once __DIR__ . '/../../includes/init.php';
requireAdmin();

$query = $_GET['q'] ?? '';
$users = $db->fetchAll("SELECT * FROM users WHERE name LIKE '%$query%' OR email LIKE '%$query%'");
echo json_encode($users);
