<?php
require_once __DIR__ . '/../../includes/init.php';
requireAdmin();

if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $db->delete('users', "id = $id");
    setFlash('success', 'User deleted successfully');
    redirect('list.php');
}
