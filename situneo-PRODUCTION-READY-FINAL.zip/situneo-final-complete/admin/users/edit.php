<?php
require_once __DIR__ . "/../../includes/init.php";
requireAdmin();
$id = $_GET["id"];
$user = $db->fetchOne("SELECT * FROM users WHERE id=$id");
?>
<h1>Edit User</h1>
<form method="post">
<input name="name" value="<?= $user['name'] ?>">
<input name="email" value="<?= $user['email'] ?>">
<button type="submit">Update</button>
</form>