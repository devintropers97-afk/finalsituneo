<?php
require_once __DIR__ . "/../../includes/init.php";
requireAdmin();
?>
<h1>Bulk Edit Services</h1>
<form method="post">
<label>Apply to all selected:</label>
<select name="action"><option>Activate</option><option>Deactivate</option><option>Delete</option></select>
<button type="submit">Apply</button>
</form>