<?php
require_once __DIR__ . '/../../includes/init.php';
requireAdmin();

$services = $db->fetchAll("SELECT s.*, c.name as category_name FROM services s LEFT JOIN service_categories c ON s.category_id = c.id ORDER BY s.created_at DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Service Management - SITUNEO</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-dark text-white">
    <div class="container mt-4">
        <h1>Service Management</h1>
        <a href="add.php" class="btn btn-primary mb-3">Add New Service</a>
        <table class="table table-dark table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Category</th>
                    <th>Setup Price</th>
                    <th>Monthly Price</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($services as $service): ?>
                <tr>
                    <td><?= $service['id'] ?></td>
                    <td><?= htmlspecialchars($service['name']) ?></td>
                    <td><?= htmlspecialchars($service['category_name']) ?></td>
                    <td><?= formatRupiah($service['price_setup']) ?></td>
                    <td><?= formatRupiah($service['price_monthly']) ?></td>
                    <td><?= $service['status'] ?></td>
                    <td>
                        <a href="edit.php?id=<?= $service['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
