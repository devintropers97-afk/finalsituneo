<?php
require_once __DIR__ . '/../../includes/init.php';
requireAdmin();

$categories = $db->fetchAll("SELECT * FROM service_categories ORDER BY display_order");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Service Categories - SITUNEO</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-dark text-white">
    <div class="container mt-4">
        <h1>Service Categories</h1>
        <table class="table table-dark">
            <thead>
                <tr><th>Name</th><th>Icon</th><th>Order</th><th>Actions</th></tr>
            </thead>
            <tbody>
                <?php foreach ($categories as $cat): ?>
                <tr>
                    <td><?= $cat['name'] ?></td>
                    <td><i class="bi <?= $cat['icon'] ?>"></i></td>
                    <td><?= $cat['display_order'] ?></td>
                    <td><a href="edit-category.php?id=<?= $cat['id'] ?>" class="btn btn-sm btn-warning">Edit</a></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
