<?php
require_once __DIR__ . '/../../includes/init.php';
requireAdmin();

if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $db->update('services', ['status' => 'inactive'], "id = $id");
    setFlash('success', 'Service deactivated');
    redirect('list.php');
}
