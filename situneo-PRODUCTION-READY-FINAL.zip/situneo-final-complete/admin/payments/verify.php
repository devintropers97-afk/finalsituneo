<?php
require_once __DIR__ . '/../../includes/init.php';
requireAdmin();

$payments_pending = $db->fetchAll("SELECT p.*, o.order_number, u.name as client_name 
    FROM payments p 
    LEFT JOIN orders o ON p.order_id = o.id 
    LEFT JOIN users u ON o.user_id = u.id 
    WHERE p.status = 'pending' AND p.payment_gateway = 'manual' 
    ORDER BY p.created_at DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Verify Payments - SITUNEO Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background: #0F3057; color: white; }
        .payment-card { background: rgba(15, 48, 87, 0.6); padding: 20px; border-radius: 10px; margin-bottom: 15px; }
    </style>
</head>
<body>
    <?php include __DIR__ . '/../../components/admin-sidebar.php'; ?>
    
    <div class="main-content" style="margin-left: 250px; padding: 20px;">
        <h1 class="mb-4"><i class="bi bi-check-circle"></i> Payment Verification</h1>
        
        <?php if (empty($payments_pending)): ?>
            <div class="alert alert-success">
                <i class="bi bi-check-all"></i> No pending payments to verify!
            </div>
        <?php else: ?>
            <?php foreach ($payments_pending as $payment): ?>
            <div class="payment-card">
                <div class="row">
                    <div class="col-md-8">
                        <h5>Order: <?= $payment['order_number'] ?></h5>
                        <p>
                            <strong>Client:</strong> <?= htmlspecialchars($payment['client_name']) ?><br>
                            <strong>Amount:</strong> <?= formatRupiah($payment['amount']) ?><br>
                            <strong>Transaction ID:</strong> <?= $payment['transaction_id'] ?><br>
                            <strong>Upload Date:</strong> <?= formatDate($payment['created_at']) ?>
                        </p>
                    </div>
                    <div class="col-md-4 text-end">
                        <?php if (!empty($payment['proof_image'])): ?>
                            <a href="/uploads/payments/<?= $payment['proof_image'] ?>" target="_blank" class="btn btn-info btn-sm mb-2">
                                <i class="bi bi-eye"></i> View Proof
                            </a><br>
                        <?php endif; ?>
                        
                        <button onclick="approvePayment(<?= $payment['id'] ?>)" class="btn btn-success btn-sm mb-2">
                            <i class="bi bi-check-circle"></i> Approve
                        </button><br>
                        
                        <button onclick="rejectPayment(<?= $payment['id'] ?>)" class="btn btn-danger btn-sm">
                            <i class="bi bi-x-circle"></i> Reject
                        </button>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
    
    <script>
    function approvePayment(id) {
        if (confirm('Approve this payment?')) {
            window.location.href = 'verify-action.php?action=approve&id=' + id;
        }
    }
    
    function rejectPayment(id) {
        const reason = prompt('Reason for rejection:');
        if (reason) {
            window.location.href = 'verify-action.php?action=reject&id=' + id + '&reason=' + encodeURIComponent(reason);
        }
    }
    </script>
</body>
</html>
