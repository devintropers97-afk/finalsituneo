<?php
require_once __DIR__ . '/../../includes/init.php';
requireAdmin();

$id = $_GET['id'];
$payment = $db->fetchOne("SELECT p.*, o.order_number FROM payments p LEFT JOIN orders o ON p.order_id = o.id WHERE p.id = $id");
?>
<!DOCTYPE html>
<html>
<head><title>Payment Detail</title></head>
<body>
    <h1>Payment Detail</h1>
    <p>Order: <?= $payment['order_number'] ?></p>
    <p>Amount: <?= formatRupiah($payment['amount']) ?></p>
    <p>Method: <?= $payment['payment_method'] ?></p>
    <p>Status: <?= $payment['status'] ?></p>
    <p>Transaction ID: <?= $payment['transaction_id'] ?></p>
</body>
</html>
