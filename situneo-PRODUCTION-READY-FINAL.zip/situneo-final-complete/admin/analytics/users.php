<?php requireAdmin(); $user_growth=$db->fetchAll("SELECT DATE(created_at) as date,COUNT(*) as count FROM users GROUP BY date"); ?>
<h1>User Growth</h1>