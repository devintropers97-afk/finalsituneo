<?php requireAdmin(); ?>
<h1>Revenue Analytics</h1>