<?php requireAdmin(); ?>
<h1>Analytics Overview</h1><div id="charts"></div>