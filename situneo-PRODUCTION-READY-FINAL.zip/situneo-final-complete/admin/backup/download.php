<?php
require_once __DIR__ . "/../../includes/init.php";
requireAdmin();
header("Content-Type: application/sql");
header("Content-Disposition: attachment; filename=backup-" . date("Y-m-d") . ".sql");
echo "-- Database Backup\n";