<?php
require_once __DIR__ . "/../../includes/init.php";
requireAdmin();
?>
<h1>API Keys Management</h1>
<table class="table table-dark">
<tr><th>Key</th><th>Status</th><th>Created</th></tr>
</table>
<button class="btn btn-primary">Generate New Key</button>