<?php
require_once __DIR__ . '/../../includes/init.php';
requireAdmin();
?>
<!DOCTYPE html>
<html>
<head><title>Email Settings</title></head>
<body class="bg-dark text-white">
    <div class="container mt-4">
        <h1>Email Settings</h1>
        <form method="post">
            <div class="mb-3">
                <label>SMTP Host</label>
                <input type="text" name="smtp_host" class="form-control" value="smtp.gmail.com">
            </div>
            <div class="mb-3">
                <label>SMTP Port</label>
                <input type="number" name="smtp_port" class="form-control" value="587">
            </div>
            <div class="mb-3">
                <label>SMTP Username</label>
                <input type="text" name="smtp_username" class="form-control">
            </div>
            <div class="mb-3">
                <label>SMTP Password</label>
                <input type="password" name="smtp_password" class="form-control">
            </div>
            <button type="submit" class="btn btn-primary">Save Settings</button>
        </form>
    </div>
</body>
</html>
