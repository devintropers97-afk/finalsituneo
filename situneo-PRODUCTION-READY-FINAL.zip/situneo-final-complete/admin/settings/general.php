<?php
require_once __DIR__ . "/../../includes/init.php";
requireAdmin();
?>
<h1>General Settings</h1>
<form method="post">
<input name="site_name" placeholder="Site Name">
<input name="site_email" placeholder="Site Email">
<button type="submit">Save Settings</button>
</form>