<?php
require_once __DIR__ . '/../../includes/init.php';
requireAdmin();
?>
<!DOCTYPE html>
<html>
<head><title>Payment Settings</title></head>
<body class="bg-dark text-white">
    <div class="container mt-4">
        <h1>Payment Gateway Settings</h1>
        <form method="post">
            <h3>Midtrans</h3>
            <div class="mb-3">
                <label>Server Key</label>
                <input type="text" name="midtrans_server_key" class="form-control">
            </div>
            <div class="mb-3">
                <label>Client Key</label>
                <input type="text" name="midtrans_client_key" class="form-control">
            </div>
            
            <h3 class="mt-4">Xendit</h3>
            <div class="mb-3">
                <label>API Key</label>
                <input type="text" name="xendit_api_key" class="form-control">
            </div>
            
            <button type="submit" class="btn btn-primary">Save Settings</button>
        </form>
    </div>
</body>
</html>
