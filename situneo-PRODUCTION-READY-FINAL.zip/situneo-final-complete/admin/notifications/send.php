<?php
require_once __DIR__ . "/../../includes/init.php";
requireAdmin();
?>
<h1>Send Notification</h1>
<form method="post">
<label>Recipients</label>
<select name="recipients" class="form-control mb-3">
<option>All Users</option>
<option>All Clients</option>
<option>All Partners</option>
</select>
<label>Title</label>
<input name="title" class="form-control mb-3">
<label>Message</label>
<textarea name="message" class="form-control mb-3" rows="4"></textarea>
<button type="submit" class="btn btn-primary">Send</button>
</form>