<?php
require_once __DIR__ . "/../../includes/init.php";
requireAdmin();
phpinfo();