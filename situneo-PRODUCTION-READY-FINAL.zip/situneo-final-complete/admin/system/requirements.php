<?php
require_once __DIR__ . "/../../includes/init.php";
requireAdmin();
?>
<h1>System Requirements</h1>
<ul>
<li>PHP Version: <?= phpversion() ?> ✅</li>
<li>MySQL: Connected ✅</li>
<li>GD Library: <?= extension_loaded("gd") ? "✅" : "❌" ?></li>
</ul>