<?php
require_once __DIR__ . '/../../includes/init.php';
requireAdmin();

$partner_stats = $db->fetchAll("SELECT u.name, COUNT(c.id) as total_commissions, SUM(c.commission_amount) as total_earned FROM users u LEFT JOIN commissions c ON u.id = c.partner_id WHERE u.role='partner' GROUP BY u.id");
?>
<!DOCTYPE html>
<html>
<head><title>Partner Report</title></head>
<body class="bg-dark text-white">
    <div class="container mt-4">
        <h1>Partner Performance Report</h1>
        <table class="table table-dark">
            <thead><tr><th>Partner</th><th>Total Commissions</th><th>Total Earned</th></tr></thead>
            <tbody>
                <?php foreach ($partner_stats as $stat): ?>
                <tr>
                    <td><?= $stat['name'] ?></td>
                    <td><?= $stat['total_commissions'] ?></td>
                    <td><?= formatRupiah($stat['total_earned']) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
