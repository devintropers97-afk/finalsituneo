<?php
require_once __DIR__ . "/../../includes/init.php";
requireAdmin();
$total_sales = $db->fetchOne("SELECT SUM(final_amount) as total FROM orders WHERE status='completed'")['total'];
?>
<h1>Sales Report</h1>
<h2>Total Sales: <?= formatRupiah($total_sales) ?></h2>