<?php
require_once __DIR__ . "/../../includes/init.php";
requireAdmin();
require_once "vendor/autoload.php";
$pdf = new TCPDF();
$pdf->AddPage();
$pdf->Write(0, "Sales Report");
$pdf->Output("report.pdf", "D");