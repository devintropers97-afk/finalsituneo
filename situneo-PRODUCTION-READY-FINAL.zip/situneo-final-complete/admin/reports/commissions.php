<?php
require_once __DIR__ . "/../../includes/init.php";
requireAdmin();
$total_commission = $db->fetchOne("SELECT SUM(commission_amount) as total FROM commissions WHERE status='paid'")['total'];
?>
<h1>Commission Report</h1>
<h2>Total Paid: <?= formatRupiah($total_commission) ?></h2>