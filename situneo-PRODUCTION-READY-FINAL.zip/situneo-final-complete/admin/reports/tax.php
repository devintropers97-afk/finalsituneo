<?php
require_once __DIR__ . "/../../includes/init.php";
requireAdmin();
$tax_collected = $db->fetchOne("SELECT SUM(tax_amount) as total FROM orders WHERE status='completed'")["total"];
?>
<h1>Tax Report</h1>
<p>Total Tax Collected: <?= formatRupiah($tax_collected) ?></p>