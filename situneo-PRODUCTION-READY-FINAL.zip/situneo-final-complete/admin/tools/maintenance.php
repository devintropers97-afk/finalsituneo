<?php requireAdmin(); ?>
<h1>Maintenance Mode</h1><form><label><input type="checkbox" name="enabled"> Enable Maintenance Mode</label><button>Save</button></form>