<?php requireAdmin(); ?>
<h1>Backup Tools</h1><button onclick="backupDatabase()">Backup Database Now</button>