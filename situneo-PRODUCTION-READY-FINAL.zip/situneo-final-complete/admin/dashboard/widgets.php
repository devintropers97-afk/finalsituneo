<?php
require_once __DIR__ . "/../../includes/init.php";
requireAdmin();
echo json_encode([
"today_orders" => $db->fetchOne("SELECT COUNT(*) as c FROM orders WHERE DATE(created_at)=CURDATE()")["c"],
"today_revenue" => $db->fetchOne("SELECT SUM(final_amount) as t FROM orders WHERE DATE(created_at)=CURDATE()")["t"]
]);