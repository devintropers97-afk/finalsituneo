<?php
require_once __DIR__ . "/../../includes/init.php";
requireAdmin();
$commissions = $db->fetchAll("SELECT c.*, u.name as partner_name FROM commissions c JOIN users u ON c.partner_id = u.id");
?>
<h1>Commission Management</h1>
<table><tr><th>Partner</th><th>Amount</th><th>Status</th></tr>
<?php foreach($commissions as $c): ?>
<tr><td><?= $c['partner_name'] ?></td><td><?= formatRupiah($c['commission_amount']) ?></td><td><?= $c['status'] ?></td></tr>
<?php endforeach; ?>
</table>