<?php
require_once __DIR__ . '/../../includes/init.php';
requireAdmin();

if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $db->update('commissions', ['status' => 'approved'], "id = $id");
    setFlash('success', 'Commission approved');
    redirect('list.php');
}
