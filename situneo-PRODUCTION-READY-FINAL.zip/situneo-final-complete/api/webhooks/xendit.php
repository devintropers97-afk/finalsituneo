<?php
require_once __DIR__ . "/../../includes/init.php";
$data = json_decode(file_get_contents("php://input"), true);
// Process Xendit webhook
if($data["status"] === "PAID") {
$external_id = $data["external_id"];
$db->update("orders", ["payment_status"=>"success"], "order_number='$external_id'");
}
echo "OK";