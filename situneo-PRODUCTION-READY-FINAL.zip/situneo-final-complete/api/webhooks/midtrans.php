<?php
require_once __DIR__ . "/../../includes/init.php";
$data = json_decode(file_get_contents("php://input"), true);
// Process Midtrans webhook
if($data["transaction_status"] === "settlement") {
$order_id = $data["order_id"];
$db->update("orders", ["payment_status"=>"success","status"=>"paid"], "order_number='$order_id'");
}
echo "OK";