<?php
header("Content-Type: application/json");
require_once __DIR__ . "/../../../includes/init.php";
$order_id = $_POST["order_id"];
$method = $_POST["method"];
echo json_encode(["success"=>true,"payment_url"=>"https://payment.gateway.com/pay/123"]);