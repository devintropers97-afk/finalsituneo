<?php
header("Content-Type: application/json");
require_once __DIR__ . "/../../../includes/init.php";
requireLogin();
$cart = $_SESSION["cart"] ?? [];
echo json_encode(["success"=>true,"items"=>$cart]);