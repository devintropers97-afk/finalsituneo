<?php
header("Content-Type: application/json");
require_once __DIR__ . "/../../../includes/init.php";
requireLogin();
$user = getCurrentUser();
$notifs = $db->fetchAll("SELECT * FROM notifications WHERE user_id={$user['id']} ORDER BY created_at DESC LIMIT 20");
echo json_encode(["success"=>true,"data"=>$notifs]);