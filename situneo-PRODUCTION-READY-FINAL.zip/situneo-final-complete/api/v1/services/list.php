<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../../../includes/init.php';

$services = $db->fetchAll("SELECT * FROM services WHERE status='active'");
echo json_encode(['success' => true, 'data' => $services]);
