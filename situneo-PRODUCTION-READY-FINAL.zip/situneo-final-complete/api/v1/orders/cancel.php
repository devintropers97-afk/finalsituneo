<?php
header("Content-Type: application/json");
require_once __DIR__ . "/../../../includes/init.php";
$id = $_GET["id"];
$db->update("orders", ["status"=>"cancelled"], "id=$id");
echo json_encode(["success"=>true]);