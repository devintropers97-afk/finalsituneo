<?php
header("Content-Type: application/json");
require_once __DIR__ . "/../../../includes/init.php";
$orders = $db->fetchAll("SELECT * FROM orders");
echo json_encode(["success"=>true,"data"=>$orders]);