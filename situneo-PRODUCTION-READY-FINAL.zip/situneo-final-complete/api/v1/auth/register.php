<?php
header("Content-Type: application/json");
require_once __DIR__ . "/../../../includes/init.php";
$data = json_decode(file_get_contents("php://input"), true);
if(register($data)) echo json_encode(["success"=>true]); else echo json_encode(["error"=>"Registration failed"]);