<?php
header("Content-Type: application/json");
require_once __DIR__ . "/../../../includes/init.php";
logout();
echo json_encode(["success"=>true]);