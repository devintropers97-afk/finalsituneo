<?php
header("Content-Type: application/json");
require_once __DIR__ . "/../../../includes/init.php";
echo json_encode(["total_users"=>100,"total_orders"=>500,"total_revenue"=>50000000]);