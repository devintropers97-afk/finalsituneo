<?php
header("Content-Type: application/json");
require_once __DIR__ . "/../../../includes/init.php";
$stats = [
"total_users" => $db->fetchOne("SELECT COUNT(*) as c FROM users")["c"],
"total_orders" => $db->fetchOne("SELECT COUNT(*) as c FROM orders")["c"],
"total_revenue" => $db->fetchOne("SELECT SUM(final_amount) as t FROM orders WHERE status='completed'")["t"]
];
echo json_encode(["success"=>true,"data"=>$stats]);