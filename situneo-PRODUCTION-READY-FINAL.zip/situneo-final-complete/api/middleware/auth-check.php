<?php
function checkApiAuth() {
$headers = getallheaders();
$token = $headers["Authorization"] ?? "";
if(empty($token)) {
http_response_code(401);
echo json_encode(["error"=>"Unauthorized"]);
exit;
}
return true;
}