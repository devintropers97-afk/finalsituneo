<?php
header("Content-Type: application/json");
require_once __DIR__ . "/../../../includes/init.php";
echo json_encode(["success"=>true,"message"=>"Webhook test successful"]);