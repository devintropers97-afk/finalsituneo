<?php
header("Content-Type: application/json");
require_once __DIR__ . "/../../../includes/init.php";
$query = $_GET["q"] ?? "";
$services = $db->fetchAll("SELECT * FROM services WHERE name LIKE '%$query%' OR description LIKE '%$query%' LIMIT 20");
echo json_encode(["success"=>true,"data"=>$services]);