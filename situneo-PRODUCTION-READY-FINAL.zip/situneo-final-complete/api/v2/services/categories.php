<?php
header("Content-Type: application/json");
require_once __DIR__ . "/../../../includes/init.php";
$categories = $db->fetchAll("SELECT * FROM service_categories ORDER BY display_order");
echo json_encode(["success"=>true,"data"=>$categories]);