<?php
header("Content-Type: application/json");
require_once __DIR__ . "/../../../includes/init.php";
requireLogin();
$user = getCurrentUser();
$stats = ["total"=>$db->fetchOne("SELECT COUNT(*) as c FROM orders WHERE user_id={$user['id']}")["c"]];
echo json_encode(["success"=>true,"data"=>$stats]);