<?php
header("Content-Type: application/json");
require_once __DIR__ . "/../../../includes/init.php";
$order_number = $_GET["order_number"];
$order = $db->fetchOne("SELECT * FROM orders WHERE order_number='$order_number'");
echo json_encode(["success"=>true,"order"=>$order]);