<?php
header("Content-Type: application/json");
require_once __DIR__ . "/../../../includes/init.php";
requireLogin();
$user = getCurrentUser();
$summary = ["total_earned"=>$db->fetchOne("SELECT SUM(commission_amount) as t FROM commissions WHERE partner_id={$user['id']}")["t"]];
echo json_encode(["success"=>true,"data"=>$summary]);