<?php
header("Content-Type: application/json");
require_once __DIR__ . "/../../../includes/init.php";
$token = $_POST["refresh_token"] ?? "";
$new_token = generateToken();
echo json_encode(["success"=>true,"token"=>$new_token]);