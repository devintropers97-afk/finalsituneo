<?php
ini_set("session.cookie_lifetime",7200);ini_set("session.gc_maxlifetime",7200);