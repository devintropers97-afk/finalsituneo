<?php
/**
 * ========================================
 * SITUNEO DIGITAL - Database Configuration
 * MySQLi Connection Class
 * ========================================
 */

// Database Configuration - PRODUCTION
define('DB_HOST', 'localhost');
define('DB_USER', 'nrrskfvk_user_situneo_digital');
define('DB_PASS', 'Devin1922$');
define('DB_NAME', 'nrrskfvk_situneo_digital');
define('DB_CHARSET', 'utf8mb4');

/**
 * Database Class
 * Simple MySQLi wrapper dengan prepared statements
 */
class Database {
    private $conn;
    private $host = DB_HOST;
    private $user = DB_USER;
    private $pass = DB_PASS;
    private $dbname = DB_NAME;
    
    /**
     * Constructor - Auto connect
     */
    public function __construct() {
        $this->connect();
    }
    
    /**
     * Connect to database
     */
    private function connect() {
        $this->conn = new mysqli($this->host, $this->user, $this->pass, $this->dbname);
        
        if ($this->conn->connect_error) {
            die("Connection failed: " . $this->conn->connect_error);
        }
        
        $this->conn->set_charset(DB_CHARSET);
    }
    
    /**
     * Get connection object
     */
    public function getConnection() {
        return $this->conn;
    }
    
    /**
     * Execute query
     */
    public function query($sql) {
        return $this->conn->query($sql);
    }
    
    /**
     * Prepare statement
     */
    public function prepare($sql) {
        return $this->conn->prepare($sql);
    }
    
    /**
     * Escape string
     */
    public function escape($value) {
        return $this->conn->real_escape_string($value);
    }
    
    /**
     * Get last insert ID
     */
    public function lastInsertId() {
        return $this->conn->insert_id;
    }
    
    /**
     * Affected rows
     */
    public function affectedRows() {
        return $this->conn->affected_rows;
    }
    
    /**
     * Fetch single row
     */
    public function fetchOne($sql) {
        $result = $this->query($sql);
        if ($result && $result->num_rows > 0) {
            return $result->fetch_assoc();
        }
        return null;
    }
    
    /**
     * Fetch all rows
     */
    public function fetchAll($sql) {
        $result = $this->query($sql);
        $data = [];
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $data[] = $row;
            }
        }
        return $data;
    }
    
    /**
     * Insert data
     */
    public function insert($table, $data) {
        $fields = implode(', ', array_keys($data));
        $values = "'" . implode("', '", array_map([$this, 'escape'], array_values($data))) . "'";
        $sql = "INSERT INTO $table ($fields) VALUES ($values)";
        return $this->query($sql);
    }
    
    /**
     * Update data
     */
    public function update($table, $data, $where) {
        $set = [];
        foreach ($data as $key => $value) {
            $set[] = "$key = '" . $this->escape($value) . "'";
        }
        $sql = "UPDATE $table SET " . implode(', ', $set) . " WHERE $where";
        return $this->query($sql);
    }
    
    /**
     * Delete data
     */
    public function delete($table, $where) {
        $sql = "DELETE FROM $table WHERE $where";
        return $this->query($sql);
    }
    
    /**
     * Close connection
     */
    public function close() {
        if ($this->conn) {
            $this->conn->close();
        }
    }
    
    /**
     * Destructor - Auto close
     */
    public function __destruct() {
        $this->close();
    }
}

// Create global database instance
$db = new Database();
$conn = $db->getConnection();

// Function untuk get database instance
function getDB() {
    global $db;
    return $db;
}

// Function untuk get connection
function getConnection() {
    global $conn;
    return $conn;
}
