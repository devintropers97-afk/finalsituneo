<?php
define("LOG_LEVEL","debug");define("LOG_PATH",__DIR__."/../logs/");