<?php
/**
 * ========================================
 * SITUNEO DIGITAL - Constants & Settings
 * Data Perusahaan & Konfigurasi Sistem
 * ========================================
 */

// ===========================
// INFORMASI PERUSAHAAN
// ===========================
define('COMPANY_NAME', 'SITUNEO DIGITAL');
define('COMPANY_LEGAL_NAME', 'PT SITUNEO DIGITAL INDONESIA');
define('COMPANY_NIB', '20250-9261-4570-4515-5453');
define('COMPANY_TAGLINE', 'Digital Harmony for a Modern World');
define('COMPANY_DESCRIPTION', 'Platform Digital Agency dengan sistem partnership terbaik di Indonesia');

// ===========================
// KONTAK PERUSAHAAN
// ===========================
define('COMPANY_EMAIL', 'admin@situneo.my.id');
define('COMPANY_EMAIL_SUPPORT', 'support@situneo.my.id');
define('COMPANY_PHONE', '6283173868915');
define('COMPANY_PHONE_FORMATTED', '+62 831-7386-8915');
define('COMPANY_WHATSAPP', '6283173868915');
define('COMPANY_ADDRESS', 'Jakarta, Indonesia');

// ===========================
// WEBSITE SETTINGS
// ===========================
define('SITE_URL', 'https://situneo.my.id');
define('SITE_NAME', 'SITUNEO DIGITAL');
define('SITE_LOGO', SITE_URL . '/assets/images/logo.png');
define('SITE_LOGO_URL', 'https://situneo.my.id/logo');
define('SITE_FAVICON', SITE_URL . '/assets/images/favicon.png');

// ===========================
// SOCIAL MEDIA
// ===========================
define('SOCIAL_FACEBOOK', 'https://facebook.com/situneo');
define('SOCIAL_INSTAGRAM', 'https://instagram.com/situneo');
define('SOCIAL_TWITTER', 'https://twitter.com/situneo');
define('SOCIAL_LINKEDIN', 'https://linkedin.com/company/situneo');
define('SOCIAL_YOUTUBE', 'https://youtube.com/@situneo');
define('SOCIAL_TIKTOK', 'https://tiktok.com/@situneo');

// ===========================
// WARNA BRAND
// ===========================
define('COLOR_PRIMARY_BLUE', '#1E5C99');
define('COLOR_DARK_BLUE', '#0F3057');
define('COLOR_GOLD', '#FFB400');
define('COLOR_BRIGHT_GOLD', '#FFD700');
define('COLOR_WHITE', '#ffffff');
define('COLOR_TEXT_LIGHT', '#e9ecef');

// Gradients
define('GRADIENT_PRIMARY', 'linear-gradient(135deg, #1E5C99 0%, #0F3057 100%)');
define('GRADIENT_GOLD', 'linear-gradient(135deg, #FFD700 0%, #FFB400 100%)');

// ===========================
// FONTS
// ===========================
define('FONT_PRIMARY', 'Inter, sans-serif');
define('FONT_SECONDARY', 'Plus Jakarta Sans, sans-serif');

// ===========================
// TIMEZONE & LOCALE
// ===========================
define('TIMEZONE', 'Asia/Jakarta');
define('DATE_FORMAT', 'd/m/Y');
define('TIME_FORMAT', 'H:i');
define('DATETIME_FORMAT', 'd/m/Y H:i');

// Set timezone
date_default_timezone_set(TIMEZONE);

// ===========================
// SISTEM KOMISI FREELANCE
// ===========================
// Tier berdasarkan jumlah order per bulan
define('COMMISSION_TIER_1_MIN', 0);
define('COMMISSION_TIER_1_MAX', 9);
define('COMMISSION_TIER_1_RATE', 0.30);  // 30%

define('COMMISSION_TIER_2_MIN', 10);
define('COMMISSION_TIER_2_MAX', 24);
define('COMMISSION_TIER_2_RATE', 0.40);  // 40%

define('COMMISSION_TIER_3_MIN', 25);
define('COMMISSION_TIER_3_MAX', 49);
define('COMMISSION_TIER_3_RATE', 0.50);  // 50%

define('COMMISSION_TIER_MAX_MIN', 75);
define('COMMISSION_TIER_MAX_RATE', 0.55);  // 55%

// Tier names
define('TIER_NAMES', [
    'tier_1' => 'Bronze',
    'tier_2' => 'Silver', 
    'tier_3' => 'Gold',
    'tier_max' => 'Diamond'
]);

// ===========================
// PAYMENT SETTINGS
// ===========================
define('CURRENCY', 'IDR');
define('CURRENCY_SYMBOL', 'Rp');
define('TAX_RATE', 0.11);  // PPN 11%

// Minimum withdrawal untuk partner
define('MIN_WITHDRAWAL_AMOUNT', 100000);  // Rp 100.000

// ===========================
// FILE UPLOAD SETTINGS
// ===========================
define('UPLOAD_MAX_SIZE', 10485760);  // 10MB
define('UPLOAD_PATH', __DIR__ . '/../uploads/');
define('UPLOAD_ALLOWED_TYPES', [
    'jpg', 'jpeg', 'png', 'gif', 'pdf', 
    'doc', 'docx', 'xls', 'xlsx', 'zip'
]);

// ===========================
// SECURITY SETTINGS
// ===========================
define('PASSWORD_MIN_LENGTH', 8);
define('SESSION_LIFETIME', 7200);  // 2 hours
define('SESSION_NAME', 'SITUNEO_SESSION');
define('CSRF_TOKEN_NAME', '_csrf_token');
define('HASH_ALGO', 'sha256');
define('ENCRYPTION_KEY', 'SITUNEO_2025_SECURE_KEY_CHANGE_THIS');  // GANTI!

// ===========================
// EMAIL SETTINGS (SMTP)
// ===========================
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'your-email@gmail.com');  // GANTI!
define('SMTP_PASSWORD', 'your-app-password');     // GANTI!
define('SMTP_FROM_EMAIL', 'noreply@situneo.my.id');
define('SMTP_FROM_NAME', 'SITUNEO Digital');
define('SMTP_ENCRYPTION', 'tls');

// ===========================
// PAYMENT GATEWAY - MIDTRANS
// ===========================
define('MIDTRANS_SERVER_KEY', '');     // ISI jika pakai Midtrans
define('MIDTRANS_CLIENT_KEY', '');     // ISI jika pakai Midtrans
define('MIDTRANS_IS_PRODUCTION', false);

// ===========================
// PAYMENT GATEWAY - XENDIT
// ===========================
define('XENDIT_API_KEY', '');          // ISI jika pakai Xendit
define('XENDIT_IS_PRODUCTION', false);

// ===========================
// WHATSAPP API (OPTIONAL)
// ===========================
define('WHATSAPP_API_KEY', '');
define('WHATSAPP_API_URL', '');

// ===========================
// FIREBASE (OPTIONAL)
// ===========================
define('FIREBASE_API_KEY', '');
define('FIREBASE_PROJECT_ID', '');

// ===========================
// OPENAI API (OPTIONAL)
// ===========================
define('OPENAI_API_KEY', '');
define('OPENAI_MODEL', 'gpt-3.5-turbo');

// ===========================
// PAGINATION
// ===========================
define('ITEMS_PER_PAGE', 20);
define('ITEMS_PER_PAGE_ADMIN', 50);

// ===========================
// DEVELOPMENT MODE
// ===========================
define('DEV_MODE', true);  // Ubah ke false di production!

if (DEV_MODE) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
    ini_set('log_errors', 1);
    ini_set('error_log', __DIR__ . '/../logs/error.log');
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}

// ===========================
// USER ROLES
// ===========================
define('ROLE_ADMIN', 'admin');
define('ROLE_CLIENT', 'client');
define('ROLE_PARTNER', 'partner');

// ===========================
// ORDER STATUS
// ===========================
define('ORDER_STATUS_PENDING', 'pending');
define('ORDER_STATUS_PAID', 'paid');
define('ORDER_STATUS_PROCESSING', 'processing');
define('ORDER_STATUS_COMPLETED', 'completed');
define('ORDER_STATUS_CANCELLED', 'cancelled');

// ===========================
// PAYMENT STATUS
// ===========================
define('PAYMENT_STATUS_PENDING', 'pending');
define('PAYMENT_STATUS_SUCCESS', 'success');
define('PAYMENT_STATUS_FAILED', 'failed');
define('PAYMENT_STATUS_EXPIRED', 'expired');

// ===========================
// COMMISSION STATUS
// ===========================
define('COMMISSION_STATUS_PENDING', 'pending');
define('COMMISSION_STATUS_APPROVED', 'approved');
define('COMMISSION_STATUS_PAID', 'paid');
define('COMMISSION_STATUS_REJECTED', 'rejected');

// ===========================
// HELPER FUNCTIONS
// ===========================

/**
 * Get site URL
 */
function siteUrl($path = '') {
    return SITE_URL . ($path ? '/' . ltrim($path, '/') : '');
}

/**
 * Get asset URL
 */
function assetUrl($path = '') {
    return SITE_URL . '/assets/' . ltrim($path, '/');
}

/**
 * Get upload URL
 */
function uploadUrl($path = '') {
    return SITE_URL . '/uploads/' . ltrim($path, '/');
}

/**
 * Check if in development mode
 */
function isDev() {
    return DEV_MODE;
}

/**
 * Get WhatsApp link
 */
function getWhatsAppLink($message = '') {
    $msg = $message ? '?text=' . urlencode($message) : '';
    return 'https://wa.me/' . COMPANY_WHATSAPP . $msg;
}
