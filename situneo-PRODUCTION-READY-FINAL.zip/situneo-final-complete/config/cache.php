<?php
define("CACHE_DRIVER","file");define("CACHE_PREFIX","situneo_");