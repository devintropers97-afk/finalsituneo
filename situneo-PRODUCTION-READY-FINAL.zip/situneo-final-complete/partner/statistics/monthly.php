<?php
require_once __DIR__ . "/../../includes/init.php";
requireLogin();
$user = getCurrentUser();
$monthly = $db->fetchAll("SELECT DATE_FORMAT(created_at, '%Y-%m') as month, COUNT(*) as orders, SUM(final_amount) as revenue FROM orders WHERE partner_id={$user['id']} GROUP BY month ORDER BY month DESC");
?>
<h1>Monthly Statistics</h1>
<table class="table table-dark">
<tr><th>Month</th><th>Orders</th><th>Revenue</th></tr>
<?php foreach($monthly as $m): ?>
<tr><td><?= $m['month'] ?></td><td><?= $m['orders'] ?></td><td><?= formatRupiah($m['revenue']) ?></td></tr>
<?php endforeach; ?>
</table>