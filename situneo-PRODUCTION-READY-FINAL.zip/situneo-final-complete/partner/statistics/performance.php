<?php
require_once __DIR__ . "/../../includes/init.php";
requireLogin();
?>
<h1>Performance Statistics</h1>