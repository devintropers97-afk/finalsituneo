<?php requireLogin(); ?>
<h1>Reward Points</h1><p>Earn points for every sale and redeem rewards!</p>