<?php
require_once __DIR__ . "/../../includes/init.php";
requireLogin();
$user = getCurrentUser();
?>
<h1>Link Generator</h1>
<form>
<label>Service</label>
<select name="service_id" class="form-control mb-3">
<option>Select Service</option>
</select>
<button type="button" onclick="generateLink()">Generate Link</button>
</form>