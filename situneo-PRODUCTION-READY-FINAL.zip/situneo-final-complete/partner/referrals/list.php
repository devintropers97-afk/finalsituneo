<?php
require_once __DIR__ . "/../../includes/init.php";
requireLogin();
$user = getCurrentUser();
$referrals = $db->fetchAll("SELECT * FROM orders WHERE partner_id={$user['id']}");
?>
<h1>My Referrals</h1>
<?php foreach($referrals as $r): ?>
<div><p>Order: <?= $r['order_number'] ?></p></div>
<?php endforeach; ?>