<?php
require_once __DIR__ . "/../../includes/init.php";
requireLogin();
$user = getCurrentUser();
$referral_code = base64_encode($user['id']);
$referral_link = SITE_URL . "/register.php?ref=" . $referral_code;
?>
<h1>Share Your Referral Link</h1>
<p>Link: <?= $referral_link ?></p>
<button onclick="navigator.clipboard.writeText('<?= $referral_link ?>')">Copy Link</button>