<?php
require_once __DIR__ . "/../../includes/init.php";
requireLogin();
$user = getCurrentUser();
$stats = $db->fetchOne("SELECT COUNT(*) as total, SUM(final_amount) as revenue FROM orders WHERE partner_id={$user['id']}");
echo json_encode($stats);