<?php
require_once __DIR__ . "/../../includes/init.php";
requireLogin();
$user = getCurrentUser();
?>
<h1>Partner Settings</h1>
<form method="post">
<label>Bank Name</label>
<input name="bank_name" class="form-control">
<label>Account Number</label>
<input name="account_number" class="form-control">
<label>Account Name</label>
<input name="account_name" class="form-control">
<button type="submit" class="btn btn-primary mt-3">Save</button>
</form>