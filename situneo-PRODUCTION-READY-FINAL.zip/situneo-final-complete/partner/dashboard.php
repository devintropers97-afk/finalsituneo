<?php
require_once __DIR__ . '/../includes/init.php';
requireLogin();

$user = getCurrentUser();
if ($user['role'] !== 'partner') redirect('/login.php');

$total_commission = $db->fetchOne("SELECT SUM(commission_amount) as total FROM commissions WHERE partner_id = {$user['id']} AND status='approved'")['total'] ?? 0;
$pending_commission = $db->fetchOne("SELECT SUM(commission_amount) as total FROM commissions WHERE partner_id = {$user['id']} AND status='pending'")['total'] ?? 0;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Partner Dashboard - SITUNEO</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #0F3057; color: white; }
        .stats-card { background: rgba(255, 180, 0, 0.1); border-radius: 15px; padding: 20px; margin-bottom: 20px; }
    </style>
</head>
<body>
    <div class="container mt-4">
        <h1>Partner Dashboard</h1>
        <div class="row mt-4">
            <div class="col-md-6">
                <div class="stats-card">
                    <h3><?= formatRupiah($total_commission) ?></h3>
                    <p>Total Commission Earned</p>
                </div>
            </div>
            <div class="col-md-6">
                <div class="stats-card">
                    <h3><?= formatRupiah($pending_commission) ?></h3>
                    <p>Pending Commission</p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
