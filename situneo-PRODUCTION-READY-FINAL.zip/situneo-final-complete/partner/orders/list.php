<?php
require_once __DIR__ . "/../../includes/init.php";
requireLogin();
?>
<h1>Orders from My Referrals</h1>