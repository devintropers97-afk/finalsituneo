<?php
require_once __DIR__ . "/../../includes/init.php";
requireLogin();
$id = $_GET["id"];
$order = $db->fetchOne("SELECT * FROM orders WHERE id=$id");
?>
<h1>Order Detail</h1>
<p>Order: <?= $order['order_number'] ?></p>
<p>Amount: <?= formatRupiah($order['final_amount']) ?></p>
<p>Your Commission: <?= formatRupiah($order['final_amount'] * 0.3) ?></p>