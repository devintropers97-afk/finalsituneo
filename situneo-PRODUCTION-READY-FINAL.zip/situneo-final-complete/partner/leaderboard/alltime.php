<?php requireLogin(); ?>
<h1>All-Time Leaderboard</h1>