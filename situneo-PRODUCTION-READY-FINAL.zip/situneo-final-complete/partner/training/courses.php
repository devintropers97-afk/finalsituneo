<?php requireLogin(); ?>
<h1>Training Courses</h1><p>Learn how to maximize your earnings</p>