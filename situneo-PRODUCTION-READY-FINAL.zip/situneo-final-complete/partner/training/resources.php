<?php requireLogin(); ?>
<h1>Resources</h1><ul><li>Sales Scripts</li><li>FAQ Answers</li><li>Best Practices</li></ul>