<?php
require_once __DIR__ . "/../../includes/init.php";
requireLogin();
?>
<h1>Achievements & Badges</h1>
<div class="row">
<div class="col-md-3"><div class="badge-card">🥉 Bronze Partner<br>10+ Orders</div></div>
<div class="col-md-3"><div class="badge-card">🥈 Silver Partner<br>25+ Orders</div></div>
<div class="col-md-3"><div class="badge-card">🥇 Gold Partner<br>50+ Orders</div></div>
</div>