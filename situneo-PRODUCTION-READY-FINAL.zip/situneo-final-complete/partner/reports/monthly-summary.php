<?php
require_once __DIR__ . "/../../includes/init.php";
requireLogin();
$user = getCurrentUser();
$month = $_GET["month"] ?? date("Y-m");
$stats = $db->fetchOne("SELECT COUNT(*) as orders, SUM(final_amount) as revenue FROM orders WHERE partner_id={$user['id']} AND DATE_FORMAT(created_at, '%Y-%m')='$month'");
?>
<h1>Monthly Summary: <?= $month ?></h1>
<p>Orders: <?= $stats["orders"] ?></p>
<p>Revenue Generated: <?= formatRupiah($stats["revenue"]) ?></p>