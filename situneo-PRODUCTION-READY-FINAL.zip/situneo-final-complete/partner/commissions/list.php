<?php
require_once __DIR__ . "/../../includes/init.php";
requireLogin();
$user = getCurrentUser();
$commissions = $db->fetchAll("SELECT * FROM commissions WHERE partner_id={$user['id']}");
?>
<h1>My Commissions</h1>
<?php foreach($commissions as $c): ?>
<div><p>Amount: <?= formatRupiah($c['commission_amount']) ?></p><p>Status: <?= $c['status'] ?></p></div>
<?php endforeach; ?>