<?php
require_once __DIR__ . "/../../includes/init.php";
requireLogin();
?>
<h1>Request Withdrawal</h1>
<form method="post">
<input name="amount" type="number" placeholder="Amount">
<input name="bank_name" placeholder="Bank Name">
<input name="account_number" placeholder="Account Number">
<button type="submit">Request</button>
</form>