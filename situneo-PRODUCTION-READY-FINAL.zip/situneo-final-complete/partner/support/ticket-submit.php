<?php
require_once __DIR__ . "/../../includes/init.php";
requireLogin();
?>
<h1>Submit Support Ticket</h1>
<form method="post">
<input name="subject" placeholder="Subject" class="form-control mb-3">
<textarea name="message" placeholder="Describe your issue" class="form-control mb-3" rows="5"></textarea>
<button type="submit" class="btn btn-primary">Submit</button>
</form>