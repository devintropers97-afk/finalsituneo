<?php
require_once __DIR__ . "/../../includes/init.php";
requireLogin();
?>
<h1>Contact Support</h1>
<p>WhatsApp: <?= COMPANY_PHONE_FORMATTED ?></p>
<p>Email: <?= COMPANY_EMAIL_SUPPORT ?></p>
<a href="<?= getWhatsAppLink('Hi, I need help as a partner') ?>" class="btn btn-success">Chat WhatsApp</a>