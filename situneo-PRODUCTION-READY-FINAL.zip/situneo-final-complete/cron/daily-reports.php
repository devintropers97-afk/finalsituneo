<?php
require_once __DIR__ . "/../includes/init.php";
echo "Generating daily reports...";
// Generate and email daily reports