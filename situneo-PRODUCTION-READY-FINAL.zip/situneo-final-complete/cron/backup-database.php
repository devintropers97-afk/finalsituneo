<?php
require_once __DIR__ . "/../includes/init.php";
echo "Backing up database...";
// Backup database