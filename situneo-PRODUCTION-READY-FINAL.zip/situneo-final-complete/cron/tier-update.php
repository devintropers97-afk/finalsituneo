<?php
require_once __DIR__ . "/../includes/init.php";
echo "Updating partner tiers...";
// Update partner tiers based on monthly performance