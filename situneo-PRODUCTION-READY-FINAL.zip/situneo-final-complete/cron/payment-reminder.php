<?php
require_once __DIR__ . "/../includes/init.php";
echo "Sending payment reminders...";
// Send reminders for pending payments