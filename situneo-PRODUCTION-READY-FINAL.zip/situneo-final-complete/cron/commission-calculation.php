<?php
require_once __DIR__ . "/../includes/init.php";
echo "Calculating commissions...";
// Calculate pending commissions