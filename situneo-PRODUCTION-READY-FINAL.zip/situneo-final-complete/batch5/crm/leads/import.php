<?php requireAdmin(); ?>
<h1>Import Leads</h1><form enctype="multipart/form-data"><input type="file" name="csv" accept=".csv"><button>Import</button></form>