<?php requireAdmin(); ?>
<h1>Pipeline Stages</h1><ul><li>New Lead</li><li>Contacted</li><li>Proposal Sent</li><li>Closed Won</li></ul>