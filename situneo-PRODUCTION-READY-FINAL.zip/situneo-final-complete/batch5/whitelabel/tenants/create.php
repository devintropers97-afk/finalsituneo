<?php requireAdmin(); ?>
<h1>Create New Tenant</h1><form><input name="company_name"><input name="subdomain"><button>Create</button></form>