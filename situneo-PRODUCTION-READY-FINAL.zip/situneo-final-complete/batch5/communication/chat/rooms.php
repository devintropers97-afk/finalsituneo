<?php
require_once __DIR__ . '/../../../includes/init.php';
requireLogin();

$user = getCurrentUser();

// Get chat rooms for current user
$rooms = $db->fetchAll("SELECT cr.*, 
    (SELECT COUNT(*) FROM chat_messages WHERE room_id = cr.id AND is_read = 0 AND sender_id != {$user['id']}) as unread_count
    FROM chat_rooms cr 
    WHERE cr.user_id = {$user['id']} OR cr.partner_id = {$user['id']} 
    ORDER BY cr.updated_at DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Chat Rooms - SITUNEO</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #0F3057; color: white; }
        .room-card { background: rgba(15, 48, 87, 0.6); padding: 15px; margin-bottom: 10px; border-radius: 10px; cursor: pointer; }
        .room-card:hover { background: rgba(30, 92, 153, 0.6); }
        .unread-badge { background: #FFB400; color: #0F3057; padding: 3px 8px; border-radius: 10px; font-size: 12px; font-weight: bold; }
    </style>
</head>
<body>
    <div class="container mt-4">
        <h1><i class="bi bi-chat-dots"></i> Chat Rooms</h1>
        
        <?php if (empty($rooms)): ?>
            <div class="alert alert-info">No chat rooms yet. Start a conversation!</div>
        <?php else: ?>
            <?php foreach ($rooms as $room): ?>
            <div class="room-card" onclick="location.href='room.php?id=<?= $room['id'] ?>'">
                <div class="d-flex justify-content-between">
                    <div>
                        <h5><?= htmlspecialchars($room['title']) ?></h5>
                        <small class="text-muted">Last message: <?= formatDate($room['updated_at']) ?></small>
                    </div>
                    <?php if ($room['unread_count'] > 0): ?>
                        <span class="unread-badge"><?= $room['unread_count'] ?></span>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</body>
</html>
