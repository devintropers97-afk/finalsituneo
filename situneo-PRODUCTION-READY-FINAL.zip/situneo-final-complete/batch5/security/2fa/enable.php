<?php requireLogin(); ?>
<h1>Enable Two-Factor Authentication</h1><img src="qr-code.php" alt="QR Code">