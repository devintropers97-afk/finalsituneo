<div class="card bg-gradient-primary text-white">
<div class="card-body">
<h6 class="text-uppercase mb-2">Total Revenue</h6>
<h2><?= formatRupiah($total_revenue) ?></h2>
<p class="mb-0"><span class="badge bg-success">+<?= $growth ?>%</span> from last month</p>
</div>
</div>