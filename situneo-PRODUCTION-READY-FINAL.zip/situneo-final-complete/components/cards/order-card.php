<div class="card bg-dark text-white mb-3">
<div class="card-body">
<h5><?= $order["order_number"] ?></h5>
<p><?= formatRupiah($order["final_amount"]) ?></p>
<span class="badge bg-<?= $order["status"] === "completed" ? "success" : "warning" ?>"><?= $order["status"] ?></span>
</div>
</div>