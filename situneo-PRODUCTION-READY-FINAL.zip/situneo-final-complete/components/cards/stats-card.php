<div class="stats-card">
<div class="stats-icon"><?= $icon ?></div>
<div class="stats-value"><?= $value ?></div>
<div class="stats-label"><?= $label ?></div>
</div>