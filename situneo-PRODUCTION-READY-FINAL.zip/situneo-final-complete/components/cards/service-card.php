<div class="card bg-dark text-white">
<div class="card-body">
<h5 class="card-title"><?= $service["name"] ?></h5>
<p class="card-text"><?= $service["description"] ?></p>
<p class="text-warning"><?= formatRupiah($service["price_setup"]) ?></p>
<a href="#" class="btn btn-warning">Order Now</a>
</div>
</div>