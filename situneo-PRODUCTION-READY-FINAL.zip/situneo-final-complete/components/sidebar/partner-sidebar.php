<div class="sidebar">
<h4 class="text-white mb-4">Partner Menu</h4>
<a href="/partner/dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
<a href="/partner/referrals/list.php"><i class="bi bi-people"></i> My Referrals</a>
<a href="/partner/commissions/list.php"><i class="bi bi-cash"></i> Commissions</a>
<a href="/partner/statistics/performance.php"><i class="bi bi-graph-up"></i> Statistics</a>
<a href="/partner/marketing/materials.php"><i class="bi bi-megaphone"></i> Marketing</a>
<a href="/logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a>
</div>