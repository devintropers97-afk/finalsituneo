<table class="table table-dark table-striped">
<thead><?= $thead ?></thead>
<tbody><?= $tbody ?></tbody>
</table>