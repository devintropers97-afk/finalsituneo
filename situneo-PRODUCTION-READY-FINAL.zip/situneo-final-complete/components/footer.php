<footer class="mt-5 py-4 text-center">
<p>&copy; 2025 SITUNEO DIGITAL. All rights reserved.</p>
</footer>
</body>
</html>