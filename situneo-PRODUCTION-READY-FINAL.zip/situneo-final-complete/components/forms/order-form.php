<form method="post">
<div class="mb-3"><label>Select Service</label><select name="service_id" class="form-control" required><?php foreach($services as $svc): ?><option value="<?= $svc["id"] ?>"><?= $svc["name"] ?> - <?= formatRupiah($svc["price_setup"]) ?></option><?php endforeach; ?></select></div>
<div class="mb-3"><label>Notes</label><textarea name="notes" class="form-control" rows="3" placeholder="Any special requirements?"></textarea></div>
<button type="submit" class="btn btn-warning">Place Order</button>
</form>