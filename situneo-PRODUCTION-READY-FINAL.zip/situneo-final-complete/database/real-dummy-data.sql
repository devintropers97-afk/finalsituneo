-- ========================================
-- SITUNEO DIGITAL - REAL DUMMY DATA
-- Data testing yang realistis untuk production
-- ========================================

-- Tambahan tables yang dibutuhkan
CREATE TABLE IF NOT EXISTS `wishlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `service_id` (`service_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `reviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `rating` int(1) NOT NULL,
  `review_text` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `service_id` (`service_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `chat_rooms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `partner_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `chat_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room_id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `room_id` (`room_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ========================================
-- DEMO USERS
-- ========================================

-- Admin (sudah ada di schema.sql)
-- Email: admin@situneo.my.id
-- Password: admin123

-- Demo Clients
INSERT INTO `users` (`name`, `email`, `password`, `phone`, `role`, `status`, `email_verified_at`) VALUES
('Budi Santoso', 'budi@demo.com', '$2y$12$LQv3c1yycLBLmRtH3Nb6UedGI9V6wIJVyRp3IXZp3H4T.zO9y1xBK', '081234567890', 'client', 'active', NOW()),
('Siti Nurhaliza', 'siti@demo.com', '$2y$12$LQv3c1yycLBLmRtH3Nb6UedGI9V6wIJVyRp3IXZp3H4T.zO9y1xBK', '081234567891', 'client', 'active', NOW()),
('Ahmad Rizki', 'ahmad@demo.com', '$2y$12$LQv3c1yycLBLmRtH3Nb6UedGI9V6wIJVyRp3IXZp3H4T.zO9y1xBK', '081234567892', 'client', 'active', NOW()),
('Dewi Lestari', 'dewi@demo.com', '$2y$12$LQv3c1yycLBLmRtH3Nb6UedGI9V6wIJVyRp3IXZp3H4T.zO9y1xBK', '081234567893', 'client', 'active', NOW()),
('Rudi Hermawan', 'rudi@demo.com', '$2y$12$LQv3c1yycLBLmRtH3Nb6UedGI9V6wIJVyRp3IXZp3H4T.zO9y1xBK', '081234567894', 'client', 'active', NOW());
-- Password semua: demo123

-- Demo Partners
INSERT INTO `users` (`name`, `email`, `password`, `phone`, `role`, `status`, `email_verified_at`) VALUES
('Partner Sukses', 'partner1@demo.com', '$2y$12$LQv3c1yycLBLmRtH3Nb6UedGI9V6wIJVyRp3IXZp3H4T.zO9y1xBK', '081234567895', 'partner', 'active', NOW()),
('Partner Pro', 'partner2@demo.com', '$2y$12$LQv3c1yycLBLmRtH3Nb6UedGI9V6wIJVyRp3IXZp3H4T.zO9y1xBK', '081234567896', 'partner', 'active', NOW()),
('Partner Elite', 'partner3@demo.com', '$2y$12$LQv3c1yycLBLmRtH3Nb6UedGI9V6wIJVyRp3IXZp3H4T.zO9y1xBK', '081234567897', 'partner', 'active', NOW());
-- Password semua: demo123

-- ========================================
-- DEMO SERVICES (Top 20 Populer)
-- ========================================

INSERT INTO `services` (`name`, `slug`, `category_id`, `description`, `features`, `price_setup`, `price_monthly`, `status`, `popular`) VALUES
-- Website Development
('Website Company Profile Professional', 'website-company-profile-pro', 1, 'Website company profile dengan desain modern dan profesional, cocok untuk perusahaan kecil hingga menengah', 'Design Modern, Responsive, SEO Friendly, Fast Loading, Free Domain .com', 3500000, 0, 'active', 1),
('Website Toko Online Premium', 'toko-online-premium', 1, 'Website toko online lengkap dengan payment gateway, manajemen produk, dan dashboard admin', 'Payment Gateway, Manajemen Produk, Dashboard Admin, Responsive, SEO Optimized', 8500000, 500000, 'active', 1),
('Landing Page Conversion Optimizer', 'landing-page-optimizer', 1, 'Landing page fokus konversi dengan A/B testing dan analytics terintegrasi', 'High Conversion Design, A/B Testing, Analytics, Form Builder, Fast Loading', 2500000, 0, 'active', 1),

-- Mobile App
('Mobile App Android & iOS', 'mobile-app-android-ios', 2, 'Aplikasi mobile native untuk Android dan iOS dengan fitur lengkap', 'Native Performance, Push Notification, Offline Mode, Cloud Sync, Admin Panel', 45000000, 2000000, 'active', 1),
('Aplikasi Katalog Produk Mobile', 'app-katalog-mobile', 2, 'Aplikasi mobile untuk katalog produk digital dengan fitur pencarian canggih', 'Search Filter, Product Gallery, Share Feature, Offline Catalog, Push Updates', 15000000, 500000, 'active', 1),

-- Digital Marketing
('Social Media Marketing 3 Bulan', 'smm-3-bulan', 3, 'Paket social media marketing untuk Instagram, Facebook, dan TikTok selama 3 bulan', 'Content Planning, Design Post, Copywriting, Scheduling, Monthly Report', 0, 3500000, 'active', 1),
('Facebook & Instagram Ads Management', 'fb-ig-ads', 3, 'Manajemen iklan Facebook dan Instagram dengan optimasi ROI maksimal', 'Ad Creation, Audience Targeting, Daily Monitoring, A/B Testing, Weekly Report', 0, 5000000, 'active', 1),
('Google Ads Campaign Premium', 'google-ads-premium', 3, 'Kampanye Google Ads dengan targeting presisi dan optimasi berkelanjutan', 'Keyword Research, Ad Creation, Bid Management, Conversion Tracking, Reports', 2000000, 4500000, 'active', 1),

-- SEO
('SEO Optimization Paket Basic', 'seo-basic', 4, 'Optimasi SEO basic untuk website dengan 10 keyword target', 'Keyword Research, On-Page SEO, Technical SEO, Sitemap, Monthly Report', 3500000, 2000000, 'active', 1),
('SEO Optimization Paket Premium', 'seo-premium', 4, 'Paket SEO premium dengan 30 keyword target dan backlink building', 'Keyword Research, On-Page SEO, Off-Page SEO, Backlinks, Content Writing, Weekly Report', 8500000, 4500000, 'active', 1),

-- Graphic Design
('Logo Design Professional', 'logo-design-pro', 5, 'Desain logo profesional dengan konsep unik dan file lengkap', '5 Konsep Design, Unlimited Revision, File Vector, Style Guide, Social Media Kit', 1500000, 0, 'active', 1),
('Branding Package Complete', 'branding-complete', 5, 'Paket branding lengkap: logo, color palette, typography, brand guidelines', 'Logo Design, Brand Guidelines, Business Card, Letterhead, Social Media Template', 8500000, 0, 'active', 1),
('Design Feed Instagram 1 Bulan', 'design-feed-ig', 5, 'Design feed Instagram profesional untuk 1 bulan (30 post)', '30 Design Post, Konsisten Style, High Quality, Editable Template, Revision', 0, 2500000, 'active', 1),

-- AI Solutions  
('AI Chatbot untuk Website', 'ai-chatbot-website', 6, 'Chatbot berbasis AI untuk customer service otomatis 24/7', 'Natural Language Processing, Custom Training, Multi-Platform, Analytics Dashboard', 12000000, 1500000, 'active', 1),
('Sistem Rekomendasi AI', 'ai-recommendation', 6, 'Sistem rekomendasi produk menggunakan machine learning', 'ML Algorithm, Personalization, Real-time Update, Analytics, API Integration', 25000000, 3000000, 'active', 1),

-- E-Commerce
('Toko Online Shopify Setup', 'shopify-setup', 7, 'Setup dan kustomisasi toko online di platform Shopify', 'Theme Customization, Product Upload, Payment Setup, SEO Basic, Training', 5500000, 500000, 'active', 1),
('Marketplace Integration', 'marketplace-integration', 7, 'Integrasi toko Anda dengan marketplace (Tokopedia, Shopee, Lazada)', 'Multi-Platform Sync, Auto Stock Update, Order Management, Reporting', 8500000, 1500000, 'active', 1),

-- Copywriting
('Content Writing SEO 10 Artikel', 'content-writing-10', 9, '10 artikel SEO-friendly @1000 kata dengan keyword research', 'Keyword Research, SEO Writing, Original Content, Plagiarism Check, Revision', 3500000, 0, 'active', 1),
('Product Description 50 Produk', 'product-desc-50', 9, 'Deskripsi produk menarik dan persuasif untuk 50 produk', 'Persuasive Writing, SEO Optimized, Unique Content, Fast Delivery', 2500000, 0, 'active', 1),

-- Analytics
('Google Analytics Setup & Training', 'ga-setup-training', 10, 'Setup Google Analytics 4 dengan dashboard custom dan training', 'GA4 Setup, Custom Dashboard, E-commerce Tracking, Training Session, Documentation', 3500000, 0, 'active', 1);

-- ========================================
-- DEMO ORDERS
-- ========================================

INSERT INTO `orders` (`order_number`, `user_id`, `partner_id`, `total_amount`, `tax_amount`, `final_amount`, `status`, `payment_status`, `notes`, `created_at`) VALUES
('ORD-20251101-0001', 2, 7, 3500000, 385000, 3885000, 'completed', 'success', 'Order untuk website company profile', '2025-11-01 10:30:00'),
('ORD-20251101-0002', 3, 7, 8500000, 935000, 9435000, 'completed', 'success', 'Toko online untuk bisnis fashion', '2025-11-01 14:20:00'),
('ORD-20251102-0003', 4, 8, 2500000, 275000, 2775000, 'processing', 'success', 'Landing page untuk campaign', '2025-11-02 09:15:00'),
('ORD-20251102-0004', 5, 8, 15000000, 1650000, 16650000, 'processing', 'success', 'App mobile untuk katalog', '2025-11-02 11:45:00'),
('ORD-20251103-0005', 6, 9, 3500000, 385000, 3885000, 'pending', 'pending', 'SMM untuk 3 bulan', '2025-11-03 08:30:00');

-- Order Items
INSERT INTO `order_items` (`order_id`, `service_id`, `service_name`, `quantity`, `price`, `subtotal`) VALUES
(1, 1, 'Website Company Profile Professional', 1, 3500000, 3500000),
(2, 2, 'Website Toko Online Premium', 1, 8500000, 8500000),
(3, 3, 'Landing Page Conversion Optimizer', 1, 2500000, 2500000),
(4, 5, 'Aplikasi Katalog Produk Mobile', 1, 15000000, 15000000),
(5, 6, 'Social Media Marketing 3 Bulan', 1, 3500000, 3500000);

-- ========================================
-- DEMO PAYMENTS
-- ========================================

INSERT INTO `payments` (`order_id`, `payment_method`, `payment_gateway`, `transaction_id`, `amount`, `status`, `paid_at`) VALUES
(1, 'bank_transfer', 'manual', 'MANUAL-001', 3885000, 'success', '2025-11-01 10:45:00'),
(2, 'bank_transfer', 'manual', 'MANUAL-002', 9435000, 'success', '2025-11-01 14:35:00'),
(3, 'bank_transfer', 'manual', 'MANUAL-003', 2775000, 'success', '2025-11-02 09:30:00'),
(4, 'bank_transfer', 'manual', 'MANUAL-004', 16650000, 'success', '2025-11-02 12:00:00');

-- ========================================
-- DEMO COMMISSIONS
-- ========================================

INSERT INTO `commissions` (`partner_id`, `order_id`, `order_amount`, `commission_rate`, `commission_amount`, `tier`, `status`, `paid_at`) VALUES
(7, 1, 3885000, 0.3000, 1165500, 'tier_1', 'paid', '2025-11-01 15:00:00'),
(7, 2, 9435000, 0.3000, 2830500, 'tier_1', 'paid', '2025-11-01 16:00:00'),
(8, 3, 2775000, 0.3000, 832500, 'tier_1', 'approved', NULL),
(8, 4, 16650000, 0.3000, 4995000, 'tier_1', 'approved', NULL),
(9, 5, 3885000, 0.3000, 1165500, 'tier_1', 'pending', NULL);

-- ========================================
-- DEMO REVIEWS
-- ========================================

INSERT INTO `reviews` (`user_id`, `service_id`, `rating`, `review_text`) VALUES
(2, 1, 5, 'Pelayanan sangat memuaskan! Website yang dibuat sangat profesional dan sesuai harapan. Tim sangat responsif dan membantu. Highly recommended! 👍'),
(3, 2, 5, 'Toko online nya keren banget! Fitur lengkap, mudah digunakan, dan yang penting loading cepat. Customer saya jadi lebih mudah belanja. Thanks SITUNEO! 🎉'),
(4, 3, 4, 'Landing page nya bagus dan konversi meningkat. Ada beberapa minor revision tapi overall puas. Good job! ⭐'),
(2, 6, 5, 'Social media management nya top! Content selalu on point, engagement naik signifikan. Worth every penny! 💯');

-- ========================================
-- DEMO NOTIFICATIONS
-- ========================================

INSERT INTO `notifications` (`user_id`, `title`, `message`, `type`, `link`) VALUES
(2, 'Order Completed', 'Your order #ORD-20251101-0001 has been completed successfully!', 'order', '/client/orders/detail.php?id=1'),
(3, 'Order Completed', 'Your order #ORD-20251101-0002 has been completed successfully!', 'order', '/client/orders/detail.php?id=2'),
(4, 'Order in Progress', 'Your order #ORD-20251102-0003 is being processed.', 'order', '/client/orders/detail.php?id=3'),
(7, 'Commission Paid', 'Commission for order #ORD-20251101-0001 has been paid: Rp 1,165,500', 'commission', '/partner/commissions/list.php'),
(7, 'Commission Paid', 'Commission for order #ORD-20251101-0002 has been paid: Rp 2,830,500', 'commission', '/partner/commissions/list.php'),
(8, 'Commission Approved', 'Commission for order #ORD-20251102-0003 has been approved: Rp 832,500', 'commission', '/partner/commissions/list.php');

-- ========================================
-- DEMO ACTIVITIES
-- ========================================

INSERT INTO `activity_logs` (`user_id`, `action`, `details`) VALUES
(1, 'login', 'Admin login to dashboard'),
(2, 'register', 'New user registration'),
(2, 'order_created', 'Created order #ORD-20251101-0001'),
(3, 'order_created', 'Created order #ORD-20251101-0002'),
(1, 'order_approved', 'Approved order #ORD-20251101-0001'),
(7, 'commission_received', 'Received commission for order #ORD-20251101-0001');

-- ========================================
-- DEMO SUPPORT TICKETS
-- ========================================

INSERT INTO `support_tickets` (`user_id`, `subject`, `message`, `status`) VALUES
(2, 'Pertanyaan tentang fitur website', 'Halo, apakah bisa menambahkan fitur live chat di website saya?', 'open'),
(3, 'Request revisi design', 'Mohon bantuan untuk revisi warna theme toko online saya', 'in_progress'),
(4, 'Terima kasih!', 'Terima kasih atas pelayanan yang cepat dan profesional!', 'closed');

-- ========================================
-- END OF DUMMY DATA
-- ========================================
