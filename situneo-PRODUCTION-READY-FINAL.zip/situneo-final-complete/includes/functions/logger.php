<?php
function logActivity($user_id,$action,$details=""){global $db;$db->insert("activity_logs",["user_id"=>$user_id,"action"=>$action,"details"=>$details]);}