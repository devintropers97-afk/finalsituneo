<?php
function calculateCommission($amount,$tier){$rates=["tier_1"=>0.3,"tier_2"=>0.4,"tier_3"=>0.5,"tier_max"=>0.55];return $amount*$rates[$tier];}