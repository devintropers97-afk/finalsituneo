<?php
function sendEmail($to,$subject,$body){return mail($to,$subject,$body);}