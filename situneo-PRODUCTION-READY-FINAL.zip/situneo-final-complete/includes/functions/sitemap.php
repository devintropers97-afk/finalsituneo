<?php
function generateSitemap(){return "<?xml version=\"1.0\"?><urlset></urlset>";}