<?php
function uploadFile($file,$destination){return move_uploaded_file($file["tmp_name"],$destination);}