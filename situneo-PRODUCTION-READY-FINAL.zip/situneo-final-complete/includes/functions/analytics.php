<?php
function trackEvent($event_name,$data){global $db;$db->insert("analytics_events",["event_name"=>$event_name,"data"=>json_encode($data)]);}