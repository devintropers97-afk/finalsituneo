<?php
function importFromCSV($file){$data=[];if(($handle=fopen($file,"r"))!==false){while(($row=fgetcsv($handle))!==false)$data[]=$row;fclose($handle);}return $data;}