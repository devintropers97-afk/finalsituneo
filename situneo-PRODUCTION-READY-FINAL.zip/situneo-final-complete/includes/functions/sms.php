<?php
function sendSMS($phone,$message){return true;}