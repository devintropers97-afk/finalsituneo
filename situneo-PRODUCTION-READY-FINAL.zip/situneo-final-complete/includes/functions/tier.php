<?php
function getTierByOrders($order_count){if($order_count<10)return "tier_1";if($order_count<25)return "tier_2";if($order_count<50)return "tier_3";return "tier_max";}