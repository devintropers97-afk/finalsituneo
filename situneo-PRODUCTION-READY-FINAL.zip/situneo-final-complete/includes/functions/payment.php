<?php
function processMidtrans($order_id,$amount){return ["transaction_id"=>"TRX".rand(10000,99999)];}