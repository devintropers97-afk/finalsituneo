<?php
function createNotification($user_id,$title,$message){global $db;$db->insert("notifications",["user_id"=>$user_id,"title"=>$title,"message"=>$message]);}