<?php
function resizeImage($file,$width,$height){return true;}