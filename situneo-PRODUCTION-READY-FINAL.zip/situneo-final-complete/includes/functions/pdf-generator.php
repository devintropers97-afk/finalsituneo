<?php
function generatePDF($html,$filename){require_once "vendor/autoload.php";$pdf=new TCPDF();$pdf->AddPage();$pdf->writeHTML($html);$pdf->Output($filename,"D");}