<?php
/**
 * Format Functions
 */

function formatRupiah($amount) {
    return "Rp " . number_format($amount, 0, ',', '.');
}

function formatDate($date) {
    $months = ['Jan','Feb','Mar','Apr','Mei','Jun','Jul','Agt','Sep','Okt','Nov','Des'];
    $d = date_create($date);
    return date_format($d, 'd') . ' ' . $months[date_format($d, 'n')-1] . ' ' . date_format($d, 'Y');
}

function formatPhone($phone) {
    return preg_replace('/(\d{4})(\d{4})(\d{4})/', '$1-$2-$3', $phone);
}
?>