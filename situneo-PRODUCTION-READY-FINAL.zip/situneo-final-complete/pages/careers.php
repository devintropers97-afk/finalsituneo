<?php require_once __DIR__ . "/../includes/init.php"; ?>
<h1>Careers</h1><p>Join our team!</p>