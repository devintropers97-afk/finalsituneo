<?php require_once __DIR__ . "/../includes/init.php"; ?>
<h1>Terms & Conditions</h1><p>Terms of service...</p>