<?php require_once __DIR__ . "/../includes/init.php"; ?>
<h1>Pricing</h1>
<p>Check our competitive prices!</p>