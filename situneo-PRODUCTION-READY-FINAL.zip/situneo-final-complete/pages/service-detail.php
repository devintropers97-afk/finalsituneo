<?php require_once __DIR__ . "/../includes/init.php";
$id = $_GET["id"];
$service = $db->fetchOne("SELECT * FROM services WHERE id=$id");
?>
<h1><?= $service["name"] ?></h1>
<p><?= $service["description"] ?></p>
<p class="h3"><?= formatRupiah($service["price_setup"]) ?></p>
<a href="/client/cart/add.php?service=<?= $id ?>" class="btn btn-warning">Add to Cart</a>