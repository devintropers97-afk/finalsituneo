<?php require_once __DIR__ . "/../includes/init.php"; ?>
<h1>Testimonials</h1>
<blockquote>"Great service!" - Client A</blockquote>
<blockquote>"Highly recommended!" - Client B</blockquote>