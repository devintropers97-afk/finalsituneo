<?php require_once __DIR__ . "/../includes/init.php"; ?>
<h1>Privacy Policy</h1><p>We protect your privacy...</p>