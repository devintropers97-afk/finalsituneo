<?php require_once __DIR__ . "/../includes/init.php"; ?>
<h1>Blog</h1><p>Latest articles and news</p>