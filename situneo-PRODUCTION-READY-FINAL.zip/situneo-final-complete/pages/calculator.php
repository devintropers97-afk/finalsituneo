<?php require_once __DIR__ . "/../includes/init.php"; ?>
<h1>Price Calculator</h1>
<form><select name="service"><option>Select Service</option></select><input type="number" name="quantity" placeholder="Quantity"><button>Calculate</button></form>