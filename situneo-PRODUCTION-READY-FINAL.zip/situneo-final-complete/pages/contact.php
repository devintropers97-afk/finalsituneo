<?php require_once __DIR__ . '/../includes/init.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Contact Us - SITUNEO DIGITAL</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #0F3057; color: white; }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center mb-4">Contact Us</h1>
        <div class="row">
            <div class="col-md-6 mx-auto">
                <div class="card bg-dark p-4">
                    <h4>Get in Touch</h4>
                    <p><i class="bi bi-envelope"></i> Email: <?= COMPANY_EMAIL ?></p>
                    <p><i class="bi bi-whatsapp"></i> WhatsApp: <?= COMPANY_PHONE_FORMATTED ?></p>
                    <p><i class="bi bi-geo-alt"></i> Address: <?= COMPANY_ADDRESS ?></p>
                    <a href="<?= getWhatsAppLink('Halo, saya ingin bertanya tentang layanan SITUNEO') ?>" class="btn btn-success btn-lg w-100 mt-3">
                        <i class="bi bi-whatsapp"></i> Chat WhatsApp
                    </a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
