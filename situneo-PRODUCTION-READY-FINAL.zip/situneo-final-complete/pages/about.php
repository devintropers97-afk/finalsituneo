<?php require_once __DIR__ . '/../includes/init.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>About Us - SITUNEO DIGITAL</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #0F3057; color: white; font-family: 'Inter', sans-serif; }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center mb-4">About SITUNEO Digital</h1>
        <div class="row">
            <div class="col-md-8 mx-auto">
                <p class="lead">SITUNEO Digital adalah platform digital agency terdepan di Indonesia yang menyediakan solusi digital lengkap untuk bisnis Anda.</p>
                <h3 class="mt-4">Our Vision</h3>
                <p>Menjadi platform digital agency #1 di Indonesia yang memberdayakan bisnis lokal untuk go digital.</p>
                <h3 class="mt-4">Our Mission</h3>
                <ul>
                    <li>Menyediakan layanan digital berkualitas tinggi</li>
                    <li>Memberdayakan freelancer dan partner lokal</li>
                    <li>Membantu UMKM untuk transformasi digital</li>
                </ul>
            </div>
        </div>
    </div>
</body>
</html>
