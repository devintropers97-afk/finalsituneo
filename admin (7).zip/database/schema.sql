-- SITUNEO DIGITAL Database Schema
-- Complete 18 tables with relationships

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+07:00";

-- 1. USERS
CREATE TABLE IF NOT EXISTS `users` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(255) NOT NULL,
  `email` VARCHAR(255) NOT NULL,
  `phone` VARCHAR(20) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `role` ENUM('admin','client','freelancer') NOT NULL DEFAULT 'client',
  `email_verified` TINYINT(1) NOT NULL DEFAULT 0,
  `email_verification_token` VARCHAR(255) DEFAULT NULL,
  `email_verified_at` DATETIME DEFAULT NULL,
  `password_reset_token` VARCHAR(255) DEFAULT NULL,
  `password_reset_expires` DATETIME DEFAULT NULL,
  `2fa_enabled` TINYINT(1) NOT NULL DEFAULT 0,
  `2fa_secret` TEXT DEFAULT NULL,
  `last_login` DATETIME DEFAULT NULL,
  `created_at` DATETIME NOT NULL,
  `updated_at` DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. FREELANCERS
CREATE TABLE IF NOT EXISTS `freelancers` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) UNSIGNED NOT NULL,
  `tier` VARCHAR(50) NOT NULL DEFAULT 'Tier 1',
  `total_orders_current_month` INT(11) NOT NULL DEFAULT 0,
  `total_orders_all_time` INT(11) NOT NULL DEFAULT 0,
  `commission_rate` DECIMAL(5,2) NOT NULL DEFAULT 30.00,
  `referral_code` VARCHAR(20) NOT NULL,
  `bank_name` VARCHAR(100) DEFAULT NULL,
  `account_number` VARCHAR(50) DEFAULT NULL,
  `account_holder` VARCHAR(255) DEFAULT NULL,
  `joined_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  UNIQUE KEY `referral_code` (`referral_code`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. DIVISIONS
CREATE TABLE IF NOT EXISTS `divisions` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(255) NOT NULL,
  `slug` VARCHAR(255) NOT NULL,
  `description` TEXT,
  `icon` VARCHAR(100) DEFAULT NULL,
  `created_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. SERVICES
CREATE TABLE IF NOT EXISTS `services` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `division_id` INT(11) UNSIGNED NOT NULL,
  `name` VARCHAR(255) NOT NULL,
  `slug` VARCHAR(255) NOT NULL,
  `description` TEXT,
  `price_onetime` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `price_monthly` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `features` TEXT,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  FOREIGN KEY (`division_id`) REFERENCES `divisions`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. ORDERS
CREATE TABLE IF NOT EXISTS `orders` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `order_number` VARCHAR(50) NOT NULL,
  `user_id` INT(11) UNSIGNED NOT NULL,
  `freelancer_id` INT(11) UNSIGNED DEFAULT NULL,
  `service_id` INT(11) UNSIGNED NOT NULL,
  `status` ENUM('pending','waiting_payment','paid','processing','completed','cancelled') DEFAULT 'pending',
  `payment_status` ENUM('pending','verified','rejected') DEFAULT 'pending',
  `total_amount` DECIMAL(12,2) NOT NULL,
  `payment_type` ENUM('onetime','monthly') DEFAULT 'onetime',
  `notes` TEXT,
  `created_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_number` (`order_number`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`service_id`) REFERENCES `services`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 6. PAYMENTS
CREATE TABLE IF NOT EXISTS `payments` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `order_id` INT(11) UNSIGNED NOT NULL,
  `amount` DECIMAL(12,2) NOT NULL,
  `method` VARCHAR(50) DEFAULT 'bank_transfer',
  `bank_name` VARCHAR(100) DEFAULT NULL,
  `account_number` VARCHAR(50) DEFAULT NULL,
  `proof_image` VARCHAR(255) DEFAULT NULL,
  `status` ENUM('pending','verified','rejected') DEFAULT 'pending',
  `verified_at` DATETIME DEFAULT NULL,
  `verified_by` INT(11) UNSIGNED DEFAULT NULL,
  `created_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`order_id`) REFERENCES `orders`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 7. COMMISSIONS
CREATE TABLE IF NOT EXISTS `commissions` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `freelancer_id` INT(11) UNSIGNED NOT NULL,
  `order_id` INT(11) UNSIGNED NOT NULL,
  `amount` DECIMAL(12,2) NOT NULL,
  `tier_at_time` VARCHAR(50) NOT NULL,
  `commission_rate` DECIMAL(5,2) NOT NULL,
  `status` ENUM('pending','approved','paid') DEFAULT 'pending',
  `paid_at` DATETIME DEFAULT NULL,
  `created_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`freelancer_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`order_id`) REFERENCES `orders`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 8. WITHDRAWALS
CREATE TABLE IF NOT EXISTS `withdrawals` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `freelancer_id` INT(11) UNSIGNED NOT NULL,
  `amount` DECIMAL(12,2) NOT NULL,
  `bank_name` VARCHAR(100) NOT NULL,
  `account_number` VARCHAR(50) NOT NULL,
  `account_holder` VARCHAR(255) NOT NULL,
  `status` ENUM('pending','approved','rejected','paid') DEFAULT 'pending',
  `processed_at` DATETIME DEFAULT NULL,
  `processed_by` INT(11) UNSIGNED DEFAULT NULL,
  `notes` TEXT,
  `created_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`freelancer_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 9. REFERRALS
CREATE TABLE IF NOT EXISTS `referrals` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `referrer_id` INT(11) UNSIGNED NOT NULL,
  `referred_id` INT(11) UNSIGNED NOT NULL,
  `order_id` INT(11) UNSIGNED DEFAULT NULL,
  `commission_earned` DECIMAL(12,2) DEFAULT 0.00,
  `created_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`referrer_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`referred_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 10. NOTIFICATIONS
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) UNSIGNED NOT NULL,
  `type` VARCHAR(100) NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `message` TEXT NOT NULL,
  `read_at` DATETIME DEFAULT NULL,
  `created_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 11. EMAIL_QUEUE
CREATE TABLE IF NOT EXISTS `email_queue` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `to_email` VARCHAR(255) NOT NULL,
  `subject` VARCHAR(500) NOT NULL,
  `body` TEXT NOT NULL,
  `status` ENUM('pending','sent','failed') DEFAULT 'pending',
  `sent_at` DATETIME DEFAULT NULL,
  `error` TEXT DEFAULT NULL,
  `created_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 12. TIER_HISTORY
CREATE TABLE IF NOT EXISTS `tier_history` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `freelancer_id` INT(11) UNSIGNED NOT NULL,
  `old_tier` VARCHAR(50) NOT NULL,
  `new_tier` VARCHAR(50) NOT NULL,
  `reason` VARCHAR(255) DEFAULT NULL,
  `changed_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`freelancer_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 13. SECURITY_LOGS
CREATE TABLE IF NOT EXISTS `security_logs` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) UNSIGNED DEFAULT NULL,
  `action` VARCHAR(100) NOT NULL,
  `ip_address` VARCHAR(45) NOT NULL,
  `user_agent` TEXT,
  `status` VARCHAR(255) DEFAULT NULL,
  `created_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 14. LOGIN_ATTEMPTS
CREATE TABLE IF NOT EXISTS `login_attempts` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `email` VARCHAR(255) NOT NULL,
  `ip_address` VARCHAR(45) NOT NULL,
  `success` TINYINT(1) DEFAULT 0,
  `created_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 15. SESSIONS
CREATE TABLE IF NOT EXISTS `sessions` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) UNSIGNED NOT NULL,
  `token` VARCHAR(255) NOT NULL,
  `ip_address` VARCHAR(45) NOT NULL,
  `user_agent` TEXT,
  `expires_at` DATETIME NOT NULL,
  `created_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`token`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 16. SETTINGS
CREATE TABLE IF NOT EXISTS `settings` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `key` VARCHAR(100) NOT NULL,
  `value` TEXT,
  `updated_at` DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 17. PAYMENT_ACCOUNTS
CREATE TABLE IF NOT EXISTS `payment_accounts` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `bank_name` VARCHAR(100) NOT NULL,
  `account_number` VARCHAR(50) NOT NULL,
  `account_holder` VARCHAR(255) NOT NULL,
  `is_active` TINYINT(1) DEFAULT 1,
  `created_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 18. ACTIVITY_LOGS
CREATE TABLE IF NOT EXISTS `activity_logs` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) UNSIGNED DEFAULT NULL,
  `action` VARCHAR(100) NOT NULL,
  `description` TEXT,
  `ip_address` VARCHAR(45) NOT NULL,
  `created_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- DEFAULT DATA
INSERT INTO `users` (`name`, `email`, `phone`, `password`, `role`, `email_verified`, `created_at`) VALUES
('Administrator', 'admin@situneo.my.id', '6283173868915', '$2y$12$LQv3c1ydemgZU9twKLLcHO7WVQ3UhM2J7.5qXFOCCYKPmY7R1XBH2', 'admin', 1, NOW());

INSERT INTO `payment_accounts` (`bank_name`, `account_number`, `account_holder`, `is_active`, `created_at`) VALUES
('BCA', '1234567890', 'SITUNEO DIGITAL', 1, NOW()),
('Mandiri', '0987654321', 'SITUNEO DIGITAL', 1, NOW()),
('BNI', '1122334455', 'SITUNEO DIGITAL', 1, NOW());
