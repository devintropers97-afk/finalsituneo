<?php define('ALLOWED', true); ?>
<!DOCTYPE html>
<html><head><title>403 - Forbidden</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
</head><body style="background: linear-gradient(135deg, #0F3057 0%, #1E5C99 100%); min-height: 100vh; display: flex; align-items: center; justify-content: center;">
<div class="text-center text-white">
<i class="bi bi-shield-fill-exclamation" style="font-size: 8rem; color: #dc3545;"></i>
<h1 class="display-1 fw-bold mt-4">403</h1>
<h3 class="mb-4">Access Forbidden</h3>
<p class="mb-4 text-white-50">Anda tidak memiliki akses ke halaman ini.</p>
<a href="javascript:history.back()" class="btn btn-lg" style="background: linear-gradient(135deg, #FFD700 0%, #FFB400 100%); border: none; color: #0F3057; font-weight: 600; padding: 1rem 2rem; border-radius: 10px;"><i class="bi bi-arrow-left me-2"></i>Kembali</a>
</div></body></html>
