<?php
define('ALLOWED', true);
require_once __DIR__ . '/../../config/app.php';
requireFreelancer();
$pageTitle = 'Tier Information';
require_once __DIR__ . '/../../components/layout/header.php';
require_once __DIR__ . '/../../includes/tier/tier-calculator.php';
$tiers = getAllTiers();
?>
<div class="container py-5">
    <h1 class="text-white mb-4">Commission Tiers</h1>
    <div class="row g-4">
        <?php foreach ($tiers as $tier): ?>
        <div class="col-md-4">
            <div class="card card-glass">
                <div class="card-body text-center">
                    <h3 class="text-warning"><?php echo $tier['name']; ?></h3>
                    <h1 class="text-white my-3"><?php echo $tier['commission_rate']; ?>%</h1>
                    <p class="text-white-50">Commission Rate</p>
                    <hr style="border-color: rgba(255,180,0,0.3);">
                    <p class="text-white-50 small">Required: <?php echo $tier['min_orders']; ?> orders/month</p>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php require_once __DIR__ . '/../../components/layout/footer.php'; ?>
