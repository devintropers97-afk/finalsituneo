<?php
define("ALLOWED", true);
require_once __DIR__ . "/../../config/app.php";
requireFreelancer();
// withdrawal.php implementation
?>