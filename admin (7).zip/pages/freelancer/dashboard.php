<?php
define('ALLOWED', true);
require_once __DIR__ . '/../../config/app.php';
requireFreelancer();
$userId = getCurrentUserID();
$pageTitle = 'Freelancer Dashboard';
require_once __DIR__ . '/../../components/layout/header.php';
global $pdo;
$stmt = $pdo->prepare("SELECT * FROM freelancers WHERE user_id = ?");
$stmt->execute([$userId]);
$freelancer = $stmt->fetch(PDO::FETCH_ASSOC);
$stmt = $pdo->prepare("SELECT SUM(amount) as total FROM commissions WHERE freelancer_id = ? AND status = 'approved'");
$stmt->execute([$userId]);
$balance = $stmt->fetchColumn() ?? 0;
?>
<div class="container py-5">
    <h1 class="text-white mb-4">Freelancer Dashboard</h1>
    <div class="row g-4 mb-4">
        <div class="col-md-3"><?php statCard('Tier', $freelancer['tier'], 'star', 'warning'); ?></div>
        <div class="col-md-3"><?php statCard('Commission Rate', $freelancer['commission_rate'] . '%', 'percent', 'success'); ?></div>
        <div class="col-md-3"><?php statCard('Total Orders', $freelancer['total_orders_all_time'], 'cart', 'primary'); ?></div>
        <div class="col-md-3"><?php statCard('Balance', formatPrice($balance), 'wallet2', 'info'); ?></div>
    </div>
    <div class="row g-4">
        <div class="col-lg-8">
            <div class="card card-glass">
                <div class="card-body">
                    <h5 class="text-white mb-4">Recent Commissions</h5>
                    <?php
                    $stmt = $pdo->prepare("SELECT c.*, o.order_number FROM commissions c LEFT JOIN orders o ON c.order_id = o.id WHERE c.freelancer_id = ? ORDER BY c.created_at DESC LIMIT 5");
                    $stmt->execute([$userId]);
                    $commissions = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    if ($commissions): ?>
                    <div class="table-responsive">
                        <table class="table table-dark">
                            <thead><tr><th>Order #</th><th>Amount</th><th>Status</th><th>Date</th></tr></thead>
                            <tbody>
                                <?php foreach ($commissions as $c): ?>
                                <tr>
                                    <td><?php echo $c['order_number']; ?></td>
                                    <td><?php echo formatPrice($c['amount']); ?></td>
                                    <td><?php echo getStatusBadge($c['status']); ?></td>
                                    <td><?php echo formatDate($c['created_at']); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                    <p class="text-white-50 text-center">No commissions yet</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="card card-glass">
                <div class="card-body">
                    <h5 class="text-white mb-4">Referral Code</h5>
                    <div class="input-group mb-3">
                        <input type="text" class="form-control auth-input" value="<?php echo $freelancer['referral_code']; ?>" id="refCode" readonly>
                        <button class="btn btn-gradient-gold" onclick="copyToClipboard('<?php echo $freelancer['referral_code']; ?>')">
                            <i class="bi bi-clipboard"></i>
                        </button>
                    </div>
                    <a href="referral.php" class="btn btn-outline-light w-100">View Referral Stats</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/../../components/layout/footer.php'; ?>
