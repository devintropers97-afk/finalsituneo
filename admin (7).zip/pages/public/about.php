<?php
define("ALLOWED", true);
require_once __DIR__ . "/../../config/app.php";
$pageTitle = "About";
require_once __DIR__ . "/../../components/layout/header.php";
?>
<div class="container py-5"><h1 class="text-white">About</h1></div>
<?php require_once __DIR__ . "/../../components/layout/footer.php"; ?>