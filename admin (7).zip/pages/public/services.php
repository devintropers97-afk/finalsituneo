<?php
define('ALLOWED', true);
require_once __DIR__ . '/../../config/app.php';
require_once __DIR__ . '/../../includes/services/services-data.php';
$pageTitle = 'Our Services';
require_once __DIR__ . '/../../components/layout/header.php';
$divisions = getAllDivisions();
?>
<div class="container py-5">
    <h1 class="text-white text-center mb-2">Our Services</h1>
    <p class="text-white-50 text-center mb-5">Professional digital solutions for your business needs</p>
    <?php foreach ($divisions as $division): ?>
    <div class="mb-5">
        <h3 class="text-warning mb-4"><?php echo $division['name']; ?></h3>
        <div class="row g-4">
            <?php
            $services = getServicesByDivision($division['id']);
            foreach ($services as $service): ?>
            <div class="col-md-6 col-lg-4">
                <div class="card card-glass h-100">
                    <div class="card-body">
                        <h5 class="text-white"><?php echo $service['name']; ?></h5>
                        <p class="text-white-50 small"><?php echo $service['description']; ?></p>
                        <hr style="border-color: rgba(255,180,0,0.3);">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <p class="text-white-50 small mb-0">Starting from</p>
                                <h5 class="text-warning mb-0"><?php echo formatPrice($service['price_onetime']); ?></h5>
                            </div>
                            <a href="<?php echo SITE_URL; ?>/pages/auth/register.php" class="btn btn-sm btn-gradient-gold">Order</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<?php require_once __DIR__ . '/../../components/layout/footer.php'; ?>
