<?php
define('ALLOWED', true);
require_once __DIR__ . '/../../config/app.php';
$pageTitle = 'Home';
require_once __DIR__ . '/../../components/layout/header.php';
?>
<div class="container-fluid px-0">
    <div class="hero-section" style="min-height: 600px; background: linear-gradient(135deg, #0F3057 0%, #1E5C99 100%); display: flex; align-items: center;">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <h1 class="display-3 fw-bold text-white mb-4">Digital Harmony for a Modern World</h1>
                    <p class="lead text-white-50 mb-4">Your trusted partner for digital solutions. NIB-registered and professional.</p>
                    <div class="d-flex gap-3">
                        <a href="services.php" class="btn btn-gradient-gold btn-lg px-5">
                            <i class="bi bi-grid-3x3-gap me-2"></i>Our Services
                        </a>
                        <a href="<?php echo SITE_URL; ?>/pages/auth/register.php" class="btn btn-outline-light btn-lg px-5">
                            Get Started
                        </a>
                    </div>
                </div>
                <div class="col-lg-6">
                    <img src="<?php echo SITE_URL; ?>/assets/img/hero-illustration.svg" alt="Hero" class="img-fluid">
                </div>
            </div>
        </div>
    </div>
    
    <div class="container py-5">
        <h2 class="text-white text-center mb-5">Why Choose SITUNEO DIGITAL?</h2>
        <div class="row g-4">
            <div class="col-md-4">
                <div class="card card-glass text-center h-100">
                    <div class="card-body">
                        <i class="bi bi-shield-check text-warning" style="font-size: 3rem;"></i>
                        <h5 class="text-white mt-3">NIB Registered</h5>
                        <p class="text-white-50">Officially registered business with NIB certification</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card card-glass text-center h-100">
                    <div class="card-body">
                        <i class="bi bi-people text-warning" style="font-size: 3rem;"></i>
                        <h5 class="text-white mt-3">Professional Team</h5>
                        <p class="text-white-50">Experienced professionals ready to help</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card card-glass text-center h-100">
                    <div class="card-body">
                        <i class="bi bi-currency-dollar text-warning" style="font-size: 3rem;"></i>
                        <h5 class="text-white mt-3">Earn Commission</h5>
                        <p class="text-white-50">Join as freelancer and earn attractive commissions</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/../../components/layout/footer.php'; ?>
