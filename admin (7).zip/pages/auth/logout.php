<?php
define('ALLOWED', true);
require_once __DIR__ . '/../../config/app.php';

destroySession();
setFlashMessage('success', 'You have been logged out successfully');
redirect('/pages/auth/login.php');
?>
