<?php
define('ALLOWED', true);
require_once __DIR__ . '/../../config/app.php';

if (isLoggedIn()) {
    redirect(getDashboardUrl(getCurrentUserRole()));
}

$pageTitle = 'Login';
$additionalCSS = ['auth'];
require_once __DIR__ . '/../../components/layout/header.php';
?>

<div class="auth-container">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-5 col-md-7">
                <div class="auth-card p-5">
                    <div class="text-center mb-4">
                        <h2 class="fw-bold text-white">Welcome Back!</h2>
                        <p class="text-white-50">Login to your SITUNEO DIGITAL account</p>
                    </div>
                    
                    <?php showFlashAlert(); ?>
                    
                    <form method="POST" action="<?php echo SITE_URL; ?>/api/auth/login.php" id="loginForm">
                        <?php echo csrfField(); ?>
                        
                        <div class="mb-3">
                            <label class="form-label text-white">Email</label>
                            <input type="email" name="email" class="auth-input form-control" required placeholder="your@email.com">
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label text-white">Password</label>
                            <input type="password" name="password" class="auth-input form-control" required placeholder="••••••••">
                        </div>
                        
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="remember" id="remember">
                                <label class="form-check-label text-white-50" for="remember">Remember me</label>
                            </div>
                            <a href="forgot-password.php" class="text-warning text-decoration-none">Forgot password?</a>
                        </div>
                        
                        <button type="submit" class="btn btn-gradient-gold w-100 py-3 mb-3">
                            <i class="bi bi-box-arrow-in-right me-2"></i>Login
                        </button>
                        
                        <div class="text-center">
                            <p class="text-white-50 mb-0">Don't have an account? <a href="register.php" class="text-warning fw-bold">Register here</a></p>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
setupFormValidation('loginForm');
</script>

<?php require_once __DIR__ . '/../../components/layout/footer.php'; ?>
