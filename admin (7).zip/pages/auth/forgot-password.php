<?php
define('ALLOWED', true);
require_once __DIR__ . '/../../config/app.php';

$pageTitle = 'Forgot Password';
$additionalCSS = ['auth'];
require_once __DIR__ . '/../../components/layout/header.php';
?>

<div class="auth-container">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-5 col-md-7">
                <div class="auth-card p-5">
                    <div class="text-center mb-4">
                        <i class="bi bi-key-fill text-warning" style="font-size: 3rem;"></i>
                        <h2 class="fw-bold text-white mt-3">Forgot Password?</h2>
                        <p class="text-white-50">Enter your email to receive reset instructions</p>
                    </div>
                    
                    <?php showFlashAlert(); ?>
                    
                    <form method="POST" action="<?php echo SITE_URL; ?>/api/auth/forgot-password.php">
                        <?php echo csrfField(); ?>
                        
                        <div class="mb-4">
                            <label class="form-label text-white">Email</label>
                            <input type="email" name="email" class="auth-input form-control" required placeholder="your@email.com">
                        </div>
                        
                        <button type="submit" class="btn btn-gradient-gold w-100 py-3 mb-3">
                            <i class="bi bi-send me-2"></i>Send Reset Link
                        </button>
                        
                        <div class="text-center">
                            <a href="login.php" class="text-warning text-decoration-none">
                                <i class="bi bi-arrow-left me-1"></i>Back to Login
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../components/layout/footer.php'; ?>
