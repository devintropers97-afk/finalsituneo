<?php
define('ALLOWED', true);
require_once __DIR__ . '/../../config/app.php';

$token = $_GET['token'] ?? '';
$message = '';
$success = false;

if (!empty($token)) {
    $result = verifyEmail($token);
    $success = $result['success'];
    $message = $result['message'];
}

$pageTitle = 'Email Verification';
$additionalCSS = ['auth'];
require_once __DIR__ . '/../../components/layout/header.php';
?>

<div class="auth-container">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-5 col-md-7">
                <div class="auth-card p-5 text-center">
                    <?php if ($success): ?>
                        <i class="bi bi-check-circle-fill text-success" style="font-size: 5rem;"></i>
                        <h2 class="fw-bold text-white mt-4">Email Verified!</h2>
                        <p class="text-white-50 mb-4"><?php echo $message; ?></p>
                        <a href="login.php" class="btn btn-gradient-gold px-5 py-3">
                            <i class="bi bi-box-arrow-in-right me-2"></i>Login Now
                        </a>
                    <?php else: ?>
                        <i class="bi bi-x-circle-fill text-danger" style="font-size: 5rem;"></i>
                        <h2 class="fw-bold text-white mt-4">Verification Failed</h2>
                        <p class="text-white-50 mb-4"><?php echo $message ?: 'Invalid or expired token'; ?></p>
                        <a href="login.php" class="btn btn-gradient-gold px-5 py-3">
                            <i class="bi bi-arrow-left me-2"></i>Back to Login
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../components/layout/footer.php'; ?>
