<?php
define('ALLOWED', true);
require_once __DIR__ . '/../../config/app.php';

if (isLoggedIn()) {
    redirect(getDashboardUrl(getCurrentUserRole()));
}

$pageTitle = 'Register';
$additionalCSS = ['auth'];
require_once __DIR__ . '/../../components/layout/header.php';
?>

<div class="auth-container">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6 col-md-8">
                <div class="auth-card p-5">
                    <div class="text-center mb-4">
                        <h2 class="fw-bold text-white">Join SITUNEO DIGITAL</h2>
                        <p class="text-white-50">Create your account and start your journey</p>
                    </div>
                    
                    <?php showFlashAlert(); ?>
                    
                    <form method="POST" action="<?php echo SITE_URL; ?>/api/auth/register.php" id="registerForm">
                        <?php echo csrfField(); ?>
                        
                        <div class="mb-3">
                            <label class="form-label text-white">Full Name <span class="text-danger">*</span></label>
                            <input type="text" name="name" class="auth-input form-control" required placeholder="John Doe">
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label text-white">Email <span class="text-danger">*</span></label>
                            <input type="email" name="email" class="auth-input form-control" required placeholder="your@email.com">
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label text-white">Phone <span class="text-danger">*</span></label>
                            <input type="tel" name="phone" class="auth-input form-control" required placeholder="08123456789">
                            <small class="text-white-50">Format: 08xx or 628xx</small>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label text-white">Password <span class="text-danger">*</span></label>
                            <input type="password" name="password" class="auth-input form-control" required placeholder="••••••••">
                            <small class="text-white-50">Min 8 chars, uppercase, lowercase, number</small>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label text-white">Confirm Password <span class="text-danger">*</span></label>
                            <input type="password" name="password_confirm" class="auth-input form-control" required placeholder="••••••••">
                        </div>
                        
                        <div class="mb-4">
                            <label class="form-label text-white">Register as <span class="text-danger">*</span></label>
                            <select name="role" class="auth-input form-select" required>
                                <option value="">-- Select Role --</option>
                                <option value="client">Client (Order Services)</option>
                                <option value="freelancer">Freelancer (Earn Commission)</option>
                            </select>
                        </div>
                        
                        <div class="form-check mb-4">
                            <input class="form-check-input" type="checkbox" required id="terms">
                            <label class="form-check-label text-white-50" for="terms">
                                I agree to the <a href="#" class="text-warning">Terms & Conditions</a>
                            </label>
                        </div>
                        
                        <button type="submit" class="btn btn-gradient-gold w-100 py-3 mb-3">
                            <i class="bi bi-person-plus me-2"></i>Create Account
                        </button>
                        
                        <div class="text-center">
                            <p class="text-white-50 mb-0">Already have an account? <a href="login.php" class="text-warning fw-bold">Login here</a></p>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
setupFormValidation('registerForm');
</script>

<?php require_once __DIR__ . '/../../components/layout/footer.php'; ?>
