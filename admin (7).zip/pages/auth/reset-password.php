<?php
define('ALLOWED', true);
require_once __DIR__ . '/../../config/app.php';

$token = $_GET['token'] ?? '';
if (empty($token)) {
    redirect('/pages/auth/login.php');
}

$pageTitle = 'Reset Password';
$additionalCSS = ['auth'];
require_once __DIR__ . '/../../components/layout/header.php';
?>

<div class="auth-container">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-5 col-md-7">
                <div class="auth-card p-5">
                    <div class="text-center mb-4">
                        <i class="bi bi-shield-lock-fill text-warning" style="font-size: 3rem;"></i>
                        <h2 class="fw-bold text-white mt-3">Reset Password</h2>
                        <p class="text-white-50">Enter your new password</p>
                    </div>
                    
                    <?php showFlashAlert(); ?>
                    
                    <form method="POST" action="<?php echo SITE_URL; ?>/api/auth/reset-password.php">
                        <?php echo csrfField(); ?>
                        <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">
                        
                        <div class="mb-3">
                            <label class="form-label text-white">New Password</label>
                            <input type="password" name="password" class="auth-input form-control" required placeholder="••••••••">
                            <small class="text-white-50">Min 8 chars, uppercase, lowercase, number</small>
                        </div>
                        
                        <div class="mb-4">
                            <label class="form-label text-white">Confirm New Password</label>
                            <input type="password" name="password_confirm" class="auth-input form-control" required placeholder="••••••••">
                        </div>
                        
                        <button type="submit" class="btn btn-gradient-gold w-100 py-3">
                            <i class="bi bi-check-circle me-2"></i>Reset Password
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../components/layout/footer.php'; ?>
