<?php
define('ALLOWED', true);
require_once __DIR__ . '/../../config/app.php';

requireAuth();

$pageTitle = '2FA Verification';
$additionalCSS = ['auth'];
require_once __DIR__ . '/../../components/layout/header.php';
?>

<div class="auth-container">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-5 col-md-7">
                <div class="auth-card p-5">
                    <div class="text-center mb-4">
                        <i class="bi bi-shield-check text-warning" style="font-size: 3rem;"></i>
                        <h2 class="fw-bold text-white mt-3">Two-Factor Authentication</h2>
                        <p class="text-white-50">Enter the 6-digit code from your authenticator app</p>
                    </div>
                    
                    <?php showFlashAlert(); ?>
                    
                    <form method="POST" action="<?php echo SITE_URL; ?>/api/auth/verify-2fa.php">
                        <?php echo csrfField(); ?>
                        
                        <div class="mb-4">
                            <input type="text" name="code" class="auth-input form-control text-center" 
                                   required placeholder="000000" maxlength="6" pattern="[0-9]{6}"
                                   style="font-size: 2rem; letter-spacing: 1rem;">
                        </div>
                        
                        <button type="submit" class="btn btn-gradient-gold w-100 py-3">
                            <i class="bi bi-check-circle me-2"></i>Verify
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../components/layout/footer.php'; ?>
