<?php
define('ALLOWED', true);
require_once __DIR__ . '/../../config/app.php';
requireClient();

$userId = getCurrentUserID();
$pageTitle = 'My Orders';
require_once __DIR__ . '/../../components/layout/header.php';

global $pdo;
$stmt = $pdo->prepare("SELECT o.*, s.name as service_name FROM orders o LEFT JOIN services s ON o.service_id = s.id WHERE o.user_id = ? ORDER BY o.created_at DESC");
$stmt->execute([$userId]);
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="container py-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="text-white">My Orders</h1>
        <a href="order-create.php" class="btn btn-gradient-gold">
            <i class="bi bi-plus-circle me-2"></i>New Order
        </a>
    </div>
    
    <div class="card card-glass">
        <div class="card-body">
            <?php if ($orders): ?>
            <div class="table-responsive">
                <table class="table table-dark">
                    <thead>
                        <tr>
                            <th>Order #</th>
                            <th>Service</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Payment</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($orders as $order): ?>
                        <tr>
                            <td><?php echo $order['order_number']; ?></td>
                            <td><?php echo $order['service_name']; ?></td>
                            <td><?php echo formatPrice($order['total_amount']); ?></td>
                            <td><?php echo getStatusBadge($order['status']); ?></td>
                            <td><?php echo getStatusBadge($order['payment_status']); ?></td>
                            <td><?php echo formatDate($order['created_at']); ?></td>
                            <td>
                                <a href="order-detail.php?id=<?php echo $order['id']; ?>" class="btn btn-sm btn-outline-light">
                                    <i class="bi bi-eye"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="text-center py-5">
                <i class="bi bi-cart-x text-white-50" style="font-size: 4rem;"></i>
                <h5 class="text-white mt-3">No orders yet</h5>
                <p class="text-white-50">Start by creating your first order</p>
                <a href="order-create.php" class="btn btn-gradient-gold mt-3">Create Order</a>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../components/layout/footer.php'; ?>
