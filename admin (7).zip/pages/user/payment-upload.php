<?php
define('ALLOWED', true);
require_once __DIR__ . '/../../config/app.php';
requireClient();

$orderId = $_GET['order_id'] ?? 0;
$userId = getCurrentUserID();

global $pdo;
$stmt = $pdo->prepare("SELECT o.*, s.name as service_name FROM orders o LEFT JOIN services s ON o.service_id = s.id WHERE o.id = ? AND o.user_id = ?");
$stmt->execute([$orderId, $userId]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$order || $order['payment_status'] != 'pending') {
    redirect('/pages/user/orders.php');
}

$pageTitle = 'Upload Payment Proof';
require_once __DIR__ . '/../../components/layout/header.php';
?>

<div class="container py-5">
    <h1 class="text-white mb-4">Upload Payment Proof</h1>
    
    <div class="row">
        <div class="col-lg-8">
            <div class="card card-glass">
                <div class="card-body">
                    <div class="alert alert-info">
                        <i class="bi bi-info-circle me-2"></i>
                        Please transfer to one of our payment accounts and upload the proof here.
                    </div>
                    
                    <form method="POST" action="<?php echo SITE_URL; ?>/api/payments/upload.php" enctype="multipart/form-data">
                        <?php echo csrfField(); ?>
                        <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                        
                        <div class="mb-3">
                            <label class="form-label text-white">Payment Method</label>
                            <select name="payment_method" class="form-select auth-input" required>
                                <option value="">-- Select Method --</option>
                                <option value="bank_transfer">Bank Transfer</option>
                                <option value="ewallet">E-Wallet</option>
                                <option value="qris">QRIS</option>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label text-white">Payment Proof Image</label>
                            <input type="file" name="proof_image" class="form-control auth-input" accept="image/*" required>
                            <small class="text-white-50">Max 2MB. JPG, PNG, or JPEG</small>
                        </div>
                        
                        <div class="mb-4">
                            <label class="form-label text-white">Notes (Optional)</label>
                            <textarea name="notes" class="form-control auth-input" rows="3" placeholder="Additional information..."></textarea>
                        </div>
                        
                        <button type="submit" class="btn btn-gradient-gold">
                            <i class="bi bi-upload me-2"></i>Upload Proof
                        </button>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="col-lg-4">
            <div class="card card-glass">
                <div class="card-body">
                    <h5 class="text-white mb-3">Order Summary</h5>
                    <div class="mb-2">
                        <span class="text-white-50">Order #:</span>
                        <span class="text-white float-end"><?php echo $order['order_number']; ?></span>
                    </div>
                    <div class="mb-2">
                        <span class="text-white-50">Service:</span>
                        <span class="text-white float-end"><?php echo $order['service_name']; ?></span>
                    </div>
                    <hr style="border-color: rgba(255,180,0,0.3);">
                    <div>
                        <span class="text-white-50">Total Amount:</span>
                        <h4 class="text-warning float-end mb-0"><?php echo formatPrice($order['total_amount']); ?></h4>
                    </div>
                </div>
            </div>
            
            <div class="card card-glass mt-3">
                <div class="card-body">
                    <h5 class="text-white mb-3">Payment Accounts</h5>
                    <div class="small text-white-50">
                        <p class="mb-2"><strong>BCA:</strong> 1234567890</p>
                        <p class="mb-2"><strong>Mandiri:</strong> 9876543210</p>
                        <p class="mb-0"><strong>BNI:</strong> 5555666677</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../components/layout/footer.php'; ?>
