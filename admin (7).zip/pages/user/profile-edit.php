<?php
define('ALLOWED', true);
require_once __DIR__ . '/../../config/app.php';
requireClient();

$userId = getCurrentUserID();
global $pdo;
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$userId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

$pageTitle = 'Edit Profile';
require_once __DIR__ . '/../../components/layout/header.php';
?>

<div class="container py-5">
    <div class="mb-4">
        <a href="profile.php" class="text-warning text-decoration-none">
            <i class="bi bi-arrow-left me-2"></i>Back to Profile
        </a>
    </div>
    
    <h1 class="text-white mb-4">Edit Profile</h1>
    
    <div class="row">
        <div class="col-lg-8">
            <div class="card card-glass">
                <div class="card-body">
                    <?php showFlashAlert(); ?>
                    
                    <form method="POST" action="<?php echo SITE_URL; ?>/api/user/update-profile.php">
                        <?php echo csrfField(); ?>
                        
                        <div class="mb-3">
                            <label class="form-label text-white">Full Name</label>
                            <input type="text" name="name" class="form-control auth-input" value="<?php echo htmlspecialchars($user['name']); ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label text-white">Phone</label>
                            <input type="tel" name="phone" class="form-control auth-input" value="<?php echo htmlspecialchars($user['phone']); ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label text-white">Email</label>
                            <input type="email" class="form-control auth-input" value="<?php echo htmlspecialchars($user['email']); ?>" disabled>
                            <small class="text-white-50">Email cannot be changed</small>
                        </div>
                        
                        <hr style="border-color: rgba(255,180,0,0.3);">
                        
                        <h5 class="text-white mb-3">Change Password (Optional)</h5>
                        
                        <div class="mb-3">
                            <label class="form-label text-white">Current Password</label>
                            <input type="password" name="current_password" class="form-control auth-input">
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label text-white">New Password</label>
                            <input type="password" name="new_password" class="form-control auth-input">
                            <small class="text-white-50">Leave blank to keep current password</small>
                        </div>
                        
                        <div class="mb-4">
                            <label class="form-label text-white">Confirm New Password</label>
                            <input type="password" name="confirm_password" class="form-control auth-input">
                        </div>
                        
                        <button type="submit" class="btn btn-gradient-gold">
                            <i class="bi bi-check-circle me-2"></i>Save Changes
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../components/layout/footer.php'; ?>
