<?php
define('ALLOWED', true);
require_once __DIR__ . '/../../config/app.php';
requireClient();

$pageTitle = 'Create Order';
require_once __DIR__ . '/../../components/layout/header.php';
require_once __DIR__ . '/../../includes/services/services-data.php';

$divisions = getAllDivisions();
$services = getAllServices();
?>

<div class="container py-5">
    <h1 class="text-white mb-4">Create New Order</h1>
    
    <div class="row">
        <div class="col-lg-8">
            <div class="card card-glass">
                <div class="card-body">
                    <form method="POST" action="<?php echo SITE_URL; ?>/api/orders/create.php" id="orderForm">
                        <?php echo csrfField(); ?>
                        
                        <div class="mb-3">
                            <label class="form-label text-white">Select Division</label>
                            <select name="division" id="divisionSelect" class="form-select auth-input">
                                <option value="">-- Choose Division --</option>
                                <?php foreach ($divisions as $div): ?>
                                <option value="<?php echo $div['id']; ?>"><?php echo $div['name']; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label text-white">Select Service</label>
                            <select name="service_id" id="serviceSelect" class="form-select auth-input" required>
                                <option value="">-- Choose Service --</option>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label text-white">Payment Type</label>
                            <select name="payment_type" class="form-select auth-input" required>
                                <option value="onetime">One-time Payment</option>
                                <option value="monthly">Monthly Subscription</option>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label text-white">Referral Code (Optional)</label>
                            <input type="text" name="referral_code" class="form-control auth-input" placeholder="Enter referral code">
                        </div>
                        
                        <div class="mb-4">
                            <label class="form-label text-white">Notes</label>
                            <textarea name="notes" class="form-control auth-input" rows="4" placeholder="Any special requirements..."></textarea>
                        </div>
                        
                        <button type="submit" class="btn btn-gradient-gold">
                            <i class="bi bi-check-circle me-2"></i>Create Order
                        </button>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="col-lg-4">
            <div class="card card-glass">
                <div class="card-body">
                    <h5 class="text-white mb-3">Need Help?</h5>
                    <p class="text-white-50 small">Contact our support team if you need assistance with your order.</p>
                    <a href="<?php echo SITE_URL; ?>/pages/public/contact.php" class="btn btn-outline-light btn-sm">
                        <i class="bi bi-chat-dots me-2"></i>Contact Support
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
const services = <?php echo json_encode($services); ?>;
const divisionSelect = document.getElementById('divisionSelect');
const serviceSelect = document.getElementById('serviceSelect');

divisionSelect.addEventListener('change', function() {
    const divisionId = parseInt(this.value);
    serviceSelect.innerHTML = '<option value="">-- Choose Service --</option>';
    
    if (divisionId) {
        const filtered = services.filter(s => s.division_id === divisionId);
        filtered.forEach(service => {
            const option = document.createElement('option');
            option.value = service.slug;
            option.textContent = service.name + ' - ' + formatPrice(service.price_onetime);
            serviceSelect.appendChild(option);
        });
    }
});
</script>

<?php require_once __DIR__ . '/../../components/layout/footer.php'; ?>
