<?php
define('ALLOWED', true);
require_once __DIR__ . '/../../config/app.php';
requireClient();

$userId = getCurrentUserID();
global $pdo;
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$userId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

$pageTitle = 'My Profile';
require_once __DIR__ . '/../../components/layout/header.php';
?>

<div class="container py-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="text-white">My Profile</h1>
        <a href="profile-edit.php" class="btn btn-gradient-gold">
            <i class="bi bi-pencil me-2"></i>Edit Profile
        </a>
    </div>
    
    <div class="row">
        <div class="col-lg-4">
            <div class="card card-glass text-center">
                <div class="card-body py-5">
                    <div class="mb-3">
                        <i class="bi bi-person-circle text-warning" style="font-size: 5rem;"></i>
                    </div>
                    <h4 class="text-white"><?php echo htmlspecialchars($user['name']); ?></h4>
                    <p class="text-white-50"><?php echo strtoupper($user['role']); ?></p>
                    <?php if ($user['email_verified']): ?>
                    <span class="badge badge-gold">
                        <i class="bi bi-check-circle-fill me-1"></i>Verified
                    </span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <div class="col-lg-8">
            <div class="card card-glass">
                <div class="card-body">
                    <h5 class="text-white mb-4">Personal Information</h5>
                    
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <span class="text-white-50">Full Name:</span>
                        </div>
                        <div class="col-md-8">
                            <span class="text-white"><?php echo htmlspecialchars($user['name']); ?></span>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <span class="text-white-50">Email:</span>
                        </div>
                        <div class="col-md-8">
                            <span class="text-white"><?php echo htmlspecialchars($user['email']); ?></span>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <span class="text-white-50">Phone:</span>
                        </div>
                        <div class="col-md-8">
                            <span class="text-white"><?php echo htmlspecialchars($user['phone']); ?></span>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <span class="text-white-50">Role:</span>
                        </div>
                        <div class="col-md-8">
                            <span class="text-white"><?php echo strtoupper($user['role']); ?></span>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <span class="text-white-50">Member Since:</span>
                        </div>
                        <div class="col-md-8">
                            <span class="text-white"><?php echo formatDate($user['created_at']); ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../components/layout/footer.php'; ?>
