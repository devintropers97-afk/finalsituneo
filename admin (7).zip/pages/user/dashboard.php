<?php
define('ALLOWED', true);
require_once __DIR__ . '/../../config/app.php';
requireClient();

$userId = getCurrentUserID();
$pageTitle = 'Dashboard';
$additionalCSS = ['dashboard'];
require_once __DIR__ . '/../../components/layout/header.php';

// Get user stats
global $pdo;
$stmt = $pdo->prepare("SELECT COUNT(*) FROM orders WHERE user_id = ?");
$stmt->execute([$userId]);
$totalOrders = $stmt->fetchColumn();

$stmt = $pdo->prepare("SELECT COUNT(*) FROM orders WHERE user_id = ? AND status = 'completed'");
$stmt->execute([$userId]);
$completedOrders = $stmt->fetchColumn();

$stmt = $pdo->prepare("SELECT SUM(total_amount) FROM orders WHERE user_id = ? AND payment_status = 'verified'");
$stmt->execute([$userId]);
$totalSpent = $stmt->fetchColumn() ?? 0;
?>

<div class="container py-5">
    <h1 class="text-white mb-4">Welcome, <?php echo $_SESSION['user_name']; ?>!</h1>
    
    <?php showFlashAlert(); ?>
    
    <div class="row g-4 mb-4">
        <div class="col-md-4">
            <?php statCard('Total Orders', $totalOrders, 'cart', 'primary'); ?>
        </div>
        <div class="col-md-4">
            <?php statCard('Completed', $completedOrders, 'check-circle', 'success'); ?>
        </div>
        <div class="col-md-4">
            <?php statCard('Total Spent', formatPrice($totalSpent), 'currency-dollar', 'warning'); ?>
        </div>
    </div>
    
    <div class="row g-4">
        <div class="col-lg-8">
            <div class="card card-glass">
                <div class="card-body">
                    <h5 class="text-white mb-4">Recent Orders</h5>
                    <?php
                    $stmt = $pdo->prepare("SELECT o.*, s.name as service_name FROM orders o LEFT JOIN services s ON o.service_id = s.id WHERE o.user_id = ? ORDER BY o.created_at DESC LIMIT 5");
                    $stmt->execute([$userId]);
                    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    
                    if ($orders):
                    ?>
                    <div class="table-responsive">
                        <table class="table table-dark">
                            <thead>
                                <tr>
                                    <th>Order #</th>
                                    <th>Service</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($orders as $order): ?>
                                <tr>
                                    <td><?php echo $order['order_number']; ?></td>
                                    <td><?php echo $order['service_name']; ?></td>
                                    <td><?php echo formatPrice($order['total_amount']); ?></td>
                                    <td><?php echo getStatusBadge($order['status']); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                    <p class="text-white-50 text-center">No orders yet</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <div class="col-lg-4">
            <div class="card card-glass">
                <div class="card-body">
                    <h5 class="text-white mb-4">Quick Actions</h5>
                    <div class="d-grid gap-2">
                        <a href="order-create.php" class="btn btn-gradient-gold">
                            <i class="bi bi-plus-circle me-2"></i>New Order
                        </a>
                        <a href="orders.php" class="btn btn-outline-light">
                            <i class="bi bi-cart me-2"></i>View Orders
                        </a>
                        <a href="profile.php" class="btn btn-outline-light">
                            <i class="bi bi-person me-2"></i>Edit Profile
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../components/layout/footer.php'; ?>
