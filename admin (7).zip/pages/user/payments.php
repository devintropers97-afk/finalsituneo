<?php
define('ALLOWED', true);
require_once __DIR__ . '/../../config/app.php';
requireClient();

$userId = getCurrentUserID();
$pageTitle = 'Payments';
require_once __DIR__ . '/../../components/layout/header.php';

global $pdo;
$stmt = $pdo->prepare("SELECT p.*, o.order_number, o.total_amount FROM payments p LEFT JOIN orders o ON p.order_id = o.id WHERE o.user_id = ? ORDER BY p.created_at DESC");
$stmt->execute([$userId]);
$payments = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="container py-5">
    <h1 class="text-white mb-4">Payment History</h1>
    
    <div class="card card-glass">
        <div class="card-body">
            <?php if ($payments): ?>
            <div class="table-responsive">
                <table class="table table-dark">
                    <thead>
                        <tr>
                            <th>Order #</th>
                            <th>Amount</th>
                            <th>Method</th>
                            <th>Status</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($payments as $payment): ?>
                        <tr>
                            <td><?php echo $payment['order_number']; ?></td>
                            <td><?php echo formatPrice($payment['total_amount']); ?></td>
                            <td><?php echo strtoupper($payment['payment_method'] ?? 'N/A'); ?></td>
                            <td><?php echo getStatusBadge($payment['status']); ?></td>
                            <td><?php echo formatDate($payment['created_at']); ?></td>
                            <td>
                                <?php if ($payment['proof_image']): ?>
                                <a href="<?php echo UPLOADS_PAYMENTS_URL . '/' . $payment['proof_image']; ?>" target="_blank" class="btn btn-sm btn-outline-light">
                                    <i class="bi bi-image"></i>
                                </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="text-center py-5">
                <i class="bi bi-receipt text-white-50" style="font-size: 4rem;"></i>
                <h5 class="text-white mt-3">No payments yet</h5>
                <p class="text-white-50">Your payment history will appear here</p>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../components/layout/footer.php'; ?>
