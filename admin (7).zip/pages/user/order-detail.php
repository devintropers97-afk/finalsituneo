<?php
define('ALLOWED', true);
require_once __DIR__ . '/../../config/app.php';
requireClient();

$orderId = $_GET['id'] ?? 0;
$userId = getCurrentUserID();

global $pdo;
$stmt = $pdo->prepare("SELECT o.*, s.name as service_name, s.description as service_desc, u.name as freelancer_name FROM orders o LEFT JOIN services s ON o.service_id = s.id LEFT JOIN users u ON o.freelancer_id = u.id WHERE o.id = ? AND o.user_id = ?");
$stmt->execute([$orderId, $userId]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$order) {
    redirect('/pages/user/orders.php');
}

$pageTitle = 'Order Details';
require_once __DIR__ . '/../../components/layout/header.php';
?>

<div class="container py-5">
    <div class="mb-4">
        <a href="orders.php" class="text-warning text-decoration-none">
            <i class="bi bi-arrow-left me-2"></i>Back to Orders
        </a>
    </div>
    
    <div class="row g-4">
        <div class="col-lg-8">
            <div class="card card-glass">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start mb-4">
                        <div>
                            <h3 class="text-white">Order #<?php echo $order['order_number']; ?></h3>
                            <p class="text-white-50 mb-0">Created: <?php echo formatDate($order['created_at']); ?></p>
                        </div>
                        <?php echo getStatusBadge($order['status']); ?>
                    </div>
                    
                    <div class="mb-4">
                        <h5 class="text-white mb-3">Service Details</h5>
                        <div class="bg-dark bg-opacity-50 p-3 rounded">
                            <h6 class="text-warning"><?php echo $order['service_name']; ?></h6>
                            <p class="text-white-50 small mb-0"><?php echo $order['service_desc']; ?></p>
                        </div>
                    </div>
                    
                    <?php if ($order['notes']): ?>
                    <div class="mb-4">
                        <h5 class="text-white mb-3">Notes</h5>
                        <p class="text-white-50"><?php echo nl2br(htmlspecialchars($order['notes'])); ?></p>
                    </div>
                    <?php endif; ?>
                    
                    <?php if ($order['freelancer_name']): ?>
                    <div class="mb-4">
                        <h5 class="text-white mb-3">Assigned Freelancer</h5>
                        <p class="text-white"><?php echo $order['freelancer_name']; ?></p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <div class="col-lg-4">
            <div class="card card-glass mb-3">
                <div class="card-body">
                    <h5 class="text-white mb-3">Payment Information</h5>
                    <div class="mb-2">
                        <span class="text-white-50">Amount:</span>
                        <span class="text-white float-end fw-bold"><?php echo formatPrice($order['total_amount']); ?></span>
                    </div>
                    <div class="mb-2">
                        <span class="text-white-50">Payment Status:</span>
                        <span class="float-end"><?php echo getStatusBadge($order['payment_status']); ?></span>
                    </div>
                    <hr style="border-color: rgba(255,180,0,0.3);">
                    <?php if ($order['payment_status'] == 'pending'): ?>
                    <a href="payment-upload.php?order_id=<?php echo $order['id']; ?>" class="btn btn-gradient-gold w-100">
                        <i class="bi bi-upload me-2"></i>Upload Payment Proof
                    </a>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="card card-glass">
                <div class="card-body">
                    <h5 class="text-white mb-3">Need Help?</h5>
                    <p class="text-white-50 small">Contact support if you have questions about this order.</p>
                    <a href="<?php echo SITE_URL; ?>/pages/public/contact.php" class="btn btn-outline-light btn-sm w-100">
                        <i class="bi bi-chat-dots me-2"></i>Contact Support
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../components/layout/footer.php'; ?>
