<?php
define('ALLOWED', true);
session_start();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}

$dbHost = $_POST['db_host'];
$dbName = $_POST['db_name'];
$dbUser = $_POST['db_user'];
$dbPass = $_POST['db_pass'];

try {
    $pdo = new PDO("mysql:host=$dbHost;charset=utf8mb4", $dbUser, $dbPass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Create database
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `$dbName` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    $pdo->exec("USE `$dbName`");
    
    // Import schema
    $schema = file_get_contents('../database/schema.sql');
    $pdo->exec($schema);
    
    // Self-delete installer
    @unlink(__FILE__);
    @unlink('index.php');
    @rmdir('../installer');
    
    header('Location: index.php?step=3');
} catch (PDOException $e) {
    die('Installation failed: ' . $e->getMessage());
}
?>
