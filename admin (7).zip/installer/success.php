<?php
header('Location: index.php?step=3');
exit;
?>
