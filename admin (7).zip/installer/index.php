<?php
define('ALLOWED', true);
session_start();
$step = $_GET['step'] ?? 1;
?>
<!DOCTYPE html>
<html>
<head>
    <title>SITUNEO DIGITAL - Installer</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
</head>
<body style="background: linear-gradient(135deg, #0F3057 0%, #1E5C99 100%); min-height: 100vh; display: flex; align-items: center;">
<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card" style="background: rgba(15,48,87,0.95); border: 1px solid rgba(255,180,0,0.3); backdrop-filter: blur(20px);">
                <div class="card-header bg-transparent border-bottom text-center py-4" style="border-color: rgba(255,180,0,0.3)!important;">
                    <h3 class="text-white mb-0"><i class="bi bi-download text-warning me-2"></i>SITUNEO DIGITAL Installer</h3>
                    <p class="text-white-50 small mb-0">Step <?php echo $step; ?> of 3</p>
                </div>
                <div class="card-body p-5">
                    <?php if ($step == 1): ?>
                        <h4 class="text-white mb-4">Welcome!</h4>
                        <p class="text-white-50">Before we begin, make sure you have:</p>
                        <ul class="text-white-50">
                            <li>PHP 7.4 or higher</li>
                            <li>MySQL 5.7 or higher</li>
                            <li>Database credentials ready</li>
                        </ul>
                        <a href="?step=2" class="btn btn-lg mt-3" style="background: linear-gradient(135deg, #FFD700 0%, #FFB400 100%); border: none; color: #0F3057; font-weight: 600;">Next <i class="bi bi-arrow-right ms-2"></i></a>
                    <?php elseif ($step == 2): ?>
                        <h4 class="text-white mb-4">Database Configuration</h4>
                        <form method="POST" action="install.php">
                            <div class="mb-3"><label class="form-label text-white">Database Host</label><input type="text" name="db_host" class="form-control" value="localhost" required style="background: rgba(255,255,255,0.1); border: 1px solid rgba(255,180,0,0.3); color: white;"></div>
                            <div class="mb-3"><label class="form-label text-white">Database Name</label><input type="text" name="db_name" class="form-control" value="nrrskfvk_situneo_digital" required style="background: rgba(255,255,255,0.1); border: 1px solid rgba(255,180,0,0.3); color: white;"></div>
                            <div class="mb-3"><label class="form-label text-white">Database Username</label><input type="text" name="db_user" class="form-control" value="nrrskfvk_user_situneo_digital" required style="background: rgba(255,255,255,0.1); border: 1px solid rgba(255,180,0,0.3); color: white;"></div>
                            <div class="mb-3"><label class="form-label text-white">Database Password</label><input type="password" name="db_pass" class="form-control" required style="background: rgba(255,255,255,0.1); border: 1px solid rgba(255,180,0,0.3); color: white;"></div>
                            <button type="submit" class="btn btn-lg" style="background: linear-gradient(135deg, #FFD700 0%, #FFB400 100%); border: none; color: #0F3057; font-weight: 600;">Install <i class="bi bi-check-circle ms-2"></i></button>
                        </form>
                    <?php elseif ($step == 3): ?>
                        <div class="text-center">
                            <i class="bi bi-check-circle-fill text-success" style="font-size: 5rem;"></i>
                            <h4 class="text-white mt-4 mb-3">Installation Complete!</h4>
                            <p class="text-white-50">Your SITUNEO DIGITAL platform is ready to use.</p>
                            <p class="text-white-50">Default admin credentials:</p>
                            <div class="alert alert-warning" role="alert">
                                Email: <strong>admin@situneo.my.id</strong><br>
                                Password: <strong>admin123</strong>
                            </div>
                            <a href="../pages/auth/login.php" class="btn btn-lg" style="background: linear-gradient(135deg, #FFD700 0%, #FFB400 100%); border: none; color: #0F3057; font-weight: 600;">Go to Login <i class="bi bi-arrow-right ms-2"></i></a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
