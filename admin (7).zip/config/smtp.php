<?php
/**
 * SMTP Configuration
 * This file should ONLY contain configuration constants
 * All functions moved to includes/functions/email.php
 */

if (!defined('ALLOWED')) {
    die('Direct access not permitted');
}

// SMTP Server Configuration
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'your-email@gmail.com');  // CHANGE THIS
define('SMTP_PASSWORD', 'your-app-password');      // CHANGE THIS
define('SMTP_SECURE', 'tls');

// Email Sender Configuration
define('SMTP_FROM_EMAIL', SMTP_USERNAME);
define('SMTP_FROM_NAME', 'Your Company Name');     // CHANGE THIS

// Company Email Addresses (used in email functions)
// Only define if not already defined in config/app.php
if (!defined('COMPANY_EMAIL_ADMIN')) {
    define('COMPANY_EMAIL_ADMIN', 'admin@yourdomain.com');
}
if (!defined('COMPANY_EMAIL_SUPPORT')) {
    define('COMPANY_EMAIL_SUPPORT', 'support@yourdomain.com');
}
if (!defined('COMPANY_NAME')) {
    define('COMPANY_NAME', 'Your Company Name');
}

// Email Template Subjects
define('EMAIL_VERIFICATION_SUBJECT', 'Verify Your Email Address');
define('EMAIL_PASSWORD_RESET_SUBJECT', 'Password Reset Request');
define('EMAIL_WELCOME_SUBJECT', 'Welcome to ' . COMPANY_NAME);
define('EMAIL_NOTIFICATION_SUBJECT', 'New Notification from ' . COMPANY_NAME);

// Email Template Settings
define('EMAIL_FOOTER_TEXT', '© ' . date('Y') . ' ' . COMPANY_NAME . '. All rights reserved.');
define('EMAIL_SUPPORT_URL', SITE_URL . '/support');
define('EMAIL_UNSUBSCRIBE_URL', SITE_URL . '/unsubscribe');

// NOTE: All email sending functions have been moved to:
// includes/functions/email.php
// 
// This keeps configuration separate from functionality
// and prevents "Cannot redeclare function" errors
