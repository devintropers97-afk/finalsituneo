<?php
/**
 * Main Application Configuration
 * FIXED VERSION - All errors resolved
 */

// Prevent direct access
if (!defined('ALLOWED')) {
    define('ALLOWED', true);
}

// Error reporting for development (set to 0 in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);

// Site Configuration
define('SITE_NAME', 'SITUNEO DIGITAL');
define('SITE_URL', 'http://situneo.my.id');
define('SITE_EMAIL', 'admin@situneo.my.id');

// Company Information
define('COMPANY_NAME', 'PT. SITUNEO DIGITAL INDONESIA');
define('COMPANY_NIB', '1234567890123');
define('COMPANY_NPWP', '12.345.678.9-012.345');
define('COMPANY_ADDRESS', 'Jakarta, Indonesia');
define('COMPANY_PHONE', '+62 812-3456-7890');
define('COMPANY_EMAIL_ADMIN', 'admin@situneo.my.id');
define('COMPANY_EMAIL_SUPPORT', 'support@situneo.my.id');

// Directory Paths
define('ROOT_PATH', dirname(__DIR__));
define('CONFIG_PATH', ROOT_PATH . '/config');
define('INCLUDES_PATH', ROOT_PATH . '/includes');
define('FUNCTIONS_PATH', INCLUDES_PATH . '/functions');
define('UPLOADS_PATH', ROOT_PATH . '/uploads');
define('UPLOADS_PAYMENTS_PATH', UPLOADS_PATH . '/payments');
define('UPLOADS_PAYMENTS_URL', SITE_URL . '/uploads/payments');
define('UPLOADS_DOCUMENTS_PATH', UPLOADS_PATH . '/documents');

// Timezone
define('TIMEZONE', 'Asia/Jakarta');
date_default_timezone_set(TIMEZONE);

// Database Config
require_once CONFIG_PATH . '/database.php';

// SMTP Config
require_once CONFIG_PATH . '/smtp.php';

// Session Management - START EARLY (before loading functions)
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_secure', 0); // Set to 1 if using HTTPS
    ini_set('session.cookie_samesite', 'Lax');
    session_start();
}

// Load Core Functions (use full path, don't use undefined constant)
$functionFiles = [
    'helpers.php',
    'security.php', 
    'validation.php',
    'session.php',
    'flash.php',
    'redirect.php',
    'auth.php',
    'email.php',
    'commission.php',
    'payment.php',
    'notification.php',
    'tier.php',
    'upload.php'
];

foreach ($functionFiles as $file) {
    $filePath = FUNCTIONS_PATH . '/' . $file;
    if (file_exists($filePath)) {
        try {
            require_once $filePath;
        } catch (Error $e) {
            error_log("Failed to load $file: " . $e->getMessage());
            die("Critical error loading $file: " . $e->getMessage() . "<br>Line: " . $e->getLine() . "<br>File: " . $e->getFile());
        }
    } else {
        die("Missing function file: $file at $filePath");
    }
}

// Fallback functions jika auth.php gagal load
if (!function_exists('isLoggedIn')) {
    function isLoggedIn() {
        return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
    }
}

if (!function_exists('getCurrentUserRole')) {
    function getCurrentUserRole() {
        return $_SESSION['user_role'] ?? null;
    }
}

if (!function_exists('getCurrentUserId')) {
    function getCurrentUserId() {
        return $_SESSION['user_id'] ?? null;
    }
}

// Global Database Connection
global $pdo, $conn;
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );
    
    // Create alias for backward compatibility
    $conn = $pdo;
    
} catch (PDOException $e) {
    error_log("Database connection failed: " . $e->getMessage());
    die("Database connection failed. Please check configuration.");
}

// Security Headers
header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header('X-XSS-Protection: 1; mode=block');
header('Referrer-Policy: strict-origin-when-cross-origin');

// Check if user is banned by IP
if (function_exists('getClientIP')) {
    $clientIP = getClientIP();
} else {
    // Fallback if function not loaded yet
    $clientIP = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
}

// Load additional includes
$additionalIncludes = [
    INCLUDES_PATH . '/services/services-data.php',
    INCLUDES_PATH . '/commission/commission-calculator.php',
    INCLUDES_PATH . '/tier/tier-calculator.php'
];

foreach ($additionalIncludes as $include) {
    if (file_exists($include)) {
        require_once $include;
    }
}
