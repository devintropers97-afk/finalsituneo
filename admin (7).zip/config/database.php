<?php
/**
 * Database Configuration
 * SITUNEO DIGITAL - Production Database Connection
 * 
 * Uses PDO for secure database access with prepared statements
 * Error handling dengan try-catch untuk production safety
 */

// Prevent direct access
if (!defined('ALLOWED')) {
    die('Direct access not permitted');
}

// Database credentials
define('DB_HOST', 'localhost');
define('DB_USER', 'nrrskfvk_user_situneo_digital');
define('DB_PASS', 'Devin1922$');
define('DB_NAME', 'nrrskfvk_situneo_digital');
define('DB_CHARSET', 'utf8mb4');

/**
 * Get Database Connection
 * Returns PDO instance dengan error handling
 * 
 * @return PDO Database connection object
 * @throws PDOException if connection fails
 */
function getDBConnection() {
    static $pdo = null;
    
    if ($pdo === null) {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES " . DB_CHARSET,
                PDO::ATTR_PERSISTENT         => true
            ];
            
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
            
        } catch (PDOException $e) {
            // Log error untuk debugging (jangan tampilkan ke user)
            error_log("Database Connection Error: " . $e->getMessage());
            
            // Show generic error untuk security
            die("Database connection failed. Please contact administrator.");
        }
    }
    
    return $pdo;
}

/**
 * Test Database Connection
 * Untuk installer wizard dan troubleshooting
 * 
 * @return array ['success' => bool, 'message' => string]
 */
function testDBConnection() {
    try {
        $pdo = getDBConnection();
        $stmt = $pdo->query("SELECT 1");
        
        return [
            'success' => true,
            'message' => 'Database connection successful'
        ];
        
    } catch (PDOException $e) {
        return [
            'success' => false,
            'message' => $e->getMessage()
        ];
    }
}

/**
 * Execute Query dengan Error Handling
 * 
 * @param string $sql SQL query dengan placeholders
 * @param array $params Parameters untuk prepared statement
 * @return mixed Query result atau false jika error
 */
function executeQuery($sql, $params = []) {
    try {
        $pdo = getDBConnection();
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        
        return $stmt;
        
    } catch (PDOException $e) {
        error_log("Query Error: " . $e->getMessage());
        error_log("SQL: " . $sql);
        error_log("Params: " . print_r($params, true));
        
        return false;
    }
}

/**
 * Get Single Row
 * 
 * @param string $sql SQL query
 * @param array $params Parameters
 * @return array|false Row data atau false
 */
function getRow($sql, $params = []) {
    $stmt = executeQuery($sql, $params);
    
    if ($stmt === false) {
        return false;
    }
    
    return $stmt->fetch();
}

/**
 * Get Multiple Rows
 * 
 * @param string $sql SQL query
 * @param array $params Parameters
 * @return array Rows data
 */
function getRows($sql, $params = []) {
    $stmt = executeQuery($sql, $params);
    
    if ($stmt === false) {
        return [];
    }
    
    return $stmt->fetchAll();
}

/**
 * Get Last Insert ID
 * 
 * @return string Last inserted ID
 */
function getLastInsertId() {
    $pdo = getDBConnection();
    return $pdo->lastInsertId();
}

/**
 * Begin Transaction
 */
function beginTransaction() {
    $pdo = getDBConnection();
    return $pdo->beginTransaction();
}

/**
 * Commit Transaction
 */
function commit() {
    $pdo = getDBConnection();
    return $pdo->commit();
}

/**
 * Rollback Transaction
 */
function rollback() {
    $pdo = getDBConnection();
    return $pdo->rollBack();
}

/**
 * Check if table exists
 * 
 * @param string $tableName Table name to check
 * @return bool True if exists
 */
function tableExists($tableName) {
    $sql = "SHOW TABLES LIKE :tableName";
    $stmt = executeQuery($sql, ['tableName' => $tableName]);
    
    if ($stmt === false) {
        return false;
    }
    
    return $stmt->rowCount() > 0;
}

// Initialize connection saat file di-include
// Ini akan create persistent connection
if (!defined('SKIP_DB_INIT')) {
    getDBConnection();
}
