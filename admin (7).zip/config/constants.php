<?php
if (!defined('ALLOWED')) { die('Direct access not permitted'); }

// Site Configuration
define('SITE_NAME', 'SITUNEO DIGITAL');
define('SITE_TAGLINE', 'Digital Harmony for a Modern World');
define('SITE_URL', 'https://yourdomain.com'); // CHANGE THIS!
define('SITE_EMAIL', 'info@situneo.my.id');
define('SITE_PHONE', '6281234567890');

// Company Information
define('COMPANY_NIB', '1234567890');
define('COMPANY_NPWP', '12.345.678.9-012.345');
define('COMPANY_DIRECTOR', 'Devin Mulyani');
define('COMPANY_ESTABLISHED', '2024');
define('COMPANY_ADDRESS', 'Jl. Contoh No. 123, Jakarta, Indonesia');

// Tier Configuration
define('TIER_1_MIN_ORDERS', 0);
define('TIER_1_COMMISSION', 30);
define('TIER_2_MIN_ORDERS', 10);
define('TIER_2_COMMISSION', 40);
define('TIER_3_MIN_ORDERS', 25);
define('TIER_3_COMMISSION', 50);
define('TIER_MAX_MIN_ORDERS', 75);
define('TIER_MAX_COMMISSION', 55);

// Security
define('PASSWORD_COST', 12);
define('SESSION_TIMEOUT', 1800); // 30 minutes
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOGIN_ATTEMPT_WINDOW', 900); // 15 minutes
define('IP_BLOCK_ATTEMPTS', 10);
define('IP_BLOCK_DURATION', 86400); // 24 hours

// File Upload
define('MAX_FILE_SIZE', 2097152); // 2MB
define('ALLOWED_IMAGE_TYPES', ['image/jpeg', 'image/png', 'image/jpg']);
define('ALLOWED_DOC_TYPES', ['application/pdf']);
