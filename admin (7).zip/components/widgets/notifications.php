<?php
if (!defined('ALLOWED')) die('Direct access not permitted');
function notificationBell($count = 0) {
    echo '<div class="dropdown">';
    echo '<a class="nav-link position-relative" href="#" data-bs-toggle="dropdown">';
    echo '<i class="bi bi-bell fs-5"></i>';
    if ($count > 0) echo '<span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">' . $count . '</span>';
    echo '</a>';
    echo '<ul class="dropdown-menu dropdown-menu-end" style="min-width: 300px; background: rgba(15,48,87,0.98); border: 1px solid rgba(255,180,0,0.3);">';
    echo '<li><h6 class="dropdown-header text-white">Notifikasi</h6></li>';
    echo '<li><hr class="dropdown-divider" style="border-color: rgba(255,180,0,0.3);"></li>';
    if ($count == 0) {
        echo '<li><p class="dropdown-item text-white-50 text-center">Tidak ada notifikasi</p></li>';
    }
    echo '</ul></div>';
}
?>