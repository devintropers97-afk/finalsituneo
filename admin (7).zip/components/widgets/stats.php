<?php
if (!defined('ALLOWED')) die('Direct access not permitted');
function statsWidget($stats) {
    echo '<div class="row g-4 mb-4">';
    foreach ($stats as $stat) {
        echo '<div class="col-xl-3 col-md-6">';
        statCard($stat['title'], $stat['value'], $stat['icon'], $stat['color'] ?? 'primary', $stat['change'] ?? null);
        echo '</div>';
    }
    echo '</div>';
}
?>