<?php
if (!defined('ALLOWED')) die('Direct access not permitted');
function lineChart($id, $title, $data, $categories) {
    echo '<div class="card" style="background: rgba(15,48,87,0.8); border: 1px solid rgba(255,180,0,0.3);">';
    echo '<div class="card-header bg-transparent border-0"><h5 class="text-white mb-0">' . $title . '</h5></div>';
    echo '<div class="card-body"><div id="' . $id . '"></div></div></div>';
    echo '<script>';
    echo 'var options = {';
    echo 'series: [{name: "' . $title . '", data: ' . json_encode($data) . '}],';
    echo 'chart: {type: "line", height: 350, background: "transparent", toolbar: {show: false}},';
    echo 'xaxis: {categories: ' . json_encode($categories) . ', labels: {style: {colors: "#fff"}}},';
    echo 'yaxis: {labels: {style: {colors: "#fff"}}},';
    echo 'stroke: {curve: "smooth", width: 3, colors: ["#FFD700"]},';
    echo 'grid: {borderColor: "rgba(255,180,0,0.1)"},';
    echo 'tooltip: {theme: "dark"}};';
    echo 'var chart = new ApexCharts(document.querySelector("#' . $id . '"), options);';
    echo 'chart.render();';
    echo '</script>';
}
?>