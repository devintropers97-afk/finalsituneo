<?php
if (!defined('ALLOWED')) die('Direct access not permitted');
function modal($id, $title, $body, $footer = '') {
    echo '<div class="modal fade" id="' . $id . '" tabindex="-1">';
    echo '<div class="modal-dialog modal-dialog-centered">';
    echo '<div class="modal-content" style="background: rgba(15,48,87,0.98); border: 1px solid rgba(255,180,0,0.3);">';
    echo '<div class="modal-header border-bottom" style="border-color: rgba(255,180,0,0.3)!important;">';
    echo '<h5 class="modal-title text-white">' . $title . '</h5>';
    echo '<button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>';
    echo '</div>';
    echo '<div class="modal-body text-white">' . $body . '</div>';
    if ($footer) echo '<div class="modal-footer border-top" style="border-color: rgba(255,180,0,0.3)!important;">' . $footer . '</div>';
    echo '</div></div></div>';
}
function confirmModal($id, $title, $message, $action) {
    $body = '<p>' . $message . '</p>';
    $footer = '<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>';
    $footer .= '<button type="button" class="btn btn-danger" onclick="' . $action . '">Konfirmasi</button>';
    modal($id, $title, $body, $footer);
}
?>