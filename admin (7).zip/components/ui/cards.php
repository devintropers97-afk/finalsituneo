<?php
if (!defined('ALLOWED')) die('Direct access not permitted');
function statCard($title, $value, $icon, $color = 'primary', $change = null) {
    echo '<div class="card h-100" style="background: rgba(15,48,87,0.8); border: 1px solid rgba(255,180,0,0.3); backdrop-filter: blur(10px);">';
    echo '<div class="card-body">';
    echo '<div class="d-flex justify-content-between align-items-start mb-3">';
    echo '<div><p class="text-white-50 small mb-1">' . $title . '</p>';
    echo '<h3 class="text-white fw-bold mb-0">' . $value . '</h3></div>';
    echo '<div class="p-3 rounded" style="background: linear-gradient(135deg, #FFD700 0%, #FFB400 100%);"><i class="bi bi-' . $icon . ' fs-4 text-dark"></i></div>';
    echo '</div>';
    if ($change) echo '<p class="text-' . ($change > 0 ? 'success' : 'danger') . ' small mb-0"><i class="bi bi-' . ($change > 0 ? 'arrow-up' : 'arrow-down') . '"></i> ' . abs($change) . '%</p>';
    echo '</div></div>';
}
function infoCard($title, $content, $icon = null) {
    echo '<div class="card" style="background: rgba(15,48,87,0.8); border: 1px solid rgba(255,180,0,0.3);">';
    echo '<div class="card-body">';
    if ($icon) echo '<i class="bi bi-' . $icon . ' fs-3 text-warning mb-3"></i>';
    echo '<h5 class="card-title text-white">' . $title . '</h5>';
    echo '<div class="card-text text-white-50">' . $content . '</div>';
    echo '</div></div>';
}
?>