<?php
if (!defined('ALLOWED')) die('Direct access not permitted');
function alert($type, $message, $dismissible = true) {
    $icons = ['success' => 'check-circle-fill', 'danger' => 'exclamation-triangle-fill', 'warning' => 'exclamation-circle-fill', 'info' => 'info-circle-fill'];
    $icon = $icons[$type] ?? 'info-circle-fill';
    echo '<div class="alert alert-' . $type . ($dismissible ? ' alert-dismissible fade show' : '') . '" role="alert">';
    echo '<i class="bi bi-' . $icon . ' me-2"></i>' . $message;
    if ($dismissible) echo '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>';
    echo '</div>';
}
function showFlash() { $flash = getFlashMessage(); if ($flash) alert($flash['type'], $flash['message']); }
?>