<?php
if (!defined('ALLOWED')) die('Direct access not permitted');
function textInput($name, $label, $value = '', $required = false, $placeholder = '') {
    echo '<div class="mb-3">';
    echo '<label class="form-label text-white">' . $label . ($required ? ' <span class="text-danger">*</span>' : '') . '</label>';
    echo '<input type="text" name="' . $name . '" class="form-control" style="background: rgba(255,255,255,0.1); border: 1px solid rgba(255,180,0,0.3); color: white;" value="' . htmlspecialchars($value) . '" placeholder="' . $placeholder . '" ' . ($required ? 'required' : '') . '>';
    echo '</div>';
}
function selectInput($name, $label, $options, $selected = '', $required = false) {
    echo '<div class="mb-3">';
    echo '<label class="form-label text-white">' . $label . ($required ? ' <span class="text-danger">*</span>' : '') . '</label>';
    echo '<select name="' . $name . '" class="form-select" style="background: rgba(255,255,255,0.1); border: 1px solid rgba(255,180,0,0.3); color: white;" ' . ($required ? 'required' : '') . '>';
    foreach ($options as $value => $text) {
        echo '<option value="' . $value . '" ' . ($value == $selected ? 'selected' : '') . '>' . $text . '</option>';
    }
    echo '</select></div>';
}
function submitButton($text = 'Submit', $class = 'btn-primary') {
    echo '<button type="submit" class="btn ' . $class . '" style="background: linear-gradient(135deg, #FFD700 0%, #FFB400 100%); border: none; color: #0F3057; font-weight: 600; padding: 0.75rem 2rem; border-radius: 10px;">' . $text . '</button>';
}
?>