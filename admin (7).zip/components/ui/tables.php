<?php
if (!defined('ALLOWED')) die('Direct access not permitted');
function dataTable($headers, $data, $actions = null) {
    echo '<div class="table-responsive">';
    echo '<table class="table table-dark table-hover">';
    echo '<thead style="background: rgba(255,180,0,0.1);"><tr>';
    foreach ($headers as $h) echo '<th>' . $h . '</th>';
    if ($actions) echo '<th>Actions</th>';
    echo '</tr></thead><tbody>';
    foreach ($data as $row) {
        echo '<tr>';
        foreach ($row as $cell) echo '<td>' . $cell . '</td>';
        if ($actions && isset($row['id'])) echo '<td>' . $actions($row['id']) . '</td>';
        echo '</tr>';
    }
    echo '</tbody></table></div>';
}
?>