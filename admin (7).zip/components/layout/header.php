<?php
/**
 * Header Component - BATCH 2
 * Responsive navigation with role-based menu
 */

if (!defined('ALLOWED')) die('Direct access not permitted');

$currentPage = basename($_SERVER['PHP_SELF'], '.php');
$currentRole = getCurrentUserRole() ?? 'guest';
$isLoggedIn = isLoggedIn();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle ?? 'Dashboard'; ?> - <?php echo SITE_NAME; ?></title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800;900&family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
    <?php if ($currentRole === 'admin'): ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/apexcharts@3.45.1/dist/apexcharts.css">
    <?php endif; ?>
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/global.css">
    <?php if (isset($additionalCSS)): foreach ($additionalCSS as $css): ?>
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/<?php echo $css; ?>.css">
    <?php endforeach; endif; ?>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark sticky-top" style="background: rgba(15,48,87,0.95)!important; backdrop-filter: blur(20px); box-shadow: 0 4px 30px rgba(0,0,0,0.3); border-bottom: 1px solid rgba(255,180,0,0.3);">
    <div class="container-fluid px-4">
        <a class="navbar-brand fw-bold" href="<?php echo SITE_URL; ?>" style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 1.5rem; background: linear-gradient(135deg, #FFD700 0%, #FFB400 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
            <i class="bi bi-circle-fill me-2" style="font-size: 0.5rem; color: #FFB400;"></i><?php echo SITE_NAME; ?>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav mx-auto">
                <?php if (!$isLoggedIn): ?>
                <li class="nav-item"><a class="nav-link" href="<?php echo SITE_URL; ?>"><i class="bi bi-house-door me-1"></i> Home</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo SITE_URL; ?>/pages/public/services.php"><i class="bi bi-grid-3x3-gap me-1"></i> Layanan</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo SITE_URL; ?>/pages/public/about.php"><i class="bi bi-info-circle me-1"></i> Tentang</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo SITE_URL; ?>/pages/public/contact.php"><i class="bi bi-envelope me-1"></i> Kontak</a></li>
                <?php else: ?>
                <li class="nav-item"><a class="nav-link" href="<?php echo getDashboardUrl($currentRole); ?>"><i class="bi bi-speedometer2 me-1"></i> Dashboard</a></li>
                <?php endif; ?>
            </ul>
            <ul class="navbar-nav">
                <?php if ($isLoggedIn): ?>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
                        <i class="bi bi-person-circle me-1"></i> <?php echo $_SESSION['user_name'] ?? 'User'; ?>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="<?php echo SITE_URL; ?>/pages/user/profile.php"><i class="bi bi-person me-2"></i> Profile</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item text-danger" href="<?php echo SITE_URL; ?>/api/auth/logout.php"><i class="bi bi-box-arrow-right me-2"></i> Logout</a></li>
                    </ul>
                </li>
                <?php else: ?>
                <li class="nav-item"><a class="nav-link" href="<?php echo SITE_URL; ?>/pages/auth/login.php">Login</a></li>
                <li class="nav-item"><a class="btn btn-sm ms-2" style="background: linear-gradient(135deg, #FFD700 0%, #FFB400 100%); border: none; color: #0F3057; font-weight: 600; padding: 0.5rem 1.5rem; border-radius: 10px;" href="<?php echo SITE_URL; ?>/pages/auth/register.php">Register</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
<div class="content-wrapper">
