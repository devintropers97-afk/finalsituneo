<?php
if (!defined('ALLOWED')) die('Direct access not permitted');
?>
</div>
<footer class="mt-5" style="background: rgba(15,48,87,0.95); backdrop-filter: blur(20px); border-top: 1px solid rgba(255,180,0,0.3);">
    <div class="container py-4">
        <div class="row">
            <div class="col-md-6 text-center text-md-start">
                <p class="text-white-50 small mb-0">&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?>. All rights reserved.</p>
            </div>
            <div class="col-md-6 text-center text-md-end">
                <p class="text-white-50 small mb-0">NIB: <?php echo COMPANY_NIB; ?> | NPWP: <?php echo COMPANY_NPWP; ?></p>
            </div>
        </div>
    </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<?php if (getCurrentUserRole() === 'admin'): ?>
<script src="https://cdn.jsdelivr.net/npm/apexcharts@3.45.1/dist/apexcharts.min.js"></script>
<?php endif; ?>
<script src="<?php echo SITE_URL; ?>/assets/js/main.js"></script>
</body>
</html>
