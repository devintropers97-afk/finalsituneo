<?php
if (!defined('ALLOWED')) die('Direct access not permitted');
function getBreadcrumbs() {
    $path = $_SERVER['REQUEST_URI'];
    $parts = explode('/', trim($path, '/'));
    $breadcrumbs = ['<a href="' . SITE_URL . '">Home</a>'];
    $current = SITE_URL;
    foreach ($parts as $part) {
        if (empty($part) || $part === 'index.php') continue;
        $current .= '/' . $part;
        $label = ucwords(str_replace(['-', '_', '.php'], [' ', ' ', ''], $part));
        $breadcrumbs[] = '<a href="' . $current . '">' . $label . '</a>';
    }
    return implode(' <i class="bi bi-chevron-right mx-2"></i> ', $breadcrumbs);
}
?>
<nav aria-label="breadcrumb" class="mb-4">
    <ol class="breadcrumb">
        <?php echo getBreadcrumbs(); ?>
    </ol>
</nav>
