<?php
if (!defined('ALLOWED')) die('Direct access not permitted');
$currentPage = basename($_SERVER['PHP_SELF'], '.php');
?>
<div class="sidebar" id="adminSidebar" style="position: fixed; left: 0; top: 0; width: 260px; height: 100vh; background: rgba(15,48,87,0.98); border-right: 1px solid rgba(255,180,0,0.3); z-index: 1000; overflow-y: auto;">
    <div class="p-4 border-bottom" style="border-color: rgba(255,180,0,0.3)!important;">
        <h5 class="text-white fw-bold mb-0"><i class="bi bi-shield-check me-2 text-warning"></i>Admin Panel</h5>
    </div>
    <div class="p-3">
        <a href="<?php echo SITE_URL; ?>/admin/dashboard.php" class="d-block text-decoration-none text-white-50 p-3 rounded mb-2 <?php echo $currentPage === 'dashboard' ? 'bg-warning bg-opacity-10 text-warning' : ''; ?>"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
        <a href="<?php echo SITE_URL; ?>/admin/users/" class="d-block text-decoration-none text-white-50 p-3 rounded mb-2"><i class="bi bi-people me-2"></i> Users</a>
        <a href="<?php echo SITE_URL; ?>/admin/orders/" class="d-block text-decoration-none text-white-50 p-3 rounded mb-2"><i class="bi bi-cart me-2"></i> Orders</a>
        <a href="<?php echo SITE_URL; ?>/admin/payments/" class="d-block text-decoration-none text-white-50 p-3 rounded mb-2"><i class="bi bi-credit-card me-2"></i> Payments</a>
        <a href="<?php echo SITE_URL; ?>/admin/commissions/" class="d-block text-decoration-none text-white-50 p-3 rounded mb-2"><i class="bi bi-currency-dollar me-2"></i> Commissions</a>
        <a href="<?php echo SITE_URL; ?>/admin/withdrawals/" class="d-block text-decoration-none text-white-50 p-3 rounded mb-2"><i class="bi bi-wallet2 me-2"></i> Withdrawals</a>
        <a href="<?php echo SITE_URL; ?>/admin/services/" class="d-block text-decoration-none text-white-50 p-3 rounded mb-2"><i class="bi bi-grid me-2"></i> Services</a>
        <a href="<?php echo SITE_URL; ?>/admin/reports/" class="d-block text-decoration-none text-white-50 p-3 rounded mb-2"><i class="bi bi-graph-up me-2"></i> Reports</a>
        <a href="<?php echo SITE_URL; ?>/admin/settings/" class="d-block text-decoration-none text-white-50 p-3 rounded mb-2"><i class="bi bi-gear me-2"></i> Settings</a>
    </div>
</div>
<div style="margin-left: 260px;">
