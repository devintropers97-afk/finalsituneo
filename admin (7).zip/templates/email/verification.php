<?php
function getVerificationEmailHTML($userName, $verificationLink) {
    return <<<HTML
<!DOCTYPE html>
<html><body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
<div style="background: linear-gradient(135deg, #1E5C99 0%, #0F3057 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
    <h1 style="margin: 0; font-size: 28px;">SITUNEO DIGITAL</h1>
    <p style="margin: 10px 0 0; font-size: 14px; opacity: 0.9;">Digital Harmony for a Modern World</p>
</div>
<div style="background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px;">
    <h2 style="color: #1E5C99; margin-top: 0;">Hi, $userName!</h2>
    <p>Terima kasih telah mendaftar di SITUNEO DIGITAL. Silakan verifikasi email Anda dengan klik tombol di bawah:</p>
    <div style="text-align: center; margin: 30px 0;">
        <a href="$verificationLink" style="background: linear-gradient(135deg, #FFD700 0%, #FFB400 100%); color: #0F3057; padding: 15px 40px; text-decoration: none; border-radius: 10px; font-weight: 600; display: inline-block;">Verifikasi Email</a>
    </div>
    <p style="color: #666; font-size: 14px;">Atau copy link berikut ke browser Anda:</p>
    <p style="color: #1E5C99; word-break: break-all; font-size: 12px;">$verificationLink</p>
    <hr style="border: none; border-top: 1px solid #ddd; margin: 30px 0;">
    <p style="color: #999; font-size: 12px; text-align: center;">© 2025 SITUNEO DIGITAL. All rights reserved.</p>
</div>
</body></html>
HTML;
}
?>
