<?php
function getWelcomeEmailHTML($userName, $role) {
    return <<<HTML
<!DOCTYPE html>
<html><body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
<div style="background: linear-gradient(135deg, #1E5C99 0%, #0F3057 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
    <h1 style="margin: 0; font-size: 28px;">Selamat Datang!</h1>
</div>
<div style="background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px;">
    <h2 style="color: #1E5C99;">Hi, $userName!</h2>
    <p>Selamat bergabung dengan SITUNEO DIGITAL sebagai <strong>$role</strong>.</p>
    <p>Anda sekarang dapat mengakses dashboard dan menikmati layanan kami.</p>
    <div style="text-align: center; margin: 30px 0;">
        <a href="https://yoursite.com/pages/auth/login.php" style="background: linear-gradient(135deg, #FFD700 0%, #FFB400 100%); color: #0F3057; padding: 15px 40px; text-decoration: none; border-radius: 10px; font-weight: 600; display: inline-block;">Login Sekarang</a>
    </div>
</div>
</body></html>
HTML;
}
?>
