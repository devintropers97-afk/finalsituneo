<?php
function getCommissionEarnedEmailHTML($userName, $amount, $orderNumber, $tier) {
    return <<<HTML
<!DOCTYPE html>
<html><body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
<div style="background: linear-gradient(135deg, #FFD700 0%, #FFB400 100%); color: #0F3057; padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
    <h1 style="margin: 0; font-size: 28px;">💰 Komisi Baru!</h1>
</div>
<div style="background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px;">
    <h2 style="color: #1E5C99;">Hi, $userName!</h2>
    <p>Selamat! Anda mendapatkan komisi baru:</p>
    <div style="text-align: center; margin: 30px 0; padding: 20px; background: white; border-radius: 10px; border: 2px solid #FFD700;">
        <h1 style="color: #1E5C99; margin: 0;">$amount</h1>
        <p style="color: #666; margin: 10px 0 0;">Dari order #$orderNumber</p>
    </div>
    <p>Tier Anda saat ini: <strong>$tier</strong></p>
    <p>Komisi dapat ditarik setelah disetujui oleh admin.</p>
</div>
</body></html>
HTML;
}
?>
