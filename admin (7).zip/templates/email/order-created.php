<?php
function getOrderCreatedEmailHTML($userName, $orderNumber, $serviceName, $amount) {
    return <<<HTML
<!DOCTYPE html>
<html><body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
<div style="background: linear-gradient(135deg, #1E5C99 0%, #0F3057 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
    <h1 style="margin: 0; font-size: 28px;">Order Berhasil Dibuat</h1>
</div>
<div style="background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px;">
    <h2 style="color: #1E5C99;">Hi, $userName!</h2>
    <p>Order Anda telah berhasil dibuat dengan detail:</p>
    <table style="width: 100%; margin: 20px 0; border-collapse: collapse;">
        <tr><td style="padding: 10px; border-bottom: 1px solid #ddd;"><strong>Order Number:</strong></td><td style="padding: 10px; border-bottom: 1px solid #ddd;">$orderNumber</td></tr>
        <tr><td style="padding: 10px; border-bottom: 1px solid #ddd;"><strong>Service:</strong></td><td style="padding: 10px; border-bottom: 1px solid #ddd;">$serviceName</td></tr>
        <tr><td style="padding: 10px; border-bottom: 1px solid #ddd;"><strong>Amount:</strong></td><td style="padding: 10px; border-bottom: 1px solid #ddd;">$amount</td></tr>
    </table>
    <p>Silakan upload bukti pembayaran melalui dashboard Anda.</p>
</div>
</body></html>
HTML;
}
?>
