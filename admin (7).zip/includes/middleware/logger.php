<?php
if (!defined('ALLOWED')) die('Direct access not permitted');
function logActivity($userId, $action, $description) {
    global $pdo;
    try {
        $stmt = $pdo->prepare("INSERT INTO activity_logs (user_id, action, description, ip_address, created_at) VALUES (?, ?, ?, ?, NOW())");
        $stmt->execute([$userId, $action, $description, getUserIP()]);
    } catch (PDOException $e) {
        error_log("Log activity failed: " . $e->getMessage());
    }
}
?>