<?php
if (!defined('ALLOWED')) die('Direct access not permitted');
function requireAuth() {
    if (!validateSession()) {
        header('Location: ' . SITE_URL . '/pages/auth/login.php');
        exit;
    }
}
function requireRole($role) {
    requireAuth();
    if (getCurrentUserRole() !== $role) {
        header('Location: ' . SITE_URL . '/pages/errors/403.php');
        exit;
    }
}
function requireAdmin() { requireRole('admin'); }
function requireClient() { requireRole('client'); }
function requireFreelancer() { requireRole('freelancer'); }
?>