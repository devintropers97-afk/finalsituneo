<?php
if (!defined('ALLOWED')) die('Direct access not permitted');
function checkRateLimit($action, $max_attempts = 5, $window = 900) {
    $ip = getUserIP();
    $key = "rate_limit:{$action}:{$ip}";
    
    if (!isset($_SESSION[$key])) {
        $_SESSION[$key] = ['count' => 1, 'start' => time()];
        return true;
    }
    
    $data = $_SESSION[$key];
    $elapsed = time() - $data['start'];
    
    if ($elapsed > $window) {
        $_SESSION[$key] = ['count' => 1, 'start' => time()];
        return true;
    }
    
    if ($data['count'] >= $max_attempts) {
        return false;
    }
    
    $_SESSION[$key]['count']++;
    return true;
}
?>