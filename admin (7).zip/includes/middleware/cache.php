<?php
if (!defined('ALLOWED')) die('Direct access not permitted');
function setCacheHeaders($seconds = 3600) {
    header('Cache-Control: max-age=' . $seconds . ', public');
    header('Expires: ' . gmdate('D, d M Y H:i:s', time() + $seconds) . ' GMT');
}
function setNoCacheHeaders() {
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    header('Expires: 0');
}
?>