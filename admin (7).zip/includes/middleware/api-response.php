<?php
if (!defined('ALLOWED')) die('Direct access not permitted');
function jsonResponse($data, $status = 200) {
    http_response_code($status);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}
function successResponse($message, $data = null) {
    jsonResponse(['success' => true, 'message' => $message, 'data' => $data]);
}
function errorResponse($message, $status = 400) {
    jsonResponse(['success' => false, 'message' => $message], $status);
}
?>