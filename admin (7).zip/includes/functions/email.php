<?php
/**
 * Email Functions
 * All email-related functions including sendVerificationEmail
 */

if (!defined('ALLOWED')) {
    die('Direct access not permitted');
}

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

/**
 * Send verification email
 */
function sendVerificationEmail($to, $name, $token) {
    $subject = EMAIL_VERIFICATION_SUBJECT;
    $verificationUrl = BASE_URL . '/verify-email.php?token=' . $token;
    
    $body = getEmailTemplate('verification', [
        'name' => $name,
        'verification_url' => $verificationUrl,
        'company_name' => COMPANY_NAME
    ]);
    
    return sendEmail($to, $subject, $body);
}

/**
 * Send password reset email
 */
function sendPasswordResetEmail($to, $name, $token) {
    $subject = EMAIL_PASSWORD_RESET_SUBJECT;
    $resetUrl = BASE_URL . '/reset-password.php?token=' . $token;
    
    $body = getEmailTemplate('password_reset', [
        'name' => $name,
        'reset_url' => $resetUrl,
        'company_name' => COMPANY_NAME
    ]);
    
    return sendEmail($to, $subject, $body);
}

/**
 * Send welcome email
 */
function sendWelcomeEmail($to, $name) {
    $subject = EMAIL_WELCOME_SUBJECT;
    
    $body = getEmailTemplate('welcome', [
        'name' => $name,
        'company_name' => COMPANY_NAME,
        'dashboard_url' => BASE_URL . '/dashboard'
    ]);
    
    return sendEmail($to, $subject, $body);
}

/**
 * Send notification email
 */
function sendNotificationEmail($to, $name, $message) {
    $subject = EMAIL_NOTIFICATION_SUBJECT;
    
    $body = getEmailTemplate('notification', [
        'name' => $name,
        'message' => $message,
        'company_name' => COMPANY_NAME
    ]);
    
    return sendEmail($to, $subject, $body);
}

/**
 * Main email sending function using PHPMailer
 */
function sendEmail($to, $subject, $body, $attachments = []) {
    // Check if PHPMailer is available
    if (!class_exists('PHPMailer\PHPMailer\PHPMailer')) {
        // Fallback to native PHP mail() if PHPMailer not available
        return sendEmailNative($to, $subject, $body);
    }
    
    $mail = new PHPMailer(true);
    
    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host = SMTP_HOST;
        $mail->SMTPAuth = true;
        $mail->Username = SMTP_USERNAME;
        $mail->Password = SMTP_PASSWORD;
        $mail->SMTPSecure = SMTP_SECURE;
        $mail->Port = SMTP_PORT;
        
        // Recipients
        $mail->setFrom(SMTP_FROM_EMAIL, SMTP_FROM_NAME);
        $mail->addAddress($to);
        $mail->addReplyTo(COMPANY_EMAIL_SUPPORT, COMPANY_NAME);
        
        // Attachments
        if (!empty($attachments)) {
            foreach ($attachments as $attachment) {
                $mail->addAttachment($attachment);
            }
        }
        
        // Content
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $body;
        $mail->AltBody = strip_tags($body);
        
        // Send email
        $mail->send();
        
        logEmail($to, $subject, 'success');
        return true;
        
    } catch (Exception $e) {
        logEmail($to, $subject, 'failed', $mail->ErrorInfo);
        return false;
    }
}

/**
 * Fallback email sending using native PHP mail()
 */
function sendEmailNative($to, $subject, $body) {
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: " . SMTP_FROM_NAME . " <" . SMTP_FROM_EMAIL . ">" . "\r\n";
    $headers .= "Reply-To: " . COMPANY_EMAIL_SUPPORT . "\r\n";
    
    if (mail($to, $subject, $body, $headers)) {
        logEmail($to, $subject, 'success');
        return true;
    }
    
    logEmail($to, $subject, 'failed');
    return false;
}

/**
 * Get email template
 */
function getEmailTemplate($type, $variables = []) {
    $templateFile = INCLUDES_PATH . '/templates/email/' . $type . '.php';
    
    // If template file exists, use it
    if (file_exists($templateFile)) {
        ob_start();
        extract($variables);
        include $templateFile;
        return ob_get_clean();
    }
    
    // Otherwise use default template
    return getDefaultEmailTemplate($type, $variables);
}

/**
 * Get default email template
 */
function getDefaultEmailTemplate($type, $variables) {
    $name = $variables['name'] ?? 'User';
    $companyName = $variables['company_name'] ?? COMPANY_NAME;
    
    $header = getEmailHeader($companyName);
    $footer = getEmailFooter($companyName);
    
    $content = '';
    
    switch ($type) {
        case 'verification':
            $verificationUrl = $variables['verification_url'] ?? '#';
            $content = "
                <h2>Welcome to {$companyName}!</h2>
                <p>Hi {$name},</p>
                <p>Thank you for registering with us. Please verify your email address by clicking the button below:</p>
                <p style='text-align: center; margin: 30px 0;'>
                    <a href='{$verificationUrl}' style='background-color: #4CAF50; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; display: inline-block;'>
                        Verify Email Address
                    </a>
                </p>
                <p>If the button doesn't work, copy and paste this link into your browser:</p>
                <p style='word-break: break-all;'>{$verificationUrl}</p>
                <p>This link will expire in 24 hours.</p>
            ";
            break;
            
        case 'password_reset':
            $resetUrl = $variables['reset_url'] ?? '#';
            $content = "
                <h2>Password Reset Request</h2>
                <p>Hi {$name},</p>
                <p>We received a request to reset your password. Click the button below to create a new password:</p>
                <p style='text-align: center; margin: 30px 0;'>
                    <a href='{$resetUrl}' style='background-color: #2196F3; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; display: inline-block;'>
                        Reset Password
                    </a>
                </p>
                <p>If the button doesn't work, copy and paste this link into your browser:</p>
                <p style='word-break: break-all;'>{$resetUrl}</p>
                <p>If you didn't request this, please ignore this email. Your password will remain unchanged.</p>
                <p>This link will expire in 1 hour.</p>
            ";
            break;
            
        case 'welcome':
            $dashboardUrl = $variables['dashboard_url'] ?? BASE_URL . '/dashboard';
            $content = "
                <h2>Welcome to {$companyName}!</h2>
                <p>Hi {$name},</p>
                <p>Your email has been verified successfully. Welcome aboard!</p>
                <p>You can now access all features of your account. Get started by visiting your dashboard:</p>
                <p style='text-align: center; margin: 30px 0;'>
                    <a href='{$dashboardUrl}' style='background-color: #4CAF50; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; display: inline-block;'>
                        Go to Dashboard
                    </a>
                </p>
                <p>If you have any questions, feel free to contact our support team.</p>
            ";
            break;
            
        case 'notification':
            $message = $variables['message'] ?? 'You have a new notification.';
            $content = "
                <h2>New Notification</h2>
                <p>Hi {$name},</p>
                <p>{$message}</p>
                <p>Login to your account to view more details.</p>
            ";
            break;
            
        default:
            $content = "
                <h2>Message from {$companyName}</h2>
                <p>Hi {$name},</p>
                <p>You have received a message from {$companyName}.</p>
            ";
    }
    
    return $header . $content . $footer;
}

/**
 * Get email header HTML
 */
function getEmailHeader($companyName) {
    return "
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset='UTF-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <title>{$companyName}</title>
    </head>
    <body style='font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;'>
        <div style='background-color: #f4f4f4; padding: 20px; border-radius: 5px;'>
            <div style='background-color: white; padding: 30px; border-radius: 5px;'>
    ";
}

/**
 * Get email footer HTML
 */
function getEmailFooter($companyName) {
    $year = date('Y');
    $supportUrl = EMAIL_SUPPORT_URL ?? '#';
    
    return "
            </div>
            <div style='text-align: center; margin-top: 20px; color: #777; font-size: 12px;'>
                <p>© {$year} {$companyName}. All rights reserved.</p>
                <p>
                    <a href='{$supportUrl}' style='color: #777;'>Contact Support</a>
                </p>
            </div>
        </div>
    </body>
    </html>
    ";
}

/**
 * Log email activity
 */
function logEmail($to, $subject, $status, $error = null) {
    global $conn;
    
    if (!isset($conn) || !$conn) {
        return;
    }
    
    $to = escapeString($to);
    $subject = escapeString($subject);
    $status = escapeString($status);
    $error = $error ? escapeString($error) : null;
    $userId = getCurrentUserId();
    
    $query = "INSERT INTO email_logs (user_id, recipient, subject, status, error_message, sent_at) 
              VALUES (" . ($userId ? "'$userId'" : "NULL") . ", '$to', '$subject', '$status', " . 
              ($error ? "'$error'" : "NULL") . ", NOW())";
    
    mysqli_query($conn, $query);
}

/**
 * Queue email for later sending
 */
function queueEmail($to, $subject, $body, $priority = 'normal') {
    global $conn;
    
    if (!isset($conn) || !$conn) {
        return false;
    }
    
    $to = escapeString($to);
    $subject = escapeString($subject);
    $body = escapeString($body);
    $priority = escapeString($priority);
    
    $query = "INSERT INTO email_queue (recipient, subject, body, priority, created_at) 
              VALUES ('$to', '$subject', '$body', '$priority', NOW())";
    
    return mysqli_query($conn, $query);
}

/**
 * Process email queue
 */
function processEmailQueue($limit = 10) {
    global $conn;
    
    if (!isset($conn) || !$conn) {
        return 0;
    }
    
    $query = "SELECT * FROM email_queue 
              WHERE status = 'pending' 
              ORDER BY priority DESC, created_at ASC 
              LIMIT $limit";
    
    $result = mysqli_query($conn, $query);
    
    if (!$result) {
        return 0;
    }
    
    $processed = 0;
    
    while ($email = mysqli_fetch_assoc($result)) {
        $success = sendEmail($email['recipient'], $email['subject'], $email['body']);
        
        $status = $success ? 'sent' : 'failed';
        $updateQuery = "UPDATE email_queue 
                       SET status = '$status', processed_at = NOW() 
                       WHERE id = '{$email['id']}'";
        
        mysqli_query($conn, $updateQuery);
        $processed++;
    }
    
    return $processed;
}
