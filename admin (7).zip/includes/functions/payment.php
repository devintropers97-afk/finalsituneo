<?php
if (!defined('ALLOWED')) die('Direct access not permitted');

function createPayment($orderId, $amount, $method, $bankName, $accountNumber) {
    $sql = "INSERT INTO payments (order_id, amount, method, bank_name, account_number, created_at) 
            VALUES (:order_id, :amount, :method, :bank, :account, NOW())";
    
    return executeQuery($sql, [
        'order_id' => $orderId,
        'amount' => $amount,
        'method' => $method,
        'bank' => $bankName,
        'account' => $accountNumber
    ]);
}

function uploadPaymentProof($paymentId, $file) {
    $validation = validateImageUpload($file);
    
    if (!$validation['valid']) {
        return ['success' => false, 'message' => $validation['error']];
    }
    
    $uploadResult = uploadFile($file, UPLOADS_PAYMENTS_PATH, 'payment_' . $paymentId);
    
    if (!$uploadResult['success']) {
        return $uploadResult;
    }
    
    $sql = "UPDATE payments SET proof_image = :filename WHERE id = :id";
    executeQuery($sql, ['filename' => $uploadResult['filename'], 'id' => $paymentId]);
    
    $sql = "UPDATE orders SET payment_status = 'pending' WHERE id = (SELECT order_id FROM payments WHERE id = :id)";
    executeQuery($sql, ['id' => $paymentId]);
    
    return ['success' => true, 'message' => 'Bukti pembayaran berhasil diupload', 'filename' => $uploadResult['filename']];
}

function verifyPayment($paymentId, $adminId) {
    beginTransaction();
    
    try {
        $sql = "UPDATE payments SET verified_at = NOW(), verified_by = :admin_id WHERE id = :id";
        executeQuery($sql, ['admin_id' => $adminId, 'id' => $paymentId]);
        
        $payment = getRow("SELECT * FROM payments WHERE id = :id", ['id' => $paymentId]);
        $orderId = $payment['order_id'];
        
        $sql = "UPDATE orders SET payment_status = 'verified', status = 'processing' WHERE id = :id";
        executeQuery($sql, ['id' => $orderId]);
        
        $order = getRow("SELECT * FROM orders WHERE id = :id", ['id' => $orderId]);
        
        if ($order['freelancer_id']) {
            calculateCommission($orderId, $order['freelancer_id'], $order['total_amount']);
        }
        
        commit();
        return ['success' => true, 'message' => 'Pembayaran berhasil diverifikasi'];
    } catch (Exception $e) {
        rollback();
        return ['success' => false, 'message' => 'Gagal memverifikasi pembayaran'];
    }
}

function rejectPayment($paymentId, $reason) {
    $sql = "UPDATE payments SET status = 'rejected' WHERE id = :id";
    executeQuery($sql, ['id' => $paymentId]);
    
    $sql = "UPDATE orders SET payment_status = 'rejected' WHERE id = (SELECT order_id FROM payments WHERE id = :id)";
    executeQuery($sql, ['id' => $paymentId]);
    
    return ['success' => true, 'message' => 'Pembayaran ditolak'];
}
