<?php
if (!defined('ALLOWED')) die('Direct access not permitted');

function createNotification($userId, $type, $title, $message) {
    $sql = "INSERT INTO notifications (user_id, type, title, message, created_at) 
            VALUES (:user_id, :type, :title, :message, NOW())";
    
    return executeQuery($sql, [
        'user_id' => $userId,
        'type' => $type,
        'title' => $title,
        'message' => $message
    ]);
}

function getUserNotifications($userId, $limit = 10) {
    $sql = "SELECT * FROM notifications WHERE user_id = :user_id ORDER BY created_at DESC LIMIT :limit";
    
    $pdo = getDBConnection();
    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(':user_id', $userId, PDO::PARAM_INT);
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->execute();
    
    return $stmt->fetchAll();
}

function getUnreadNotificationCount($userId) {
    $sql = "SELECT COUNT(*) as count FROM notifications WHERE user_id = :user_id AND read_at IS NULL";
    $result = getRow($sql, ['user_id' => $userId]);
    return $result['count'] ?? 0;
}

function markNotificationAsRead($notificationId) {
    $sql = "UPDATE notifications SET read_at = NOW() WHERE id = :id";
    return executeQuery($sql, ['id' => $notificationId]);
}

function markAllNotificationsAsRead($userId) {
    $sql = "UPDATE notifications SET read_at = NOW() WHERE user_id = :user_id AND read_at IS NULL";
    return executeQuery($sql, ['user_id' => $userId]);
}
