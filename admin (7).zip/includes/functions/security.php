<?php
/**
 * Security Functions
 * Note: getUserIP() has been REMOVED from this file
 * It's already defined in helpers.php
 */

if (!defined('ALLOWED')) {
    die('Direct access not permitted');
}

/**
 * Sanitize input data
 */
function sanitizeInput($data) {
    if (is_array($data)) {
        return array_map('sanitizeInput', $data);
    }
    
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    
    return $data;
}

/**
 * Generate CSRF token
 */
function generateCSRFToken() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Verify CSRF token
 */
function verifyCSRFToken($token) {
    if (!isset($_SESSION['csrf_token'])) {
        return false;
    }
    return hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Generate secure random token
 */
function generateSecureToken($length = 32) {
    return bin2hex(random_bytes($length));
}

/**
 * Hash password
 */
function hashPassword($password) {
    return password_hash($password, PASSWORD_DEFAULT);
}

/**
 * Verify password
 */
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

/**
 * Check if password needs rehashing
 */
function passwordNeedsRehash($hash) {
    return password_needs_rehash($hash, PASSWORD_DEFAULT);
}

/**
 * Validate email format
 * MOVED TO: includes/functions/validation.php
 * This function is now in validation.php to prevent duplicate declarations
 */
// function validateEmail() removed - use validation.php instead

/**
 * Validate password strength
 * MOVED TO: includes/functions/validation.php
 * This function is now in validation.php to prevent duplicate declarations
 */
// function validatePassword() removed - use validation.php instead

/**
 * Prevent SQL Injection
 */
function escapeString($string) {
    global $conn;
    if (!isset($conn) || !$conn) {
        return addslashes($string);
    }
    return mysqli_real_escape_string($conn, $string);
}

/**
 * Check if request is AJAX
 */
function isAjaxRequest() {
    return !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
           strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';
}

/**
 * Rate limiting check
 */
function checkRateLimit($identifier, $maxAttempts = 5, $timeWindow = 3600) {
    $key = 'rate_limit_' . $identifier;
    
    if (!isset($_SESSION[$key])) {
        $_SESSION[$key] = [
            'attempts' => 1,
            'first_attempt' => time()
        ];
        return true;
    }
    
    $data = $_SESSION[$key];
    $timePassed = time() - $data['first_attempt'];
    
    // Reset if time window has passed
    if ($timePassed > $timeWindow) {
        $_SESSION[$key] = [
            'attempts' => 1,
            'first_attempt' => time()
        ];
        return true;
    }
    
    // Check if limit exceeded
    if ($data['attempts'] >= $maxAttempts) {
        return false;
    }
    
    // Increment attempts
    $_SESSION[$key]['attempts']++;
    return true;
}

/**
 * Log security event
 */
function logSecurityEvent($event, $details = []) {
    $logFile = LOGS_PATH . '/security.log';
    
    $logEntry = [
        'timestamp' => date('Y-m-d H:i:s'),
        'event' => $event,
        'ip' => getUserIP(), // This function is defined in helpers.php
        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown',
        'details' => $details
    ];
    
    $logMessage = json_encode($logEntry) . PHP_EOL;
    
    file_put_contents($logFile, $logMessage, FILE_APPEND | LOCK_EX);
}

// NOTE: getUserIP() function has been REMOVED from this file
// It's already defined in includes/functions/helpers.php (line 43)
// To avoid "Cannot redeclare function" error
