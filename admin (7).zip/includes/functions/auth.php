<?php
/**
 * Authentication Functions
 * Note: getDashboardUrl() has been REMOVED from this file
 * It's already defined in helpers.php
 */

if (!defined('ALLOWED')) {
    die('Direct access not permitted');
}

/**
 * Check if user is logged in
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

/**
 * Require login - redirect to login page if not authenticated
 */
function requireLogin() {
    if (!isLoggedIn()) {
        $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'];
        redirect('/login.php');
        exit;
    }
}

/**
 * Check if user has specific role
 */
function hasRole($role) {
    if (!isLoggedIn()) {
        return false;
    }
    
    return isset($_SESSION['user_role']) && $_SESSION['user_role'] === $role;
}

/**
 * Require specific role
 */
function requireRole($role) {
    if (!hasRole($role)) {
        redirect('/403.php');
        exit;
    }
}

/**
 * Get current user ID
 */
function getCurrentUserId() {
    return $_SESSION['user_id'] ?? null;
}

/**
 * Get current user role
 */
function getCurrentUserRole() {
    return $_SESSION['user_role'] ?? null;
}

/**
 * Get current user data
 */
function getCurrentUser() {
    global $conn;
    
    $userId = getCurrentUserId();
    if (!$userId) {
        return null;
    }
    
    $userId = escapeString($userId);
    $query = "SELECT * FROM users WHERE id = '$userId' LIMIT 1";
    $result = mysqli_query($conn, $query);
    
    if ($result && mysqli_num_rows($result) > 0) {
        return mysqli_fetch_assoc($result);
    }
    
    return null;
}

/**
 * Login user
 */
function loginUser($userId, $remember = false) {
    global $conn;
    
    // Get user data
    $userId = escapeString($userId);
    $query = "SELECT * FROM users WHERE id = '$userId' LIMIT 1";
    $result = mysqli_query($conn, $query);
    
    if (!$result || mysqli_num_rows($result) === 0) {
        return false;
    }
    
    $user = mysqli_fetch_assoc($result);
    
    // Regenerate session ID to prevent session fixation
    session_regenerate_id(true);
    
    // Set session variables
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_email'] = $user['email'];
    $_SESSION['user_name'] = $user['name'];
    $_SESSION['user_role'] = $user['role'] ?? 'member';
    $_SESSION['logged_in_at'] = time();
    
    // Update last login
    $updateQuery = "UPDATE users SET 
                    last_login = NOW(), 
                    last_ip = '" . escapeString(getUserIP()) . "'
                    WHERE id = '$userId'";
    mysqli_query($conn, $updateQuery);
    
    // Handle "Remember Me"
    if ($remember) {
        $token = generateSecureToken(32);
        $hashedToken = hashPassword($token);
        
        // Store token in database
        $insertQuery = "INSERT INTO user_tokens (user_id, token, expires_at) 
                       VALUES ('$userId', '$hashedToken', DATE_ADD(NOW(), INTERVAL 30 DAY))";
        
        if (mysqli_query($conn, $insertQuery)) {
            setcookie('remember_token', $token, time() + (30 * 86400), '/', '', true, true);
        }
    }
    
    return true;
}

/**
 * Logout user
 */
function logoutUser() {
    global $conn;
    
    // Remove remember token if exists
    if (isset($_COOKIE['remember_token'])) {
        $userId = getCurrentUserId();
        if ($userId) {
            $userId = escapeString($userId);
            mysqli_query($conn, "DELETE FROM user_tokens WHERE user_id = '$userId'");
        }
        
        setcookie('remember_token', '', time() - 3600, '/', '', true, true);
    }
    
    // Clear all session data
    $_SESSION = array();
    
    // Destroy session cookie
    if (isset($_COOKIE[session_name()])) {
        setcookie(session_name(), '', time() - 3600, '/');
    }
    
    // Destroy session
    session_destroy();
    
    return true;
}

/**
 * Check remember me token
 */
function checkRememberToken() {
    global $conn;
    
    if (!isset($_COOKIE['remember_token']) || isLoggedIn()) {
        return false;
    }
    
    $token = $_COOKIE['remember_token'];
    
    // Find valid token
    $query = "SELECT ut.*, u.id as user_id 
              FROM user_tokens ut
              JOIN users u ON ut.user_id = u.id
              WHERE ut.expires_at > NOW()
              AND u.status = 'active'";
    
    $result = mysqli_query($conn, $query);
    
    if (!$result) {
        return false;
    }
    
    while ($row = mysqli_fetch_assoc($result)) {
        if (verifyPassword($token, $row['token'])) {
            // Valid token found - login user
            loginUser($row['user_id'], true);
            return true;
        }
    }
    
    // Invalid token - clear cookie
    setcookie('remember_token', '', time() - 3600, '/', '', true, true);
    return false;
}

/**
 * Verify user email
 */
function verifyUserEmail($token) {
    global $conn;
    
    $token = escapeString($token);
    
    $query = "SELECT * FROM users 
              WHERE verification_token = '$token' 
              AND email_verified = 0 
              LIMIT 1";
    
    $result = mysqli_query($conn, $query);
    
    if (!$result || mysqli_num_rows($result) === 0) {
        return false;
    }
    
    $user = mysqli_fetch_assoc($result);
    
    // Update user as verified
    $updateQuery = "UPDATE users SET 
                    email_verified = 1,
                    verification_token = NULL,
                    verified_at = NOW()
                    WHERE id = '{$user['id']}'";
    
    if (mysqli_query($conn, $updateQuery)) {
        return true;
    }
    
    return false;
}

/**
 * Check if email is already registered
 */
function emailExists($email) {
    global $conn;
    
    $email = escapeString($email);
    $query = "SELECT id FROM users WHERE email = '$email' LIMIT 1";
    $result = mysqli_query($conn, $query);
    
    return $result && mysqli_num_rows($result) > 0;
}

/**
 * Register new user
 */
function registerUser($data) {
    global $conn;
    
    // Validate required fields
    if (empty($data['email']) || empty($data['password']) || empty($data['name'])) {
        return ['success' => false, 'message' => 'All fields are required'];
    }
    
    // Validate email
    if (!validateEmail($data['email'])) {
        return ['success' => false, 'message' => 'Invalid email format'];
    }
    
    // Validate password
    if (!validatePassword($data['password'])) {
        return ['success' => false, 'message' => 'Password must be at least 8 characters with uppercase, lowercase, and number'];
    }
    
    // Check if email exists
    if (emailExists($data['email'])) {
        return ['success' => false, 'message' => 'Email already registered'];
    }
    
    // Hash password
    $hashedPassword = hashPassword($data['password']);
    $verificationToken = generateSecureToken(32);
    
    // Escape data
    $name = escapeString($data['name']);
    $email = escapeString($data['email']);
    $role = escapeString($data['role'] ?? 'member');
    
    // Insert user
    $query = "INSERT INTO users (name, email, password, role, verification_token, created_at) 
              VALUES ('$name', '$email', '$hashedPassword', '$role', '$verificationToken', NOW())";
    
    if (mysqli_query($conn, $query)) {
        $userId = mysqli_insert_id($conn);
        
        // Send verification email
        if (function_exists('sendVerificationEmail')) {
            sendVerificationEmail($email, $name, $verificationToken);
        }
        
        return [
            'success' => true, 
            'message' => 'Registration successful. Please check your email to verify your account.',
            'user_id' => $userId
        ];
    }
    
    return ['success' => false, 'message' => 'Registration failed. Please try again.'];
}

// NOTE: getDashboardUrl() function has been REMOVED from this file
// It's already defined in includes/functions/helpers.php (line 138)
// To avoid "Cannot redeclare function" error
