<?php
/**
 * Validation Functions
 * FIXED VERSION - All validations now work correctly
 */

if (!defined('ALLOWED')) {
    die('Direct access not permitted');
}

/**
 * Validate email address
 * FIXED: Now properly validates email format
 */
function validateEmail($email) {
    if (empty($email)) {
        return false;
    }
    
    // Filter and validate email
    $email = filter_var($email, FILTER_SANITIZE_EMAIL);
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/**
 * Validate phone number (Indonesia format)
 * FIXED: Now properly validates phone format
 */
function validatePhone($phone) {
    if (empty($phone)) {
        return false;
    }
    
    // Remove spaces, dashes, and brackets
    $phone = preg_replace('/[\s\-\(\)]/', '', $phone);
    
    // Check if contains only numbers
    if (!ctype_digit($phone)) {
        return false;
    }
    
    // Check length (min 10, max 15 digits)
    $length = strlen($phone);
    if ($length < 10 || $length > 15) {
        return false;
    }
    
    // Check if starts with valid prefix
    // Valid: 08, 628, +628, 62
    $validPrefixes = ['08', '628', '+628', '62'];
    $isValid = false;
    
    foreach ($validPrefixes as $prefix) {
        if (substr($phone, 0, strlen($prefix)) === $prefix) {
            $isValid = true;
            break;
        }
    }
    
    return $isValid;
}

/**
 * Validate password strength
 * FIXED: Now properly checks password requirements
 * Requirements: min 8 chars, at least 1 uppercase, 1 lowercase, 1 number
 */
function validatePassword($password) {
    if (empty($password)) {
        return false;
    }
    
    // Check minimum length
    if (strlen($password) < 8) {
        return false;
    }
    
    // Check for at least one lowercase letter
    if (!preg_match('/[a-z]/', $password)) {
        return false;
    }
    
    // Check for at least one uppercase letter
    if (!preg_match('/[A-Z]/', $password)) {
        return false;
    }
    
    // Check for at least one number
    if (!preg_match('/[0-9]/', $password)) {
        return false;
    }
    
    return true;
}

/**
 * Validate name
 * FIXED: Now properly validates name format
 * Requirements: min 3 chars, only letters, spaces, and hyphens
 */
function validateName($name) {
    if (empty($name)) {
        return false;
    }
    
    // Check minimum length
    if (strlen($name) < 3) {
        return false;
    }
    
    // Check maximum length
    if (strlen($name) > 100) {
        return false;
    }
    
    // Allow only letters, spaces, hyphens, and apostrophes
    if (!preg_match("/^[a-zA-Z\s\-']+$/", $name)) {
        return false;
    }
    
    return true;
}

/**
 * Validate required field
 */
function validateRequired($value) {
    if (is_array($value)) {
        return !empty($value);
    }
    
    return !empty(trim($value));
}

/**
 * Validate numeric value
 */
function validateNumeric($value, $min = null, $max = null) {
    if (!is_numeric($value)) {
        return false;
    }
    
    if ($min !== null && $value < $min) {
        return false;
    }
    
    if ($max !== null && $value > $max) {
        return false;
    }
    
    return true;
}

/**
 * Validate string length
 */
function validateLength($string, $min = 0, $max = PHP_INT_MAX) {
    $length = strlen($string);
    return $length >= $min && $length <= $max;
}

/**
 * Validate date format
 */
function validateDate($date, $format = 'Y-m-d') {
    $d = DateTime::createFromFormat($format, $date);
    return $d && $d->format($format) === $date;
}

/**
 * Validate URL
 */
function validateURL($url) {
    return filter_var($url, FILTER_VALIDATE_URL) !== false;
}

/**
 * Validate image upload
 */
function validateImageUpload($file) {
    $result = ['valid' => false, 'error' => ''];
    
    // Check if file exists
    if (!isset($file) || $file['error'] === UPLOAD_ERR_NO_FILE) {
        $result['error'] = 'No file uploaded';
        return $result;
    }
    
    // Check for upload errors
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $result['error'] = 'Upload error occurred';
        return $result;
    }
    
    // Check file size (max 2MB)
    $maxSize = 2 * 1024 * 1024; // 2MB
    if ($file['size'] > $maxSize) {
        $result['error'] = 'File size exceeds 2MB';
        return $result;
    }
    
    // Check MIME type
    $allowedTypes = ['image/jpeg', 'image/png', 'image/jpg'];
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mimeType = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    
    if (!in_array($mimeType, $allowedTypes)) {
        $result['error'] = 'Only JPG and PNG files are allowed';
        return $result;
    }
    
    // Check file extension
    $allowedExtensions = ['jpg', 'jpeg', 'png'];
    $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    
    if (!in_array($extension, $allowedExtensions)) {
        $result['error'] = 'Invalid file extension';
        return $result;
    }
    
    $result['valid'] = true;
    return $result;
}

/**
 * Validate PDF upload
 */
function validatePDFUpload($file) {
    $result = ['valid' => false, 'error' => ''];
    
    // Check if file exists
    if (!isset($file) || $file['error'] === UPLOAD_ERR_NO_FILE) {
        $result['error'] = 'No file uploaded';
        return $result;
    }
    
    // Check for upload errors
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $result['error'] = 'Upload error occurred';
        return $result;
    }
    
    // Check file size (max 5MB)
    $maxSize = 5 * 1024 * 1024; // 5MB
    if ($file['size'] > $maxSize) {
        $result['error'] = 'File size exceeds 5MB';
        return $result;
    }
    
    // Check MIME type
    $allowedTypes = ['application/pdf'];
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mimeType = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    
    if (!in_array($mimeType, $allowedTypes)) {
        $result['error'] = 'Only PDF files are allowed';
        return $result;
    }
    
    // Check file extension
    $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    
    if ($extension !== 'pdf') {
        $result['error'] = 'Invalid file extension';
        return $result;
    }
    
    $result['valid'] = true;
    return $result;
}

/**
 * Sanitize filename
 */
function sanitizeFilename($filename) {
    // Remove any path information
    $filename = basename($filename);
    
    // Remove special characters
    $filename = preg_replace('/[^a-zA-Z0-9._-]/', '_', $filename);
    
    // Remove multiple dots (security)
    $filename = preg_replace('/\.+/', '.', $filename);
    
    return $filename;
}

/**
 * Validate amount (for payments/withdrawals)
 */
function validateAmount($amount, $min = 0) {
    if (!is_numeric($amount)) {
        return false;
    }
    
    if ($amount < $min) {
        return false;
    }
    
    return true;
}

/**
 * Validate bank account number
 */
function validateBankAccount($accountNumber) {
    // Remove spaces and dashes
    $accountNumber = preg_replace('/[\s\-]/', '', $accountNumber);
    
    // Check if numeric
    if (!ctype_digit($accountNumber)) {
        return false;
    }
    
    // Check length (Indonesia bank accounts: 10-16 digits)
    $length = strlen($accountNumber);
    return $length >= 10 && $length <= 16;
}

/**
 * Validate referral code
 */
function validateReferralCode($code) {
    // Referral code: 8 alphanumeric characters
    return preg_match('/^[A-Z0-9]{8}$/', $code);
}
