<?php
if (!defined('ALLOWED')) die('Direct access not permitted');

function getTierByOrders($orderCount) {
    if ($orderCount >= TIER_MAX_MIN_ORDERS) {
        return ['name' => TIER_MAX_NAME, 'commission' => TIER_MAX_COMMISSION];
    } elseif ($orderCount >= TIER_3_MIN_ORDERS) {
        return ['name' => TIER_3_NAME, 'commission' => TIER_3_COMMISSION];
    } elseif ($orderCount >= TIER_2_MIN_ORDERS) {
        return ['name' => TIER_2_NAME, 'commission' => TIER_2_COMMISSION];
    } else {
        return ['name' => TIER_1_NAME, 'commission' => TIER_1_COMMISSION];
    }
}

function checkAndUpgradeTier($freelancerId) {
    $freelancer = getRow("SELECT * FROM freelancers WHERE user_id = :id", ['id' => $freelancerId]);
    
    if (!$freelancer) {
        return false;
    }
    
    $currentOrders = $freelancer['total_orders_current_month'];
    $newTier = getTierByOrders($currentOrders);
    
    if ($newTier['name'] !== $freelancer['tier']) {
        $sql = "UPDATE freelancers SET tier = :tier, commission_rate = :rate WHERE user_id = :id";
        executeQuery($sql, [
            'tier' => $newTier['name'],
            'rate' => $newTier['commission'],
            'id' => $freelancerId
        ]);
        
        $sql = "INSERT INTO tier_history (freelancer_id, old_tier, new_tier, reason, changed_at) 
                VALUES (:freelancer_id, :old_tier, :new_tier, 'auto_upgrade', NOW())";
        executeQuery($sql, [
            'freelancer_id' => $freelancerId,
            'old_tier' => $freelancer['tier'],
            'new_tier' => $newTier['name']
        ]);
        
        createNotification($freelancerId, NOTIFICATION_TIER_UPGRADED, 
            'Tier Naik!', 
            'Selamat! Tier Anda naik ke ' . $newTier['name'] . ' dengan komisi ' . $newTier['commission'] . '%');
        
        return true;
    }
    
    return false;
}

function evaluateMonthlyTiers() {
    $sql = "SELECT * FROM freelancers";
    $freelancers = getRows($sql);
    
    $upgraded = 0;
    $downgraded = 0;
    
    foreach ($freelancers as $freelancer) {
        $lastMonthOrders = $freelancer['total_orders_current_month'];
        $currentTier = $freelancer['tier'];
        
        $shouldBeTier = getTierByOrders($lastMonthOrders);
        
        if ($shouldBeTier['name'] !== $currentTier) {
            $sql = "UPDATE freelancers SET tier = :tier, commission_rate = :rate, total_orders_current_month = 0 WHERE id = :id";
            executeQuery($sql, [
                'tier' => $shouldBeTier['name'],
                'rate' => $shouldBeTier['commission'],
                'id' => $freelancer['id']
            ]);
            
            $sql = "INSERT INTO tier_history (freelancer_id, old_tier, new_tier, reason, changed_at) 
                    VALUES (:freelancer_id, :old_tier, :new_tier, 'monthly_evaluation', NOW())";
            executeQuery($sql, [
                'freelancer_id' => $freelancer['user_id'],
                'old_tier' => $currentTier,
                'new_tier' => $shouldBeTier['name']
            ]);
            
            if (strpos($shouldBeTier['name'], 'MAX') !== false || intval(filter_var($shouldBeTier['name'], FILTER_SANITIZE_NUMBER_INT)) > intval(filter_var($currentTier, FILTER_SANITIZE_NUMBER_INT))) {
                $upgraded++;
            } else {
                $downgraded++;
                createNotification($freelancer['user_id'], NOTIFICATION_TIER_DOWNGRADED, 
                    'Informasi Tier', 
                    'Tier Anda berubah menjadi ' . $shouldBeTier['name'] . ' karena order bulan lalu tidak mencapai target maintain.');
            }
        } else {
            $sql = "UPDATE freelancers SET total_orders_current_month = 0 WHERE id = :id";
            executeQuery($sql, ['id' => $freelancer['id']]);
        }
    }
    
    return ['upgraded' => $upgraded, 'downgraded' => $downgraded, 'total' => count($freelancers)];
}

function incrementFreelancerOrders($freelancerId) {
    $sql = "UPDATE freelancers SET 
            total_orders_current_month = total_orders_current_month + 1,
            total_orders_all_time = total_orders_all_time + 1 
            WHERE user_id = :id";
    
    executeQuery($sql, ['id' => $freelancerId]);
    
    checkAndUpgradeTier($freelancerId);
}
