<?php
/**
 * Flash Message Functions
 * SITUNEO DIGITAL - PHP 7.4 Compatible
 */

if (!defined('ALLOWED')) {
    die('Direct access not permitted');
}

/**
 * Set flash message
 */
function setFlash($type, $message) {
    if (!isset($_SESSION['flash'])) {
        $_SESSION['flash'] = array();
    }
    $_SESSION['flash'][$type] = $message;
}

/**
 * Get flash message
 */
function getFlash($type = null) {
    if ($type === null) {
        $flash = isset($_SESSION['flash']) ? $_SESSION['flash'] : array();
        unset($_SESSION['flash']);
        return $flash;
    }
    
    $message = isset($_SESSION['flash'][$type]) ? $_SESSION['flash'][$type] : null;
    unset($_SESSION['flash'][$type]);
    
    return $message;
}

/**
 * Check if flash message exists
 */
function hasFlash($type = null) {
    if ($type === null) {
        return isset($_SESSION['flash']) && !empty($_SESSION['flash']);
    }
    return isset($_SESSION['flash'][$type]);
}

/**
 * Display flash message
 */
function displayFlash() {
    $flashes = getFlash();
    
    if (empty($flashes)) {
        return;
    }
    
    foreach ($flashes as $type => $message) {
        // Convert type to Bootstrap alert class
        if ($type === 'success') {
            $alertType = 'success';
        } elseif ($type === 'error') {
            $alertType = 'danger';
        } elseif ($type === 'warning') {
            $alertType = 'warning';
        } elseif ($type === 'info') {
            $alertType = 'info';
        } else {
            $alertType = 'primary';
        }
        
        echo "<div class='alert alert-" . $alertType . " alert-dismissible fade show' role='alert'>";
        echo htmlspecialchars($message);
        echo "<button type='button' class='btn-close' data-bs-dismiss='alert'></button>";
        echo "</div>";
    }
}

/**
 * Set success flash message
 */
function setSuccess($message) {
    setFlash('success', $message);
}

/**
 * Set error flash message
 */
function setError($message) {
    setFlash('error', $message);
}

/**
 * Set warning flash message
 */
function setWarning($message) {
    setFlash('warning', $message);
}

/**
 * Set info flash message
 */
function setInfo($message) {
    setFlash('info', $message);
}
