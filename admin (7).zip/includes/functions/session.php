<?php
/**
 * Session Management Functions
 * SITUNEO DIGITAL
 */

if (!defined('ALLOWED')) {
    die('Direct access not permitted');
}

/**
 * Initialize session with secure settings
 */
function initSession() {
    if (session_status() === PHP_SESSION_NONE) {
        ini_set('session.cookie_httponly', 1);
        ini_set('session.use_only_cookies', 1);
        ini_set('session.cookie_secure', 0); // Set to 1 if using HTTPS
        ini_set('session.cookie_samesite', 'Lax');
        session_start();
    }
}

/**
 * Regenerate session ID for security
 */
function regenerateSession() {
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_regenerate_id(true);
    }
}

/**
 * Destroy session completely
 */
function destroySession() {
    if (session_status() === PHP_SESSION_ACTIVE) {
        $_SESSION = [];
        
        if (isset($_COOKIE[session_name()])) {
            setcookie(session_name(), '', time() - 3600, '/');
        }
        
        session_destroy();
    }
}

/**
 * Set session variable
 */
function setSession($key, $value) {
    $_SESSION[$key] = $value;
}

/**
 * Get session variable
 */
function getSession($key, $default = null) {
    return $_SESSION[$key] ?? $default;
}

/**
 * Check if session variable exists
 */
function hasSession($key) {
    return isset($_SESSION[$key]);
}

/**
 * Remove session variable
 */
function unsetSession($key) {
    if (isset($_SESSION[$key])) {
        unset($_SESSION[$key]);
    }
}

/**
 * Validate session is active and valid
 */
function validateSession() {
    if (session_status() !== PHP_SESSION_ACTIVE) {
        return false;
    }
    
    // Check if user_id exists in session
    if (!isset($_SESSION['user_id'])) {
        return false;
    }
    
    // Check session timeout (optional)
    if (isset($_SESSION['last_activity'])) {
        $timeout = 3600; // 1 hour
        if (time() - $_SESSION['last_activity'] > $timeout) {
            destroySession();
            return false;
        }
    }
    
    $_SESSION['last_activity'] = time();
    
    return true;
}

/**
 * Set session timeout
 */
function setSessionTimeout($seconds = 3600) {
    $_SESSION['timeout'] = $seconds;
    $_SESSION['last_activity'] = time();
}

/**
 * Check session timeout
 */
function checkSessionTimeout() {
    if (isset($_SESSION['timeout']) && isset($_SESSION['last_activity'])) {
        if (time() - $_SESSION['last_activity'] > $_SESSION['timeout']) {
            return false;
        }
    }
    return true;
}
