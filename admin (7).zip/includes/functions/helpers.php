<?php
/**
 * Helper Functions
 * General utility functions used throughout the application
 */

if (!defined('ALLOWED')) {
    die('Direct access not permitted');
}

/**
 * Redirect to a URL
 */
function redirect($url) {
    if (!headers_sent()) {
        header("Location: $url");
        exit;
    } else {
        echo "<script>window.location.href='$url';</script>";
        echo "<noscript><meta http-equiv='refresh' content='0;url=$url'></noscript>";
        exit;
    }
}

/**
 * Get base URL
 */
function getBaseUrl() {
    return BASE_URL ?? 'http://' . $_SERVER['HTTP_HOST'];
}

/**
 * Get current URL
 */
function getCurrentUrl() {
    $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
    return $protocol . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
}

/**
 * Get user IP address
 * This is the ONLY place this function should be defined
 */
function getUserIP() {
    $ip = '';
    
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    }
    
    // Validate IP
    if (filter_var($ip, FILTER_VALIDATE_IP)) {
        return $ip;
    }
    
    return '0.0.0.0';
}

/**
 * Check if request is POST
 */
function isPost() {
    return $_SERVER['REQUEST_METHOD'] === 'POST';
}

/**
 * Check if request is GET
 */
function isGet() {
    return $_SERVER['REQUEST_METHOD'] === 'GET';
}

/**
 * Get POST data
 */
function getPost($key, $default = null) {
    return $_POST[$key] ?? $default;
}

/**
 * Get GET data
 */
function getQuery($key, $default = null) {
    return $_GET[$key] ?? $default;
}

/**
 * Check if value is empty
 */
function isEmpty($value) {
    return empty($value) && $value !== '0' && $value !== 0;
}

/**
 * Format date
 */
function formatDate($date, $format = 'Y-m-d H:i:s') {
    if (empty($date)) {
        return '';
    }
    
    $timestamp = is_numeric($date) ? $date : strtotime($date);
    return date($format, $timestamp);
}

/**
 * Time ago format
 */
function timeAgo($datetime) {
    $timestamp = is_numeric($datetime) ? $datetime : strtotime($datetime);
    $diff = time() - $timestamp;
    
    if ($diff < 60) {
        return 'just now';
    } elseif ($diff < 3600) {
        $mins = floor($diff / 60);
        return $mins . ' minute' . ($mins > 1 ? 's' : '') . ' ago';
    } elseif ($diff < 86400) {
        $hours = floor($diff / 3600);
        return $hours . ' hour' . ($hours > 1 ? 's' : '') . ' ago';
    } elseif ($diff < 604800) {
        $days = floor($diff / 86400);
        return $days . ' day' . ($days > 1 ? 's' : '') . ' ago';
    } else {
        return date('M j, Y', $timestamp);
    }
}

/**
 * Format currency
 */
function formatCurrency($amount, $currency = 'USD') {
    $symbols = [
        'USD' => '$',
        'EUR' => '€',
        'GBP' => '£',
        'IDR' => 'Rp'
    ];
    
    $symbol = $symbols[$currency] ?? $currency . ' ';
    
    if ($currency === 'IDR') {
        return $symbol . number_format($amount, 0, ',', '.');
    }
    
    return $symbol . number_format($amount, 2, '.', ',');
}

/**
 * Get dashboard URL based on user role
 * This is the ONLY place this function should be defined
 */
function getDashboardUrl($role = null) {
    if ($role === null && isset($_SESSION['user_role'])) {
        $role = $_SESSION['user_role'];
    }
    
    $dashboards = [
        'admin' => '/admin/dashboard.php',
        'member' => '/member/dashboard.php',
        'user' => '/user/dashboard.php'
    ];
    
    return $dashboards[$role] ?? '/dashboard.php';
}

/**
 * Generate random string
 */
function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    
    return $randomString;
}

/**
 * Generate slug from string
 */
function generateSlug($string) {
    $string = strtolower($string);
    $string = preg_replace('/[^a-z0-9\s-]/', '', $string);
    $string = preg_replace('/[\s-]+/', '-', $string);
    $string = trim($string, '-');
    
    return $string;
}

/**
 * Truncate text
 */
function truncateText($text, $length = 100, $suffix = '...') {
    if (strlen($text) <= $length) {
        return $text;
    }
    
    return substr($text, 0, $length) . $suffix;
}

/**
 * Get file extension
 */
function getFileExtension($filename) {
    return strtolower(pathinfo($filename, PATHINFO_EXTENSION));
}

/**
 * Format file size
 */
function formatFileSize($bytes) {
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    
    for ($i = 0; $bytes > 1024 && $i < count($units) - 1; $i++) {
        $bytes /= 1024;
    }
    
    return round($bytes, 2) . ' ' . $units[$i];
}

/**
 * Check if file is image
 */
function isImage($filename) {
    $imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'];
    $extension = getFileExtension($filename);
    
    return in_array($extension, $imageExtensions);
}

/**
 * Set flash message
 */
function setFlashMessage($message, $type = 'info') {
    $_SESSION['flash_message'] = [
        'message' => $message,
        'type' => $type
    ];
}

/**
 * Get and clear flash message
 */
function getFlashMessage() {
    if (isset($_SESSION['flash_message'])) {
        $message = $_SESSION['flash_message'];
        unset($_SESSION['flash_message']);
        return $message;
    }
    
    return null;
}

/**
 * JSON response
 */
function jsonResponse($data, $statusCode = 200) {
    http_response_code($statusCode);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

/**
 * Success response
 */
function successResponse($message, $data = null) {
    jsonResponse([
        'success' => true,
        'message' => $message,
        'data' => $data
    ]);
}

/**
 * Error response
 */
function errorResponse($message, $statusCode = 400) {
    jsonResponse([
        'success' => false,
        'error' => $message
    ], $statusCode);
}

/**
 * Pagination helper
 */
function getPagination($currentPage, $totalItems, $itemsPerPage = 10) {
    $totalPages = ceil($totalItems / $itemsPerPage);
    $offset = ($currentPage - 1) * $itemsPerPage;
    
    return [
        'current_page' => $currentPage,
        'total_pages' => $totalPages,
        'total_items' => $totalItems,
        'items_per_page' => $itemsPerPage,
        'offset' => $offset,
        'has_previous' => $currentPage > 1,
        'has_next' => $currentPage < $totalPages
    ];
}

/**
 * Debug helper
 */
function dd($data) {
    echo '<pre>';
    var_dump($data);
    echo '</pre>';
    die();
}

/**
 * Log message to file
 */
function logMessage($message, $file = 'app.log') {
    $logPath = LOGS_PATH . '/' . $file;
    $timestamp = date('Y-m-d H:i:s');
    $logEntry = "[{$timestamp}] {$message}" . PHP_EOL;
    
    file_put_contents($logPath, $logEntry, FILE_APPEND | LOCK_EX);
}

/**
 * Get visitor info
 */
function getVisitorInfo() {
    return [
        'ip' => getUserIP(),
        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown',
        'referer' => $_SERVER['HTTP_REFERER'] ?? 'Direct',
        'language' => $_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? 'Unknown',
        'timestamp' => time()
    ];
}

/**
 * Check if user is admin
 */
function isAdmin() {
    return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
}

/**
 * Check if user is member
 */
function isMember() {
    return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'member';
}

/**
 * Array to CSV download
 */
function arrayToCsv($data, $filename = 'export.csv') {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    
    $output = fopen('php://output', 'w');
    
    // Add headers
    if (!empty($data)) {
        fputcsv($output, array_keys($data[0]));
    }
    
    // Add data
    foreach ($data as $row) {
        fputcsv($output, $row);
    }
    
    fclose($output);
    exit;
}

/**
 * Format price/currency
 * Format number as currency (Rupiah by default)
 */
function formatPrice($amount, $currency = 'IDR') {
    if (!is_numeric($amount)) {
        return $amount;
    }
    
    $amount = floatval($amount);
    
    if ($currency === 'IDR' || $currency === 'Rp') {
        return 'Rp ' . number_format($amount, 0, ',', '.');
    } elseif ($currency === 'USD' || $currency === '$') {
        return '$' . number_format($amount, 2, '.', ',');
    } else {
        return $currency . ' ' . number_format($amount, 2, '.', ',');
    }
}

/**
 * Show flash alert
 * Display flash message as Bootstrap alert
 */
function showFlashAlert() {
    if (!isset($_SESSION['flash'])) {
        return;
    }
    
    $flashes = $_SESSION['flash'];
    unset($_SESSION['flash']);
    
    foreach ($flashes as $type => $message) {
        $alertType = 'primary';
        
        if ($type === 'success') {
            $alertType = 'success';
        } elseif ($type === 'error' || $type === 'danger') {
            $alertType = 'danger';
        } elseif ($type === 'warning') {
            $alertType = 'warning';
        } elseif ($type === 'info') {
            $alertType = 'info';
        }
        
        echo '<div class="alert alert-' . $alertType . ' alert-dismissible fade show" role="alert">';
        echo htmlspecialchars($message);
        echo '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>';
        echo '</div>';
    }
}

/**
 * Get status badge HTML
 * Return Bootstrap badge HTML for status
 */
function getStatusBadge($status) {
    $badges = array(
        'pending' => '<span class="badge bg-warning">Pending</span>',
        'approved' => '<span class="badge bg-info">Approved</span>',
        'processing' => '<span class="badge bg-primary">Processing</span>',
        'completed' => '<span class="badge bg-success">Completed</span>',
        'cancelled' => '<span class="badge bg-danger">Cancelled</span>',
        'rejected' => '<span class="badge bg-danger">Rejected</span>',
        'paid' => '<span class="badge bg-success">Paid</span>',
        'unpaid' => '<span class="badge bg-warning">Unpaid</span>',
        'verified' => '<span class="badge bg-success">Verified</span>',
        'active' => '<span class="badge bg-success">Active</span>',
        'inactive' => '<span class="badge bg-secondary">Inactive</span>',
        'suspended' => '<span class="badge bg-danger">Suspended</span>'
    );
    
    $status = strtolower($status);
    
    if (isset($badges[$status])) {
        return $badges[$status];
    }
    
    return '<span class="badge bg-secondary">' . htmlspecialchars(ucfirst($status)) . '</span>';
}


