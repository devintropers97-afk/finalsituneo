<?php
if (!defined('ALLOWED')) die('Direct access not permitted');

function uploadFile($file, $uploadDir, $prefix = '') {
    if (!file_exists($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }
    
    $originalName = basename($file['name']);
    $extension = getFileExtension($originalName);
    $safeFilename = sanitizeFilename($prefix . '_' . time() . '.' . $extension);
    $targetPath = $uploadDir . '/' . $safeFilename;
    
    if (move_uploaded_file($file['tmp_name'], $targetPath)) {
        return ['success' => true, 'filename' => $safeFilename, 'path' => $targetPath];
    }
    
    return ['success' => false, 'message' => 'Gagal mengupload file'];
}

function deleteFile($filePath) {
    if (file_exists($filePath)) {
        return unlink($filePath);
    }
    return false;
}
