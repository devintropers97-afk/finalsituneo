<?php
if (!defined('ALLOWED')) die('Direct access not permitted');

function calculateCommission($orderId, $freelancerId, $orderAmount) {
    $freelancer = getRow("SELECT * FROM freelancers WHERE user_id = :id", ['id' => $freelancerId]);
    
    if (!$freelancer) {
        return false;
    }
    
    $commissionRate = $freelancer['commission_rate'];
    $commissionAmount = ($orderAmount * $commissionRate) / 100;
    
    $sql = "INSERT INTO commissions (freelancer_id, order_id, amount, tier_at_time, commission_rate, status, created_at) 
            VALUES (:freelancer_id, :order_id, :amount, :tier, :rate, 'pending', NOW())";
    
    $result = executeQuery($sql, [
        'freelancer_id' => $freelancerId,
        'order_id' => $orderId,
        'amount' => $commissionAmount,
        'tier' => $freelancer['tier'],
        'rate' => $commissionRate
    ]);
    
    if ($result) {
        createNotification($freelancerId, NOTIFICATION_COMMISSION_EARNED, 
            'Komisi Baru!', 
            'Anda mendapat komisi ' . formatCurrency($commissionAmount) . ' dari order #' . $orderId);
    }
    
    return $result;
}

function approveCommission($commissionId) {
    $sql = "UPDATE commissions SET status = 'approved' WHERE id = :id";
    return executeQuery($sql, ['id' => $commissionId]);
}

function getFreelancerCommissions($freelancerId, $status = null) {
    $sql = "SELECT c.*, o.order_number FROM commissions c 
            LEFT JOIN orders o ON c.order_id = o.id 
            WHERE c.freelancer_id = :freelancer_id";
    
    $params = ['freelancer_id' => $freelancerId];
    
    if ($status) {
        $sql .= " AND c.status = :status";
        $params['status'] = $status;
    }
    
    $sql .= " ORDER BY c.created_at DESC";
    
    return getRows($sql, $params);
}

function getTotalCommissionBalance($freelancerId) {
    $sql = "SELECT SUM(amount) as total FROM commissions 
            WHERE freelancer_id = :freelancer_id AND status = 'approved'";
    
    $result = getRow($sql, ['freelancer_id' => $freelancerId]);
    return $result['total'] ?? 0;
}
