<?php
/**
 * Redirect Functions
 * SITUNEO DIGITAL
 */

if (!defined('ALLOWED')) {
    die('Direct access not permitted');
}

/**
 * Redirect to URL (already exists in helpers.php but kept here for compatibility)
 */
if (!function_exists('redirect')) {
    function redirect($url) {
        if (!headers_sent()) {
            header("Location: $url");
            exit;
        } else {
            echo "<script>window.location.href='$url';</script>";
            exit;
        }
    }
}

/**
 * Redirect back to previous page
 */
function redirectBack() {
    $referer = $_SERVER['HTTP_REFERER'] ?? SITE_URL;
    redirect($referer);
}

/**
 * Redirect with flash message
 */
function redirectWith($url, $type, $message) {
    setFlash($type, $message);
    redirect($url);
}

/**
 * Redirect with success message
 */
function redirectWithSuccess($url, $message) {
    redirectWith($url, 'success', $message);
}

/**
 * Redirect with error message
 */
function redirectWithError($url, $message) {
    redirectWith($url, 'error', $message);
}

/**
 * Redirect to dashboard based on role
 */
function redirectToDashboard($role = null) {
    if ($role === null) {
        $role = getCurrentUserRole();
    }
    
    $dashboardUrl = getDashboardUrl($role);
    redirect($dashboardUrl);
}

/**
 * Redirect to login page
 */
function redirectToLogin() {
    redirect(SITE_URL . '/pages/auth/login.php');
}

/**
 * Redirect to home page
 */
function redirectToHome() {
    redirect(SITE_URL);
}
