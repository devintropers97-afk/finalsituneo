<?php
/**
 * Services Data - COMPLETE 32 SERVICES
 * FIXED VERSION
 */

if (!defined('ALLOWED')) {
    die('Direct access not permitted');
}

function getAllDivisions() {
    return [
        ['id' => 1, 'name' => 'Website & Pengembangan Sistem', 'slug' => 'website-pengembangan-sistem', 'icon' => 'bi-code-slash'],
        ['id' => 2, 'name' => 'Digital Marketing', 'slug' => 'digital-marketing', 'icon' => 'bi-megaphone'],
        ['id' => 3, 'name' => 'AI & Automation', 'slug' => 'ai-automation', 'icon' => 'bi-robot'],
        ['id' => 4, 'name' => 'Branding & Design', 'slug' => 'branding-design', 'icon' => 'bi-palette'],
        ['id' => 5, 'name' => 'Content & Copywriting', 'slug' => 'content-copywriting', 'icon' => 'bi-pencil-square'],
        ['id' => 6, 'name' => 'Data & Analytics', 'slug' => 'data-analytics', 'icon' => 'bi-graph-up'],
        ['id' => 7, 'name' => 'Legal & Infrastructure', 'slug' => 'legal-infrastructure', 'icon' => 'bi-shield-check'],
        ['id' => 8, 'name' => 'Customer Experience', 'slug' => 'customer-experience', 'icon' => 'bi-people'],
        ['id' => 9, 'name' => 'Education & Training', 'slug' => 'education-training', 'icon' => 'bi-book'],
        ['id' => 10, 'name' => 'Partnership & Reseller', 'slug' => 'partnership-reseller', 'icon' => 'bi-handshake'],
    ];
}

function getAllServices() {
    // NOTE: Only showing 32 services as that's what was tested
    // Division 5-10 intentionally have 0 services for now (will be added in BATCH 2)
    return [
        // Division 1: Website (10 services)
        ['division_id' => 1, 'name' => 'Landing Page / Company Profile', 'slug' => 'landing-page', 'description' => 'Website 1 halaman profesional', 'price_onetime' => 350000, 'price_monthly' => 150000, 'features' => 'Responsif, SEO, SSL, Domain, Hosting'],
        ['division_id' => 1, 'name' => 'Multi-Page Website', 'slug' => 'multi-page', 'description' => 'Website multi halaman', 'price_onetime' => 750000, 'price_monthly' => 250000, 'features' => '10 halaman, Gallery, Blog, Admin'],
        ['division_id' => 1, 'name' => 'E-Commerce Website', 'slug' => 'ecommerce', 'description' => 'Toko online lengkap', 'price_onetime' => 1500000, 'price_monthly' => 350000, 'features' => 'Payment, Inventory, Tracking'],
        ['division_id' => 1, 'name' => 'Custom Website / Web App', 'slug' => 'custom-webapp', 'description' => 'Custom sesuai kebutuhan', 'price_onetime' => 2000000, 'price_monthly' => 500000, 'features' => 'Full custom, API, Database'],
        ['division_id' => 1, 'name' => 'Website Sekolah / Lembaga', 'slug' => 'website-sekolah', 'description' => 'Platform digital sekolah', 'price_onetime' => 1200000, 'price_monthly' => 400000, 'features' => 'Akademik, Galeri, Admin'],
        ['division_id' => 1, 'name' => 'Portfolio / Personal Branding', 'slug' => 'portfolio', 'description' => 'Website portfolio profesional', 'price_onetime' => 700000, 'price_monthly' => 200000, 'features' => 'Showcase, Skills, Blog'],
        ['division_id' => 1, 'name' => 'Website AI & Automation', 'slug' => 'website-ai', 'description' => 'Website dengan AI', 'price_onetime' => 2500000, 'price_monthly' => 450000, 'features' => 'Chatbot, Auto-response, Analytics'],
        ['division_id' => 1, 'name' => 'Website Pemerintah', 'slug' => 'govsite', 'description' => 'Portal pemerintahan', 'price_onetime' => 3500000, 'price_monthly' => 1500000, 'features' => 'High security, Multi-role'],
        ['division_id' => 1, 'name' => 'Website Event', 'slug' => 'eventsite', 'description' => 'Platform event', 'price_onetime' => 1200000, 'price_monthly' => 500000, 'features' => 'Ticketing, Registration, Streaming'],
        ['division_id' => 1, 'name' => 'Website Properti', 'slug' => 'propertysite', 'description' => 'Listing properti', 'price_onetime' => 2200000, 'price_monthly' => 900000, 'features' => 'Listings, Map, Virtual tour'],
        
        // Division 2: Digital Marketing (9 services)
        ['division_id' => 2, 'name' => 'SEO Optimization', 'slug' => 'seo-basic', 'description' => 'Optimasi SEO basic', 'price_onetime' => 0, 'price_monthly' => 200000, 'features' => 'Keywords, On-page, Reports'],
        ['division_id' => 2, 'name' => 'SEO Premium', 'slug' => 'seo-premium', 'description' => 'SEO komprehensif', 'price_onetime' => 0, 'price_monthly' => 600000, 'features' => 'Competitor analysis, Link building'],
        ['division_id' => 2, 'name' => 'Google Ads Management', 'slug' => 'google-ads', 'description' => 'Kelola Google Ads', 'price_onetime' => 0, 'price_monthly' => 400000, 'features' => 'Campaign, Keywords, Optimization'],
        ['division_id' => 2, 'name' => 'Meta Ads', 'slug' => 'meta-ads', 'description' => 'FB & IG Ads', 'price_onetime' => 0, 'price_monthly' => 400000, 'features' => 'Targeting, Creative, Analytics'],
        ['division_id' => 2, 'name' => 'TikTok Ads', 'slug' => 'tiktok-ads', 'description' => 'Iklan TikTok', 'price_onetime' => 0, 'price_monthly' => 400000, 'features' => 'Video ads, Hashtag challenge'],
        ['division_id' => 2, 'name' => 'Google My Business', 'slug' => 'gmb', 'description' => 'Optimasi GMB', 'price_onetime' => 0, 'price_monthly' => 250000, 'features' => 'Profile, Posts, Reviews'],
        ['division_id' => 2, 'name' => 'WhatsApp Blast', 'slug' => 'wa-blast', 'description' => 'Broadcast WA', 'price_onetime' => 0, 'price_monthly' => 250000, 'features' => 'Bulk messaging, Templates'],
        ['division_id' => 2, 'name' => 'Email Marketing', 'slug' => 'email-marketing', 'description' => 'Automated emails', 'price_onetime' => 0, 'price_monthly' => 200000, 'features' => 'Templates, Automation, Analytics'],
        ['division_id' => 2, 'name' => 'Social Media Management', 'slug' => 'smm', 'description' => 'Kelola social media', 'price_onetime' => 0, 'price_monthly' => 400000, 'features' => 'Content, Scheduling, Analytics'],
        
        // Division 3: AI & Automation (8 services)
        ['division_id' => 3, 'name' => 'AI Chatbot Basic', 'slug' => 'chatbot-basic', 'description' => 'Chatbot basic', 'price_onetime' => 0, 'price_monthly' => 300000, 'features' => 'Auto-reply, FAQ, Analytics'],
        ['division_id' => 3, 'name' => 'AI Chatbot Premium', 'slug' => 'chatbot-premium', 'description' => 'Chatbot advanced', 'price_onetime' => 0, 'price_monthly' => 600000, 'features' => 'Multi-platform, CRM integration'],
        ['division_id' => 3, 'name' => 'CRM Basic', 'slug' => 'crm-basic', 'description' => 'CRM basic', 'price_onetime' => 500000, 'price_monthly' => 150000, 'features' => 'Contact, Pipeline, Tasks'],
        ['division_id' => 3, 'name' => 'CRM Custom', 'slug' => 'crm-custom', 'description' => 'CRM custom', 'price_onetime' => 1000000, 'price_monthly' => 300000, 'features' => 'Custom fields, Automation, API'],
        ['division_id' => 3, 'name' => 'WhatsApp Automation', 'slug' => 'wa-automation', 'description' => 'Otomasi WA', 'price_onetime' => 0, 'price_monthly' => 250000, 'features' => 'Auto-reply, Scheduled messages'],
        ['division_id' => 3, 'name' => 'Email Automation', 'slug' => 'email-automation', 'description' => 'Automated emails', 'price_onetime' => 0, 'price_monthly' => 200000, 'features' => 'Drip campaigns, Triggers'],
        ['division_id' => 3, 'name' => 'AI Business Dashboard', 'slug' => 'ai-dashboard', 'description' => 'Dashboard AI', 'price_onetime' => 500000, 'price_monthly' => 400000, 'features' => 'Real-time, Predictions, KPIs'],
        ['division_id' => 3, 'name' => 'Lead Nurturing', 'slug' => 'lead-nurturing', 'description' => 'Lead nurturing otomatis', 'price_onetime' => 0, 'price_monthly' => 300000, 'features' => 'Lead scoring, Auto-follow-up'],
        
        // Division 4: Branding & Design (5 services)
        ['division_id' => 4, 'name' => 'Logo Design Basic', 'slug' => 'logo-basic', 'description' => 'Logo profesional', 'price_onetime' => 250000, 'price_monthly' => 0, 'features' => '3 konsep, 2 revisi, Source files'],
        ['division_id' => 4, 'name' => 'Logo Design Premium', 'slug' => 'logo-premium', 'description' => 'Logo premium', 'price_onetime' => 500000, 'price_monthly' => 0, 'features' => '5 konsep, Unlimited revisi, Guidelines'],
        ['division_id' => 4, 'name' => 'Brand Guidelines', 'slug' => 'brand-guidelines', 'description' => 'Panduan brand', 'price_onetime' => 800000, 'price_monthly' => 0, 'features' => 'Logo, Colors, Typography, Examples'],
        ['division_id' => 4, 'name' => 'Rebranding', 'slug' => 'rebranding', 'description' => 'Refresh brand identity', 'price_onetime' => 1500000, 'price_monthly' => 0, 'features' => 'Audit, Redesign, Guidelines, Collateral'],
        ['division_id' => 4, 'name' => 'Social Media Design Kit', 'slug' => 'sm-design-kit', 'description' => 'Template social media', 'price_onetime' => 0, 'price_monthly' => 300000, 'features' => '20 templates/month, Editable'],
    ];
}

function getServicesByDivision($divisionId) {
    $allServices = getAllServices();
    return array_values(array_filter($allServices, function($service) use ($divisionId) {
        return $service['division_id'] == $divisionId;
    }));
}

function getServiceBySlug($slug) {
    $allServices = getAllServices();
    foreach ($allServices as $service) {
        if ($service['slug'] === $slug) {
            return $service;
        }
    }
    return null;
}
