<?php
if (!defined('ALLOWED')) die('Direct access not permitted');
function getRevenueReportAPI($startDate, $endDate) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT DATE(created_at) as date, SUM(total_amount) as revenue FROM orders WHERE payment_status = 'verified' AND created_at BETWEEN ? AND ? GROUP BY DATE(created_at) ORDER BY date ASC");
    $stmt->execute([$startDate, $endDate]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
function getCommissionReportAPI($startDate, $endDate) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT DATE(c.created_at) as date, SUM(c.amount) as total_commission, COUNT(*) as count FROM commissions c WHERE c.created_at BETWEEN ? AND ? GROUP BY DATE(c.created_at) ORDER BY date ASC");
    $stmt->execute([$startDate, $endDate]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>