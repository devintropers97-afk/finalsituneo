<?php
if (!defined('ALLOWED')) die('Direct access not permitted');
function getUserAPI($userId) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT id, name, email, phone, role, email_verified, created_at FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}
function updateUserAPI($userId, $data) {
    global $pdo;
    $allowed = ['name', 'phone'];
    $updates = [];
    $values = [];
    foreach ($allowed as $field) {
        if (isset($data[$field])) {
            $updates[] = "$field = ?";
            $values[] = $data[$field];
        }
    }
    if (empty($updates)) return false;
    $values[] = $userId;
    $stmt = $pdo->prepare("UPDATE users SET " . implode(', ', $updates) . " WHERE id = ?");
    return $stmt->execute($values);
}
?>