<?php
if (!defined('ALLOWED')) die('Direct access not permitted');
function uploadPaymentProofAPI($orderId, $file) {
    global $pdo;
    $validation = validateImageUpload($file);
    if (!$validation['valid']) {
        return ['success' => false, 'message' => $validation['error']];
    }
    
    $upload = uploadFile($file, UPLOADS_PAYMENTS_PATH, 'payment_' . $orderId);
    if (!$upload['success']) {
        return ['success' => false, 'message' => 'Upload failed'];
    }
    
    $stmt = $pdo->prepare("UPDATE payments SET proof_image = ?, status = 'pending' WHERE order_id = ?");
    $stmt->execute([$upload['filename'], $orderId]);
    
    return ['success' => true, 'filename' => $upload['filename']];
}
?>