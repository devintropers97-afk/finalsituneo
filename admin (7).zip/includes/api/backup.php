<?php
if (!defined('ALLOWED')) die('Direct access not permitted');
function createBackup() {
    global $pdo;
    $backupFile = __DIR__ . '/../../backups/backup_' . date('Y-m-d_H-i-s') . '.sql';
    
    $tables = [];
    $result = $pdo->query("SHOW TABLES");
    while ($row = $result->fetch(PDO::FETCH_NUM)) {
        $tables[] = $row[0];
    }
    
    $output = "-- Database Backup\n-- Date: " . date('Y-m-d H:i:s') . "\n\n";
    
    foreach ($tables as $table) {
        $result = $pdo->query("SELECT * FROM $table");
        $output .= "-- Table: $table\n";
        $output .= "DELETE FROM $table;\n";
        
        while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
            $values = array_map(function($v) use ($pdo) {
                return $pdo->quote($v);
            }, array_values($row));
            $output .= "INSERT INTO $table VALUES (" . implode(', ', $values) . ");\n";
        }
        $output .= "\n";
    }
    
    file_put_contents($backupFile, $output);
    return $backupFile;
}
?>