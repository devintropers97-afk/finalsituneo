<?php
if (!defined('ALLOWED')) die('Direct access not permitted');
function optimizeImage($sourcePath, $destPath, $quality = 85) {
    $imageInfo = getimagesize($sourcePath);
    $mimeType = $imageInfo['mime'];
    
    switch ($mimeType) {
        case 'image/jpeg':
            $image = imagecreatefromjpeg($sourcePath);
            imagejpeg($image, $destPath, $quality);
            break;
        case 'image/png':
            $image = imagecreatefrompng($sourcePath);
            imagepng($image, $destPath, 9);
            break;
        default:
            return false;
    }
    
    imagedestroy($image);
    return true;
}
?>