<?php
if (!defined('ALLOWED')) die('Direct access not permitted');
function getServicesAPI($divisionId = null) {
    if ($divisionId) {
        return getServicesByDivision($divisionId);
    }
    return getAllServices();
}
function getServiceDetailsAPI($serviceId) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT s.*, d.name as division_name FROM services s LEFT JOIN divisions d ON s.division_id = d.id WHERE s.id = ?");
    $stmt->execute([$serviceId]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}
?>