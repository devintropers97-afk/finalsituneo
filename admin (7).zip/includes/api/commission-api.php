<?php
if (!defined('ALLOWED')) die('Direct access not permitted');
function getCommissionsAPI($freelancerId, $status = null) {
    global $pdo;
    $sql = "SELECT c.*, o.order_number, s.name as service_name FROM commissions c 
            LEFT JOIN orders o ON c.order_id = o.id 
            LEFT JOIN services s ON o.service_id = s.id 
            WHERE c.freelancer_id = ?";
    $params = [$freelancerId];
    
    if ($status) {
        $sql .= " AND c.status = ?";
        $params[] = $status;
    }
    
    $sql .= " ORDER BY c.created_at DESC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>