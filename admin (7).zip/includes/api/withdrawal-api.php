<?php
if (!defined('ALLOWED')) die('Direct access not permitted');
function requestWithdrawalAPI($freelancerId, $amount, $bankData) {
    global $pdo;
    
    $stmt = $pdo->prepare("SELECT SUM(amount) as balance FROM commissions WHERE freelancer_id = ? AND status = 'approved'");
    $stmt->execute([$freelancerId]);
    $data = $stmt->fetch();
    $balance = $data['balance'] ?? 0;
    
    if ($amount > $balance) {
        return ['success' => false, 'message' => 'Saldo tidak mencukupi'];
    }
    
    if ($amount < 50000) {
        return ['success' => false, 'message' => 'Minimum withdrawal Rp 50.000'];
    }
    
    $stmt = $pdo->prepare("INSERT INTO withdrawals (freelancer_id, amount, bank_name, account_number, account_holder, status, created_at) VALUES (?, ?, ?, ?, ?, 'pending', NOW())");
    $stmt->execute([$freelancerId, $amount, $bankData['bank'], $bankData['account'], $bankData['holder']]);
    
    return ['success' => true, 'withdrawal_id' => $pdo->lastInsertId()];
}
?>