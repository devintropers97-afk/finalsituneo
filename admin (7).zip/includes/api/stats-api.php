<?php
if (!defined('ALLOWED')) die('Direct access not permitted');
function getDashboardStatsAPI($userId, $role) {
    global $pdo;
    $stats = [];
    
    if ($role === 'admin') {
        $stmt = $pdo->query("SELECT COUNT(*) as total FROM users");
        $stats['total_users'] = $stmt->fetchColumn();
        
        $stmt = $pdo->query("SELECT COUNT(*) as total FROM orders");
        $stats['total_orders'] = $stmt->fetchColumn();
        
        $stmt = $pdo->query("SELECT SUM(total_amount) as total FROM orders WHERE payment_status = 'verified'");
        $stats['total_revenue'] = $stmt->fetchColumn() ?? 0;
        
        $stmt = $pdo->query("SELECT COUNT(*) as total FROM payments WHERE status = 'pending'");
        $stats['pending_payments'] = $stmt->fetchColumn();
    }
    
    return $stats;
}
?>