<?php
if (!defined('ALLOWED')) die('Direct access not permitted');
function addToQueue($type, $data) {
    global $pdo;
    $stmt = $pdo->prepare("INSERT INTO email_queue (to_email, subject, body, status, created_at) VALUES (?, ?, ?, 'pending', NOW())");
    return $stmt->execute([$data['to'], $data['subject'], $data['body']]);
}
function processQueue($limit = 10) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM email_queue WHERE status = 'pending' ORDER BY created_at ASC LIMIT ?");
    $stmt->execute([$limit]);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($items as $item) {
        $sent = sendEmail($item['to_email'], $item['subject'], $item['body']);
        $status = $sent ? 'sent' : 'failed';
        $pdo->prepare("UPDATE email_queue SET status = ?, sent_at = NOW() WHERE id = ?")->execute([$status, $item['id']]);
    }
    
    return count($items);
}
?>