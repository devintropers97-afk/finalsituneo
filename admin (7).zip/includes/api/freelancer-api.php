<?php
if (!defined('ALLOWED')) die('Direct access not permitted');
function getFreelancerStatsAPI($userId) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM freelancers WHERE user_id = ?");
    $stmt->execute([$userId]);
    $freelancer = $stmt->fetch(PDO::FETCH_ASSOC);
    
    $stmt = $pdo->prepare("SELECT SUM(amount) as total_commission FROM commissions WHERE freelancer_id = ? AND status = 'approved'");
    $stmt->execute([$userId]);
    $commissionData = $stmt->fetch(PDO::FETCH_ASSOC);
    
    return [
        'tier' => $freelancer['tier'],
        'commission_rate' => $freelancer['commission_rate'],
        'referral_code' => $freelancer['referral_code'],
        'total_orders' => $freelancer['total_orders_all_time'],
        'total_commission' => $commissionData['total_commission'] ?? 0
    ];
}
?>