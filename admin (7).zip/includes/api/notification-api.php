<?php
if (!defined('ALLOWED')) die('Direct access not permitted');
function getNotificationsAPI($userId, $unreadOnly = false) {
    global $pdo;
    $sql = "SELECT * FROM notifications WHERE user_id = ?";
    if ($unreadOnly) $sql .= " AND read_at IS NULL";
    $sql .= " ORDER BY created_at DESC LIMIT 20";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$userId]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
function markNotificationReadAPI($notificationId) {
    global $pdo;
    $stmt = $pdo->prepare("UPDATE notifications SET read_at = NOW() WHERE id = ?");
    return $stmt->execute([$notificationId]);
}
?>