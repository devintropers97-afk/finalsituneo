<?php
if (!defined('ALLOWED')) die('Direct access not permitted');
function createOrderAPI($userId, $serviceId, $referralCode = null) {
    global $pdo;
    try {
        $pdo->beginTransaction();
        
        $freelancerId = null;
        if ($referralCode) {
            $stmt = $pdo->prepare("SELECT user_id FROM freelancers WHERE referral_code = ?");
            $stmt->execute([$referralCode]);
            $freelancer = $stmt->fetch();
            if ($freelancer) $freelancerId = $freelancer['user_id'];
        }
        
        $stmt = $pdo->prepare("SELECT * FROM services WHERE id = ?");
        $stmt->execute([$serviceId]);
        $service = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$service) throw new Exception('Service not found');
        
        $orderNumber = generateOrderNumber();
        $stmt = $pdo->prepare("INSERT INTO orders (order_number, user_id, freelancer_id, service_id, total_amount, status, payment_status, created_at) VALUES (?, ?, ?, ?, ?, 'pending', 'pending', NOW())");
        $stmt->execute([$orderNumber, $userId, $freelancerId, $serviceId, $service['price_onetime']]);
        $orderId = $pdo->lastInsertId();
        
        $pdo->commit();
        return ['success' => true, 'order_id' => $orderId, 'order_number' => $orderNumber];
    } catch (Exception $e) {
        $pdo->rollBack();
        return ['success' => false, 'message' => $e->getMessage()];
    }
}
?>