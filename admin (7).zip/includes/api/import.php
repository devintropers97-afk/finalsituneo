<?php
if (!defined('ALLOWED')) die('Direct access not permitted');
function importFromCSV($file, $table, $mapping) {
    global $pdo;
    
    if (($handle = fopen($file, 'r')) !== FALSE) {
        $header = fgetcsv($handle);
        $imported = 0;
        
        while (($data = fgetcsv($handle)) !== FALSE) {
            $row = array_combine($header, $data);
            $values = [];
            foreach ($mapping as $dbField => $csvField) {
                $values[$dbField] = $row[$csvField] ?? null;
            }
            
            $fields = implode(', ', array_keys($values));
            $placeholders = implode(', ', array_fill(0, count($values), '?'));
            $stmt = $pdo->prepare("INSERT INTO $table ($fields) VALUES ($placeholders)");
            
            if ($stmt->execute(array_values($values))) {
                $imported++;
            }
        }
        
        fclose($handle);
        return ['success' => true, 'imported' => $imported];
    }
    
    return ['success' => false, 'message' => 'Failed to read file'];
}
?>