<?php
/**
 * Homepage - SITUNEO DIGITAL
 * FIXED VERSION - No more 403 error
 */

// CRITICAL: Define ALLOWED before requiring config
define('ALLOWED', true);

// Require config
require_once __DIR__ . '/config/app.php';

$pageTitle = 'Home';
$additionalCSS = [];

// Include header
require_once __DIR__ . '/components/layout/header.php';
?>

<div class="container-fluid px-0">
    <!-- Hero Section -->
    <div class="hero-section" style="min-height: 600px; background: linear-gradient(135deg, #0F3057 0%, #1E5C99 100%); display: flex; align-items: center; padding: 80px 0;">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 text-white mb-5 mb-lg-0">
                    <h1 class="display-3 fw-bold mb-4" style="font-family: 'Plus Jakarta Sans', sans-serif;">
                        Digital Harmony for a Modern World
                    </h1>
                    <p class="lead mb-4" style="font-size: 1.25rem; opacity: 0.9;">
                        Your trusted partner for professional digital solutions. NIB-registered and committed to excellence.
                    </p>
                    <div class="d-flex gap-3 flex-wrap">
                        <a href="<?php echo SITE_URL; ?>/pages/public/services.php" class="btn btn-lg px-5 py-3" style="background: linear-gradient(135deg, #FFD700 0%, #FFB400 100%); border: none; color: #0F3057; font-weight: 600; border-radius: 10px; box-shadow: 0 4px 15px rgba(255, 180, 0, 0.4);">
                            <i class="bi bi-grid-3x3-gap me-2"></i>Explore Services
                        </a>
                        <a href="<?php echo SITE_URL; ?>/pages/auth/register.php" class="btn btn-outline-light btn-lg px-5 py-3" style="border: 2px solid rgba(255, 255, 255, 0.5); border-radius: 10px;">
                            Get Started Free
                        </a>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="position-relative">
                        <div style="background: rgba(255, 255, 255, 0.1); backdrop-filter: blur(20px); border-radius: 20px; padding: 40px; border: 1px solid rgba(255, 180, 0, 0.3);">
                            <i class="bi bi-rocket-takeoff text-warning" style="font-size: 8rem;"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Features Section -->
    <div class="container py-5 my-5">
        <div class="text-center mb-5">
            <h2 class="display-5 fw-bold text-white mb-3">Why Choose SITUNEO DIGITAL?</h2>
            <p class="text-white-50 lead">Professional, registered, and trusted by businesses</p>
        </div>
        
        <div class="row g-4">
            <div class="col-md-4">
                <div class="card h-100" style="background: rgba(15, 48, 87, 0.8); backdrop-filter: blur(20px); border: 1px solid rgba(255, 180, 0, 0.3); border-radius: 20px;">
                    <div class="card-body text-center p-5">
                        <div class="mb-4">
                            <i class="bi bi-shield-check" style="font-size: 4rem; color: #FFD700;"></i>
                        </div>
                        <h4 class="text-white mb-3">NIB Registered</h4>
                        <p class="text-white-50">Officially registered business with NIB certification. Legal and trustworthy.</p>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="card h-100" style="background: rgba(15, 48, 87, 0.8); backdrop-filter: blur(20px); border: 1px solid rgba(255, 180, 0, 0.3); border-radius: 20px;">
                    <div class="card-body text-center p-5">
                        <div class="mb-4">
                            <i class="bi bi-people-fill" style="font-size: 4rem; color: #FFD700;"></i>
                        </div>
                        <h4 class="text-white mb-3">Professional Team</h4>
                        <p class="text-white-50">Experienced professionals ready to help you succeed.</p>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="card h-100" style="background: rgba(15, 48, 87, 0.8); backdrop-filter: blur(20px); border: 1px solid rgba(255, 180, 0, 0.3); border-radius: 20px;">
                    <div class="card-body text-center p-5">
                        <div class="mb-4">
                            <i class="bi bi-currency-dollar" style="font-size: 4rem; color: #FFD700;"></i>
                        </div>
                        <h4 class="text-white mb-3">Earn Commission</h4>
                        <p class="text-white-50">Join as freelancer and earn attractive commissions with our tier system.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- CTA Section -->
    <div class="container py-5 my-5">
        <div class="card" style="background: linear-gradient(135deg, #FFD700 0%, #FFB400 100%); border: none; border-radius: 20px;">
            <div class="card-body text-center p-5">
                <h2 class="fw-bold mb-3" style="color: #0F3057;">Ready to Get Started?</h2>
                <p class="mb-4" style="color: #0F3057; opacity: 0.8; font-size: 1.1rem;">Join thousands of satisfied clients and start your digital journey today.</p>
                <a href="<?php echo SITE_URL; ?>/pages/auth/register.php" class="btn btn-lg px-5 py-3" style="background: #0F3057; color: white; border: none; border-radius: 10px; font-weight: 600;">
                    <i class="bi bi-person-plus me-2"></i>Register Now
                </a>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/components/layout/footer.php'; ?>
