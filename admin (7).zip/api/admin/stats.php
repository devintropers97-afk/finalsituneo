<?php
define("ALLOWED", true);
require_once __DIR__ . "/../../config/app.php";
header("Content-Type: application/json");
if ($_SERVER["REQUEST_METHOD"] !== "GET") { errorResponse("Invalid method", 405); }
// admin/stats.php implementation
errorResponse("Not implemented yet");
?>