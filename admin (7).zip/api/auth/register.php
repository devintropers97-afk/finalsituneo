<?php
define('ALLOWED', true);
require_once __DIR__ . '/../../config/app.php';
header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { errorResponse('Invalid method', 405); }
requireCSRF();
$name = $_POST['name'] ?? '';
$email = $_POST['email'] ?? '';
$phone = $_POST['phone'] ?? '';
$password = $_POST['password'] ?? '';
$role = $_POST['role'] ?? '';
if (empty($name) || empty($email) || empty($phone) || empty($password) || empty($role)) {
    errorResponse('All fields required');
}
if (!validateEmail($email)) { errorResponse('Invalid email'); }
if (!validatePassword($password)) { errorResponse('Password too weak'); }
global $pdo;
$stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
$stmt->execute([$email]);
if ($stmt->fetch()) { errorResponse('Email already exists'); }
try {
    $pdo->beginTransaction();
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    $verificationToken = generateVerificationToken();
    $stmt = $pdo->prepare("INSERT INTO users (name, email, phone, password, role, verification_token, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())");
    $stmt->execute([$name, $email, $phone, $hashedPassword, $role, $verificationToken]);
    $userId = $pdo->lastInsertId();
    if ($role === 'freelancer') {
        require_once __DIR__ . '/../../includes/freelancer/onboarding.php';
        createFreelancerProfile($userId);
    }
    sendVerificationEmail($email, $name, $verificationToken);
    $pdo->commit();
    successResponse('Registration successful! Please check your email to verify.');
} catch (Exception $e) {
    $pdo->rollBack();
    errorResponse('Registration failed: ' . $e->getMessage());
}
