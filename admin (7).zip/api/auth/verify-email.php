<?php
// auth/verify-email.php - GET endpoint
define("ALLOWED", true);
require_once __DIR__ . "/../../config/app.php";
header("Content-Type: application/json");
?>