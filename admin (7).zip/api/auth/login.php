<?php
define('ALLOWED', true);
require_once __DIR__ . '/../../config/app.php';
header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { errorResponse('Invalid method', 405); }
requireCSRF();
$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';
if (empty($email) || empty($password)) { errorResponse('Email and password required'); }
global $pdo;
$stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
$stmt->execute([$email]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$user || !password_verify($password, $user['password'])) { errorResponse('Invalid credentials'); }
if (!$user['email_verified']) { errorResponse('Please verify your email first'); }
initSession();
$_SESSION['user_id'] = $user['id'];
$_SESSION['user_role'] = $user['role'];
$_SESSION['user_name'] = $user['name'];
successResponse('Login successful', ['redirect' => getDashboardUrl($user['role'])]);
