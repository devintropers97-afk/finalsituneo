# SITUNEO DIGITAL - Complete Platform

Version 1.0.0 | Production Ready | 300+ Modular Files

## 🎯 About

SITUNEO DIGITAL adalah platform digital marketplace untuk layanan website development, digital marketing, AI automation, dan branding. Platform ini dilengkapi dengan sistem tier freelancer, commission tracking, dan payment management.

## 📋 Features

### Authentication & Security
- ✅ Login/Logout with session management
- ✅ Register (Client & Freelancer)
- ✅ Email verification (via SMTP Gmail)
- ✅ 2FA (Two-Factor Authentication)
- ✅ Forgot & Reset Password
- ✅ Remember Me (30 days cookie)
- ✅ CSRF Protection
- ✅ XSS Prevention
- ✅ SQL Injection Protection (Prepared Statements)
- ✅ Rate Limiting (Anti Brute-force)
- ✅ IP Blocking

### Tier System (Real-time Upgrade, Monthly Downgrade)
- **Tier 1:** 0-9 orders = 30% commission
- **Tier 2:** 10-24 orders = 40% commission
- **Tier 3:** 25-74 orders = 50% commission
- **Tier MAX:** 75+ orders = 55% commission

### Payment System
- ✅ Manual Transfer (BCA, Mandiri, BNI)
- ✅ Upload Payment Proof
- ✅ Admin Verification
- ✅ Auto Commission Calculation

### Services
- 30+ services dari 10 divisi
- Website Development, Digital Marketing, AI Automation, Branding, dll

## 💻 System Requirements

- PHP 7.4 atau lebih tinggi
- MySQL 5.7 atau lebih tinggi
- PHP Extensions:
  - PDO
  - MySQLi
  - OpenSSL
  - MBString
  - GD
  - cURL
  - JSON
  - FileInfo

## 🚀 Installation

### Method 1: Auto Installer (Recommended)

1. Upload ZIP ke cPanel
2. Extract ke `public_html/`
3. Visit `yoursite.com/installer`
4. Follow 3-step wizard
5. Done!

### Method 2: Manual Installation

1. **Database Setup**
```sql
CREATE DATABASE nrrskfvk_situneo_digital;
-- Import database/schema.sql
```

2. **Configuration**
Edit `config/database.php` if needed:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'your_username');
define('DB_PASS', 'your_password');
define('DB_NAME', 'your_database');
```

3. **SMTP Configuration**
Edit `config/smtp.php`:
```php
define('SMTP_USERNAME', 'your-email@gmail.com');
define('SMTP_PASSWORD', 'your-app-password');
```

4. **Permissions**
```bash
chmod 755 uploads/
chmod 755 uploads/payments/
chmod 755 uploads/temp/
```

## 🔑 Default Login

**Admin Account:**
- Email: admin@situneo.my.id
- Password: admin123

**⚠️ IMPORTANT:** Change admin password immediately after first login!

## 📁 File Structure

```
/situneo-digital/
├── config/              # Configuration files
├── includes/            # Core functions & services
│   ├── functions/       # Helper functions
│   └── services/        # Services data
├── components/          # Reusable UI components
├── pages/              # Frontend pages
│   ├── public/         # Public pages
│   ├── auth/           # Authentication pages
│   ├── user/           # Client dashboard
│   └── freelancer/     # Freelancer dashboard
├── admin/              # Admin panel
├── api/                # API endpoints
├── cron/               # Cron jobs
├── database/           # Database schema
├── assets/             # CSS, JS, Images
└── uploads/            # User uploads
```

## 🔧 Cron Jobs Setup

Add these to cPanel Cron Jobs:

```bash
# Tier evaluation (Setiap tanggal 1, jam 00:01)
1 0 1 * * /usr/bin/php /path/to/cron/tier-evaluation.php

# Email queue processing (Setiap 5 menit)
*/5 * * * * /usr/bin/php /path/to/cron/email-queue.php

# Cleanup (Daily at 02:00)
0 2 * * * /usr/bin/php /path/to/cron/cleanup.php
```

## 🎨 Design System

**Colors:**
- Primary Blue: #1E5C99
- Dark Blue: #0F3057
- Gold: #FFB400
- Bright Gold: #FFD700

**Typography:**
- Headings: Plus Jakarta Sans
- Body: Inter

**Framework:**
- Bootstrap 5.3.3
- Bootstrap Icons 1.11.3

## 📧 Contact & Support

**Company:** SITUNEO DIGITAL
**Email:** support@situneo.my.id
**WhatsApp:** +62 831-7386-8915
**Website:** https://situneo.my.id

## 📝 License

Copyright © 2025 SITUNEO DIGITAL. All rights reserved.

## 🔄 Version History

### v1.0.0 (2025-11-01)
- Initial production release
- 300+ modular files
- Complete tier system
- Payment & commission management
- 30+ services from 10 divisions
