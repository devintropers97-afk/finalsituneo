<?php
define('ALLOWED', true);
require_once __DIR__ . '/../config/app.php';
requireAdmin();
$pageTitle = 'Admin Dashboard';
require_once __DIR__ . '/../components/layout/header.php';
require_once __DIR__ . '/../components/layout/sidebar.php';
global $pdo;
$totalUsers = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$totalOrders = $pdo->query("SELECT COUNT(*) FROM orders")->fetchColumn();
$totalRevenue = $pdo->query("SELECT SUM(total_amount) FROM orders WHERE payment_status='verified'")->fetchColumn() ?? 0;
$pendingPayments = $pdo->query("SELECT COUNT(*) FROM payments WHERE status='pending'")->fetchColumn();
?>
<div class="container-fluid py-4">
    <h1 class="text-white mb-4">Admin Dashboard</h1>
    <div class="row g-4 mb-4">
        <div class="col-xl-3 col-md-6"><?php statCard('Total Users', $totalUsers, 'people', 'primary'); ?></div>
        <div class="col-xl-3 col-md-6"><?php statCard('Total Orders', $totalOrders, 'cart', 'success'); ?></div>
        <div class="col-xl-3 col-md-6"><?php statCard('Total Revenue', formatPrice($totalRevenue), 'currency-dollar', 'warning'); ?></div>
        <div class="col-xl-3 col-md-6"><?php statCard('Pending Payments', $pendingPayments, 'clock', 'danger'); ?></div>
    </div>
    <div class="row g-4">
        <div class="col-lg-8">
            <div class="card card-glass">
                <div class="card-body">
                    <h5 class="text-white mb-4">Recent Orders</h5>
                    <?php
                    $stmt = $pdo->query("SELECT o.*, u.name as user_name, s.name as service_name FROM orders o LEFT JOIN users u ON o.user_id = u.id LEFT JOIN services s ON o.service_id = s.id ORDER BY o.created_at DESC LIMIT 10");
                    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    if ($orders): ?>
                    <div class="table-responsive">
                        <table class="table table-dark table-sm">
                            <thead><tr><th>Order #</th><th>Customer</th><th>Service</th><th>Amount</th><th>Status</th></tr></thead>
                            <tbody>
                                <?php foreach ($orders as $o): ?>
                                <tr>
                                    <td><?php echo $o['order_number']; ?></td>
                                    <td><?php echo $o['user_name']; ?></td>
                                    <td><?php echo $o['service_name']; ?></td>
                                    <td><?php echo formatPrice($o['total_amount']); ?></td>
                                    <td><?php echo getStatusBadge($o['status']); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="card card-glass">
                <div class="card-body">
                    <h5 class="text-white mb-4">Quick Actions</h5>
                    <div class="d-grid gap-2">
                        <a href="users/create.php" class="btn btn-gradient-gold"><i class="bi bi-person-plus me-2"></i>Add User</a>
                        <a href="payments/pending.php" class="btn btn-outline-light"><i class="bi bi-credit-card me-2"></i>Pending Payments</a>
                        <a href="reports/revenue.php" class="btn btn-outline-light"><i class="bi bi-graph-up me-2"></i>View Reports</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<?php require_once __DIR__ . '/../components/layout/footer.php'; ?>
