<?php
define("ALLOWED", true);
require_once __DIR__ . "/../../config/app.php";
requireAdmin();
$pageTitle = "View Order";
require_once __DIR__ . "/../../components/layout/header.php";
require_once __DIR__ . "/../../components/layout/sidebar.php";
?>
<div class="container-fluid py-4"><h1 class="text-white">View Order</h1></div>
</div>
<?php require_once __DIR__ . "/../../components/layout/footer.php"; ?>