// Loading Overlay
function showLoader() {
    const loader = document.getElementById('globalLoader');
    if (!loader) {
        const div = document.createElement('div');
        div.id = 'globalLoader';
        div.style.cssText = 'position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(15,48,87,0.9); display: flex; align-items: center; justify-content: center; z-index: 99999;';
        div.innerHTML = '<div class="spinner-border text-warning" style="width: 3rem; height: 3rem;"></div>';
        document.body.appendChild(div);
    } else {
        loader.style.display = 'flex';
    }
}

function hideLoader() {
    const loader = document.getElementById('globalLoader');
    if (loader) loader.style.display = 'none';
}
