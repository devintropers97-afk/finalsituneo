// Form Validation
function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

function validatePhone(phone) {
    const re = /^(08|628|\+628|62)[0-9]{8,13}$/;
    return re.test(phone.replace(/[\s\-\(\)]/g, ''));
}

function validatePassword(password) {
    return password.length >= 8 && /[a-z]/.test(password) && /[A-Z]/.test(password) && /[0-9]/.test(password);
}

function setupFormValidation(formId) {
    const form = document.getElementById(formId);
    if (!form) return;
    
    form.addEventListener('submit', function(e) {
        const emailInputs = form.querySelectorAll('input[type="email"]');
        const phoneInputs = form.querySelectorAll('input[name*="phone"]');
        const passwordInputs = form.querySelectorAll('input[type="password"][name*="password"]:not([name*="confirm"])');
        
        let isValid = true;
        
        emailInputs.forEach(input => {
            if (!validateEmail(input.value)) {
                showError(input, 'Email tidak valid');
                isValid = false;
            }
        });
        
        phoneInputs.forEach(input => {
            if (!validatePhone(input.value)) {
                showError(input, 'Nomor telepon tidak valid');
                isValid = false;
            }
        });
        
        passwordInputs.forEach(input => {
            if (!validatePassword(input.value)) {
                showError(input, 'Password minimal 8 karakter, harus ada huruf besar, kecil, dan angka');
                isValid = false;
            }
        });
        
        if (!isValid) e.preventDefault();
    });
}

function showError(input, message) {
    input.classList.add('is-invalid');
    let feedback = input.nextElementSibling;
    if (!feedback || !feedback.classList.contains('invalid-feedback')) {
        feedback = document.createElement('div');
        feedback.className = 'invalid-feedback';
        input.parentNode.appendChild(feedback);
    }
    feedback.textContent = message;
}
