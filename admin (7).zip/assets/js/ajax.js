// AJAX Helper Functions
function ajaxRequest(url, method = 'GET', data = null) {
    return new Promise((resolve, reject) => {
        const xhr = new XMLHttpRequest();
        xhr.open(method, url, true);
        xhr.setRequestHeader('Content-Type', 'application/json');
        xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
        
        xhr.onload = function() {
            if (xhr.status >= 200 && xhr.status < 300) {
                try {
                    resolve(JSON.parse(xhr.responseText));
                } catch (e) {
                    resolve(xhr.responseText);
                }
            } else {
                reject(new Error(`Request failed with status ${xhr.status}`));
            }
        };
        
        xhr.onerror = function() {
            reject(new Error('Network error'));
        };
        
        if (data && method !== 'GET') {
            xhr.send(JSON.stringify(data));
        } else {
            xhr.send();
        }
    });
}

function handleAjaxResponse(response, successCallback, errorCallback) {
    if (response.success) {
        if (successCallback) successCallback(response);
        if (response.message) showNotification('success', response.message);
    } else {
        if (errorCallback) errorCallback(response);
        if (response.message) showNotification('danger', response.message);
    }
}
