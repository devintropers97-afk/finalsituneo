// Notification System
let notificationCount = 0;

function showNotification(type, message) {
    const container = document.getElementById('notificationContainer');
    if (!container) {
        const div = document.createElement('div');
        div.id = 'notificationContainer';
        div.style.cssText = 'position: fixed; top: 20px; right: 20px; z-index: 9999; width: 350px;';
        document.body.appendChild(div);
    }
    
    const notification = document.createElement('div');
    notification.className = `alert alert-${type} alert-dismissible fade show`;
    notification.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.getElementById('notificationContainer').appendChild(notification);
    
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => notification.remove(), 300);
    }, 5000);
}

function fetchNotifications() {
    fetch('/api/notifications/fetch.php')
        .then(res => res.json())
        .then(data => {
            updateNotificationBadge(data.unread_count);
            updateNotificationDropdown(data.notifications);
        })
        .catch(err => console.error('Failed to fetch notifications:', err));
}

function updateNotificationBadge(count) {
    notificationCount = count;
    const badge = document.querySelector('.notification-badge');
    if (badge) {
        badge.textContent = count;
        badge.style.display = count > 0 ? 'flex' : 'none';
    }
}

function updateNotificationDropdown(notifications) {
    const dropdown = document.querySelector('.notification-dropdown');
    if (!dropdown) return;
    
    if (notifications.length === 0) {
        dropdown.innerHTML = '<li><p class="dropdown-item text-center text-muted">Tidak ada notifikasi</p></li>';
    } else {
        dropdown.innerHTML = notifications.map(n => `
            <li><a class="dropdown-item" href="${n.link}">
                <i class="bi bi-${n.icon} me-2"></i>${n.message}
                <br><small class="text-muted">${n.time_ago}</small>
            </a></li>
        `).join('');
    }
}

// Auto-refresh notifications every 30 seconds
setInterval(fetchNotifications, 30000);
