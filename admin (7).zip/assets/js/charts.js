// Chart Configuration
function createLineChart(elementId, data, categories, title) {
    const options = {
        series: [{
            name: title,
            data: data
        }],
        chart: {
            type: 'line',
            height: 350,
            background: 'transparent',
            toolbar: { show: false }
        },
        xaxis: {
            categories: categories,
            labels: { style: { colors: '#fff' } }
        },
        yaxis: {
            labels: { style: { colors: '#fff' } }
        },
        stroke: {
            curve: 'smooth',
            width: 3,
            colors: ['#FFD700']
        },
        grid: {
            borderColor: 'rgba(255,180,0,0.1)'
        },
        tooltip: {
            theme: 'dark'
        }
    };
    
    const chart = new ApexCharts(document.querySelector(`#${elementId}`), options);
    chart.render();
    return chart;
}

function createBarChart(elementId, data, categories, title) {
    const options = {
        series: [{
            name: title,
            data: data
        }],
        chart: {
            type: 'bar',
            height: 350,
            background: 'transparent',
            toolbar: { show: false }
        },
        plotOptions: {
            bar: {
                borderRadius: 8,
                distributed: true
            }
        },
        dataLabels: { enabled: false },
        xaxis: {
            categories: categories,
            labels: { style: { colors: '#fff' } }
        },
        yaxis: {
            labels: { style: { colors: '#fff' } }
        },
        colors: ['#FFD700', '#FFB400', '#1E5C99', '#0F3057'],
        grid: {
            borderColor: 'rgba(255,180,0,0.1)'
        },
        tooltip: {
            theme: 'dark'
        }
    };
    
    const chart = new ApexCharts(document.querySelector(`#${elementId}`), options);
    chart.render();
    return chart;
}

function createDonutChart(elementId, data, labels, title) {
    const options = {
        series: data,
        chart: {
            type: 'donut',
            height: 350,
            background: 'transparent'
        },
        labels: labels,
        colors: ['#FFD700', '#FFB400', '#1E5C99', '#0F3057'],
        legend: {
            labels: { colors: '#fff' }
        },
        dataLabels: {
            dropShadow: { enabled: false }
        },
        tooltip: {
            theme: 'dark'
        }
    };
    
    const chart = new ApexCharts(document.querySelector(`#${elementId}`), options);
    chart.render();
    return chart;
}
