<?php
class ElasticsearchClient {
    private $host = 'localhost:9200';
    
    public function search($index, $query) {
        $url = "http://{$this->host}/{$index}/_search";
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(['query' => $query]));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        curl_close($ch);
        return json_decode($response, true);
    }
}
?>