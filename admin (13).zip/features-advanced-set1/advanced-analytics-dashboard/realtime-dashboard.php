<?php
require_once "../../config/database.php";
require_once "../../includes/functions.php";
requireAdmin();

$realtime_data = [
    'active_users' => getActiveUsers(),
    'current_orders' => getCurrentOrders(),
    'revenue_today' => getRevenue Today(),
];

header('Content-Type: application/json');
echo json_encode($realtime_data);
?>