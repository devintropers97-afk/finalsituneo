<?php
$redis_config = [
    'host' => 'localhost',
    'port' => 6379,
    'password' => '',
    'database' => 0,
    'prefix' => 'situneo_'
];

try {
    $redis = new Redis();
    $redis->connect($redis_config['host'], $redis_config['port']);
} catch(Exception $e) {
    error_log('Redis connection failed: ' . $e->getMessage());
}
?>