<?php
/**
 * Login Backend - FIXED REDIRECTS + ROLE VALIDATION
 */

session_start();
require_once __DIR__ . "/config/database.php";

// Check if already logged in
if (isset($_SESSION['user_id'])) {
    $role = $_SESSION['user_role'];
    if ($role === 'admin') {
        header('Location: /admin/dashboard/index.php');
    } elseif ($role === 'partner') {
        header('Location: /partner/dashboard/index.php');
    } else {
        header('Location: /client/dashboard/index.php');
    }
    exit;
}

$errors = [];

// Process login
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $role = trim($_POST['role'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    
    // Validation
    if (empty($role)) {
        $errors['role'] = 'Silakan pilih role';
    } elseif (!in_array($role, ['admin', 'client', 'partner'])) {
        $errors['role'] = 'Role tidak valid';
    }
    
    if (empty($email)) {
        $errors['email'] = 'Email harus diisi';
    }
    
    if (empty($password)) {
        $errors['password'] = 'Password harus diisi';
    }
    
    // If no errors, check database
    if (empty($errors)) {
        try {
            $stmt = $db->prepare("SELECT id, name, email, password, role, status FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch();
            
            if ($user) {
                // Check if role matches
                if ($user['role'] !== $role) {
                    $errors['general'] = 'Role yang dipilih tidak sesuai dengan akun Anda';
                } 
                // Check password
                elseif (!password_verify($password, $user['password'])) {
                    $errors['general'] = 'Email atau password salah';
                } 
                // Check status
                elseif ($user['status'] !== 'active') {
                    $errors['general'] = 'Akun Anda belum aktif atau diblokir';
                } 
                else {
                    // Login success!
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['user_name'] = $user['name'];
                    $_SESSION['user_email'] = $user['email'];
                    $_SESSION['user_role'] = $user['role'];
                    
                    // Update last login
                    $update = $db->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
                    $update->execute([$user['id']]);
                    
                    // Redirect based on role
                    if ($user['role'] === 'admin') {
                        header('Location: /admin/dashboard/index.php');
                    } elseif ($user['role'] === 'partner') {
                        header('Location: /partner/dashboard/index.php');
                    } else {
                        header('Location: /client/dashboard/index.php');
                    }
                    exit;
                }
            } else {
                $errors['general'] = 'Email atau password salah';
            }
        } catch (Exception $e) {
            $errors['general'] = 'Terjadi kesalahan sistem. Silakan coba lagi.';
            error_log('Login error: ' . $e->getMessage());
        }
    }
}

// If there are errors, redirect back to login with errors
if (!empty($errors)) {
    $_SESSION['login_errors'] = $errors;
    header('Location: /login.php');
    exit;
}
