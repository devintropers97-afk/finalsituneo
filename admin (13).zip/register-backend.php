<?php
/**
 * Register Backend - Process Registration
 * With Simple Partner Form (Only 6 Fields!)
 */

session_start();
require_once __DIR__ . "/config/database.php";

$errors = [];
$old = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get input
    $role = trim($_POST['role'] ?? '');
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';
    $password_confirmation = $_POST['password_confirmation'] ?? '';
    $agree = isset($_POST['agree']);
    
    // Partner extra fields (SIMPLE!)
    $city = trim($_POST['city'] ?? '');
    $experience = trim($_POST['experience'] ?? '');
    
    // Store old input (except password)
    $old = compact('role', 'name', 'email', 'phone', 'city', 'experience');
    
    // Validation
    if (empty($role)) {
        $errors['role'] = 'Silakan pilih role';
    } elseif (!in_array($role, ['client', 'partner'])) {
        $errors['role'] = 'Role tidak valid';
    }
    
    if (empty($name)) {
        $errors['name'] = 'Nama harus diisi';
    }
    
    if (empty($email)) {
        $errors['email'] = 'Email harus diisi';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Format email tidak valid';
    } else {
        // Check if email exists
        try {
            $stmt = $db->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$email]);
            if ($stmt->fetch()) {
                $errors['email'] = 'Email sudah terdaftar';
            }
        } catch (Exception $e) {
            $errors['general'] = 'Terjadi kesalahan sistem';
            error_log('Email check error: ' . $e->getMessage());
        }
    }
    
    if (empty($phone)) {
        $errors['phone'] = 'Nomor WhatsApp harus diisi';
    }
    
    // Partner validation (SIMPLE!)
    if ($role === 'partner' && empty($city)) {
        $errors['city'] = 'Domisili harus diisi untuk partner';
    }
    
    if (empty($password)) {
        $errors['password'] = 'Password harus diisi';
    } elseif (strlen($password) < 6) {
        $errors['password'] = 'Password minimal 6 karakter';
    }
    
    if ($password !== $password_confirmation) {
        $errors['password'] = 'Konfirmasi password tidak cocok';
    }
    
    if (!$agree) {
        $errors['agree'] = 'Anda harus menyetujui syarat & ketentuan';
    }
    
    // If no errors, insert to database
    if (empty($errors)) {
        try {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            // Prepare data
            $userData = [
                'name' => $name,
                'email' => $email,
                'phone' => $phone,
                'password' => $hashed_password,
                'role' => $role,
                'status' => 'active'
            ];
            
            // Add partner extra data to JSON field (if needed in your DB structure)
            // Or create separate columns if you prefer
            $partnerData = null;
            if ($role === 'partner') {
                $partnerData = json_encode([
                    'city' => $city,
                    'experience' => $experience
                ]);
            }
            
            // Insert to users table
            $stmt = $db->prepare("
                INSERT INTO users (name, email, phone, password, role, status, created_at) 
                VALUES (?, ?, ?, ?, ?, 'active', NOW())
            ");
            
            $stmt->execute([
                $name,
                $email,
                $phone,
                $hashed_password,
                $role
            ]);
            
            // Registration success!
            $user_id = $db->lastInsertId();
            
            // If partner, save additional data (optional - adjust based on your DB structure)
            if ($role === 'partner' && !empty($city)) {
                try {
                    // Check if partner_profiles table exists, if not just skip
                    $checkTable = $db->query("SHOW TABLES LIKE 'partner_profiles'");
                    if ($checkTable->rowCount() > 0) {
                        $partnerStmt = $db->prepare("
                            INSERT INTO partner_profiles (user_id, city, experience, created_at) 
                            VALUES (?, ?, ?, NOW())
                        ");
                        $partnerStmt->execute([$user_id, $city, $experience]);
                    }
                } catch (Exception $e) {
                    // Table doesn't exist, that's okay - partner data saved in main users table
                    error_log('Partner profile save skipped: ' . $e->getMessage());
                }
            }
            
            // Auto login
            $_SESSION['user_id'] = $user_id;
            $_SESSION['user_name'] = $name;
            $_SESSION['user_email'] = $email;
            $_SESSION['user_role'] = $role;
            
            // Redirect based on role
            if ($role === 'partner') {
                header('Location: /partner/dashboard/index.php?welcome=1');
            } else {
                header('Location: /client/dashboard/index.php?welcome=1');
            }
            exit;
            
        } catch (Exception $e) {
            $errors['general'] = 'Terjadi kesalahan sistem. Silakan coba lagi.';
            error_log('Register error: ' . $e->getMessage());
        }
    }
}

// If errors, redirect back
if (!empty($errors)) {
    $_SESSION['register_errors'] = $errors;
    $_SESSION['old_input'] = $old;
    header('Location: /register.php');
    exit;
}
