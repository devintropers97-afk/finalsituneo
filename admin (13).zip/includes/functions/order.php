<?php
/**
 * Order Management Functions
 */

function createOrder($data) {
    return dbInsert('orders', $data);
}

function getOrder($id) {
    return dbFetch("SELECT o.*, u.name as client_name, s.name as service_name FROM orders o JOIN users u ON o.user_id = u.id JOIN services s ON o.service_id = s.id WHERE o.id = ?", [$id]);
}

function getAllOrders($status = null) {
    if($status) {
        return dbFetchAll("SELECT o.*, u.name as client_name FROM orders o JOIN users u ON o.user_id = u.id WHERE o.status = ? ORDER BY o.created_at DESC", [$status]);
    }
    return dbFetchAll("SELECT o.*, u.name as client_name FROM orders o JOIN users u ON o.user_id = u.id ORDER BY o.created_at DESC");
}

function updateOrderStatus($order_id, $status) {
    return dbUpdate('orders', ['status' => $status, 'updated_at' => date('Y-m-d H:i:s')], 'id = ?', [$order_id]);
}

function getOrdersByUser($user_id) {
    return dbFetchAll("SELECT o.*, s.name as service_name FROM orders o JOIN services s ON o.service_id = s.id WHERE o.user_id = ? ORDER BY o.created_at DESC", [$user_id]);
}

function getRecentOrders($limit = 10) {
    return dbFetchAll("SELECT o.*, u.name as client_name FROM orders o JOIN users u ON o.user_id = u.id ORDER BY o.created_at DESC LIMIT ?", [$limit]);
}

function getOrderDetails($order_id) {
    return getOrder($order_id);
}

function getOrderTracking($order_id) {
    return dbFetchAll("SELECT * FROM order_tracking WHERE order_id = ? ORDER BY created_at DESC", [$order_id]);
}
?>