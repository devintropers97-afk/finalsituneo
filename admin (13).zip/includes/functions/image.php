<?php
function resizeImage($source, $dest, $width, $height) {
    list($w, $h) = getimagesize($source);
    $ratio = min($width/$w, $height/$h);
    $nw = $w * $ratio;
    $nh = $h * $ratio;
    
    $img = imagecreatefromjpeg($source);
    $newimg = imagecreatetruecolor($nw, $nh);
    imagecopyresampled($newimg, $img, 0, 0, 0, 0, $nw, $nh, $w, $h);
    imagejpeg($newimg, $dest, 90);
    
    imagedestroy($img);
    imagedestroy($newimg);
}
?>