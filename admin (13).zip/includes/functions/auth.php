<?php
/**
 * Authentication Functions
 */

function login($email, $password) {
    global $conn;
    $stmt = $conn->prepare("SELECT id, name, email, password, role, status FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password']) && $user['status'] === 'active') {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['name'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['user_role'] = $user['role'];
            return true;
        }
    }
    return false;
}

function logout() {
    session_destroy();
    setcookie('remember_token', '', time() - 3600, '/');
}

function register($data) {
    global $conn;
    $password_hash = password_hash($data['password'], PASSWORD_BCRYPT);
    $stmt = $conn->prepare("INSERT INTO users (name, email, password, phone, role, status) VALUES (?, ?, ?, ?, 'client', 'active')");
    $stmt->bind_param("ssss", $data['name'], $data['email'], $password_hash, $data['phone']);
    return $stmt->execute();
}
?>