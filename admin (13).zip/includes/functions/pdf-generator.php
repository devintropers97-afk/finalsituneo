<?php
function generatePDF($html, $filename) {
    require_once "../../vendor/autoload.php";
    
    $pdf = new TCPDF();
    $pdf->AddPage();
    $pdf->SetFont('helvetica', '', 12);
    $pdf->writeHTML($html, true, false, true, false, '');
    
    return $pdf->Output($filename, 'S'); // return as string
}
?>