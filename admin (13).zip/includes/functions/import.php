<?php
function importCSV($file, $table) {
    global $db;
    $handle = fopen($file, 'r');
    $count = 0;
    
    $headers = fgetcsv($handle);
    
    while(($data = fgetcsv($handle)) !== FALSE) {
        $placeholders = str_repeat('?,', count($data) - 1) . '?';
        $db->prepare("INSERT INTO $table VALUES ($placeholders)")->execute($data);
        $count++;
    }
    
    fclose($handle);
    return $count;
}
?>