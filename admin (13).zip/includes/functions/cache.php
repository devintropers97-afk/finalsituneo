<?php
function cacheGet($key){$file="../../cache/$key.cache";return file_exists($file)?unserialize(file_get_contents($file)):null;}
function cacheSet($key,$value,$ttl=3600){file_put_contents("../../cache/$key.cache",serialize($value));}