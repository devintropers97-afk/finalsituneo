<?php
function generateSitemap() {
    global $db;
    
    $urls = [];
    $urls[] = SITE_URL;
    $urls[] = SITE_URL . '/services';
    $urls[] = SITE_URL . '/about';
    $urls[] = SITE_URL . '/contact';
    
    $services = $db->query("SELECT slug FROM services WHERE status='active'")->fetchAll();
    foreach($services as $s) {
        $urls[] = SITE_URL . '/services/' . $s['slug'];
    }
    
    return $urls;
}
?>