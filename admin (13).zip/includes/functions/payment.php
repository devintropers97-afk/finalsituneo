<?php
function processPayment($order_id, $payment_method) {
    global $db;
    
    // Get order details
    $order = $db->prepare("SELECT * FROM orders WHERE id=?")->execute([$order_id])->fetch();
    
    // Process based on payment method
    if($payment_method === 'midtrans') {
        return processMidtrans($order);
    } elseif($payment_method === 'manual') {
        return processManualPayment($order);
    }
    
    return false;
}
?>