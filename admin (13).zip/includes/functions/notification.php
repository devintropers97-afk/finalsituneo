<?php
function sendNotification($user_id, $title, $message) {
    global $db;
    $db->prepare("INSERT INTO notifications (user_id, title, message, created_at) VALUES (?, ?, ?, NOW())")
       ->execute([$user_id, $title, $message]);
}
?>