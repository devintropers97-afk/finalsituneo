<?php
function determineTier($total_orders) {
    if($total_orders >= 100) return 'platinum';
    if($total_orders >= 50) return 'gold';
    if($total_orders >= 20) return 'silver';
    return 'bronze';
}

function getCommissionRate($tier) {
    $rates = [
        'bronze' => 30,
        'silver' => 40,
        'gold' => 50,
        'platinum' => 55
    ];
    return $rates[$tier] ?? 30;
}
?>