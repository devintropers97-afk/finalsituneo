<?php
function logError($message, $context = []) {
    $log_file = "../../logs/error.log';
    $timestamp = date('Y-m-d H:i:s');
    $context_str = json_encode($context);
    file_put_contents($log_file, "[$timestamp] $message $context_str\n", FILE_APPEND);
}
?>