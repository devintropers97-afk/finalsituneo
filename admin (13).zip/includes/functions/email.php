<?php
function sendEmail($to, $subject, $body) {
    $headers = "From: " . MAIL_FROM_ADDRESS . "\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
    
    return mail($to, $subject, $body, $headers);
}
?>