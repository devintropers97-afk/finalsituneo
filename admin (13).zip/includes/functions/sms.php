<?php
function sendSMS($phone, $message) {
    // Implement SMS gateway integration
    // Example: Twilio, Nexmo, etc.
    return true;
}
?>