<?php
function trackPageView($page) {
    global $db;
    $db->prepare("INSERT INTO page_views (page, ip_address, user_agent, created_at) VALUES (?, ?, ?, NOW())")
       ->execute([$page, $_SERVER['REMOTE_ADDR'], $_SERVER['HTTP_USER_AGENT']]);
}
?>