<?php
/**
 * Validation Functions
 */

function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function validatePhone($phone) {
    return preg_match('/^(\+62|62|0)[0-9]{9,12}$/', $phone);
}

function validatePassword($password) {
    return strlen($password) >= 8;
}

function sanitizeInput($input) {
    return htmlspecialchars(strip_tags(trim($input)), ENT_QUOTES, 'UTF-8');
}
?>