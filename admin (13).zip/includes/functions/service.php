<?php
/**
 * Service Management Functions
 */

function getService($id) {
    return dbFetch("SELECT * FROM services WHERE id = ?", [$id]);
}

function getAllServices($category_id = null) {
    if($category_id) {
        return dbFetchAll("SELECT * FROM services WHERE category_id = ? AND status = 'active' ORDER BY name", [$category_id]);
    }
    return dbFetchAll("SELECT * FROM services WHERE status = 'active' ORDER BY name");
}

function createService($data) {
    return dbInsert('services', $data);
}

function updateService($id, $data) {
    return dbUpdate('services', $data, 'id = ?', [$id]);
}

function deleteService($id) {
    return dbUpdate('services', ['status' => 'inactive'], 'id = ?', [$id]);
}

function getServicesByCategory() {
    return dbFetchAll("SELECT c.name as category, s.* FROM services s JOIN categories c ON s.category_id = c.id WHERE s.status = 'active' ORDER BY c.name, s.name");
}
?>