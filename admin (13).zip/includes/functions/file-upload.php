<?php
function uploadFile($file, $destination) {
    $allowed = ['jpg', 'jpeg', 'png', 'pdf', 'doc', 'docx'];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    
    if(!in_array($ext, $allowed)) {
        return false;
    }
    
    $filename = uniqid() . '.' . $ext;
    $path = $destination . '/' . $filename;
    
    return move_uploaded_file($file['tmp_name'], $path) ? $filename : false;
}
?>