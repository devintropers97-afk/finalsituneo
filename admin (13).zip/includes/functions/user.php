<?php
/**
 * User Management Functions
 */

function getUser($id) {
    return dbFetch("SELECT * FROM users WHERE id = ?", [$id]);
}

function getUserByEmail($email) {
    return dbFetch("SELECT * FROM users WHERE email = ?", [$email]);
}

function getAllUsers($role = null) {
    if($role) {
        return dbFetchAll("SELECT * FROM users WHERE role = ? ORDER BY created_at DESC", [$role]);
    }
    return dbFetchAll("SELECT * FROM users ORDER BY created_at DESC");
}

function updateUser($id, $data) {
    return dbUpdate('users', $data, 'id = ?', [$id]);
}

function deleteUser($id) {
    return dbDelete('users', 'id = ?', [$id]);
}

function getUserStats($user_id) {
    $stats = [];
    $stats['total_orders'] = dbFetch("SELECT COUNT(*) as count FROM orders WHERE user_id = ?", [$user_id])['count'];
    $stats['total_spent'] = dbFetch("SELECT SUM(total_amount) as total FROM orders WHERE user_id = ? AND status = 'completed'", [$user_id])['total'] ?? 0;
    return $stats;
}
?>