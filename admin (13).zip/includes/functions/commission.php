<?php
function calculateCommission($order_id) {
    global $db;
    
    $order = $db->prepare("SELECT * FROM orders WHERE id=?")->execute([$order_id])->fetch();
    $partner = $db->prepare("SELECT * FROM users WHERE id=?")->execute([$order['partner_id']])->fetch();
    
    $rate = getCommissionRate($partner['tier']);
    $amount = $order['total_amount'] * ($rate / 100);
    
    $db->prepare("INSERT INTO commissions (partner_id, order_id, amount, rate, status, created_at) VALUES (?, ?, ?, ?, 'pending', NOW())")
       ->execute([$order['partner_id'], $order_id, $amount, $rate]);
}
?>