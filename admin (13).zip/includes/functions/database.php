<?php
/**
 * Database Helper Functions
 */

function dbQuery($query, $params = []) {
    global $db;
    $stmt = $db->prepare($query);
    $stmt->execute($params);
    return $stmt;
}

function dbFetch($query, $params = []) {
    return dbQuery($query, $params)->fetch(PDO::FETCH_ASSOC);
}

function dbFetchAll($query, $params = []) {
    return dbQuery($query, $params)->fetchAll(PDO::FETCH_ASSOC);
}

function dbInsert($table, $data) {
    global $db;
    $fields = implode(', ', array_keys($data));
    $placeholders = implode(', ', array_fill(0, count($data), '?'));
    $query = "INSERT INTO $table ($fields) VALUES ($placeholders)";
    return $db->prepare($query)->execute(array_values($data));
}

function dbUpdate($table, $data, $where, $whereParams = []) {
    global $db;
    $set = implode(', ', array_map(fn($k) => "$k = ?", array_keys($data)));
    $query = "UPDATE $table SET $set WHERE $where";
    return $db->prepare($query)->execute(array_merge(array_values($data), $whereParams));
}

function dbDelete($table, $where, $params = []) {
    global $db;
    $query = "DELETE FROM $table WHERE $where";
    return $db->prepare($query)->execute($params);
}
?>