<?php
/**
 * Core Functions - FIXED REDIRECTS
 */

// Determine base path
$base_path = dirname(__DIR__);

// Include function files if they exist
$function_files = [
    'auth.php', 'validation.php', 'security.php', 'database.php',
    'user.php', 'service.php', 'order.php', 'commission.php',
    'payment.php', 'notification.php', 'email.php', 'file-upload.php', 'tier.php'
];

foreach ($function_files as $file) {
    $path = $base_path . "/includes/functions/" . $file;
    if (file_exists($path)) {
        require_once $path;
    }
}

/**
 * Check if user is logged in
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

/**
 * Get current user ID
 */
function getCurrentUserId() {
    return $_SESSION['user_id'] ?? null;
}

/**
 * Get current user role
 */
function getCurrentUserRole() {
    return $_SESSION['user_role'] ?? null;
}

/**
 * Check if user is admin
 */
function isAdmin() {
    return getCurrentUserRole() === 'admin';
}

/**
 * Check if user is client
 */
function isClient() {
    return getCurrentUserRole() === 'client';
}

/**
 * Check if user is partner
 */
function isPartner() {
    return getCurrentUserRole() === 'partner';
}

/**
 * Require login - FIXED REDIRECT!
 */
function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: /login.php');
        exit;
    }
}

/**
 * Require admin - FIXED REDIRECT!
 */
function requireAdmin() {
    requireLogin();
    if (!isAdmin()) {
        header('Location: /');
        exit;
    }
}

/**
 * Require partner - FIXED REDIRECT!
 */
function requirePartner() {
    requireLogin();
    if (!isPartner()) {
        header('Location: /');
        exit;
    }
}

/**
 * Redirect helper
 */
function redirectTo($url) {
    header("Location: $url");
    exit;
}

/**
 * Flash message
 */
function setFlashMessage($type, $message) {
    $_SESSION['flash_type'] = $type;
    $_SESSION['flash_message'] = $message;
}

function getFlashMessage() {
    if (isset($_SESSION['flash_message'])) {
        $type = $_SESSION['flash_type'] ?? 'info';
        $message = $_SESSION['flash_message'];
        unset($_SESSION['flash_type'], $_SESSION['flash_message']);
        return ['type' => $type, 'message' => $message];
    }
    return null;
}

/**
 * Format currency
 */
function formatCurrency($amount) {
    return 'Rp ' . number_format($amount, 0, ',', '.');
}

/**
 * Format date
 */
function formatDate($date, $format = 'd M Y') {
    if (empty($date)) return '-';
    return date($format, strtotime($date));
}

/**
 * Sanitize input
 */
function sanitize($input) {
    return htmlspecialchars(strip_tags(trim($input)), ENT_QUOTES, 'UTF-8');
}

/**
 * Generate random string
 */
function generateRandomString($length = 32) {
    return bin2hex(random_bytes($length / 2));
}

/**
 * Check request method
 */
function isPost() {
    return $_SERVER['REQUEST_METHOD'] === 'POST';
}

function isGet() {
    return $_SERVER['REQUEST_METHOD'] === 'GET';
}

/**
 * Get data helpers
 */
function post($key, $default = null) {
    return $_POST[$key] ?? $default;
}

function get($key, $default = null) {
    return $_GET[$key] ?? $default;
}

/**
 * Logger
 */
function logMessage($message, $level = 'INFO') {
    $log_dir = dirname(__DIR__) . '/logs';
    if (!is_dir($log_dir)) {
        @mkdir($log_dir, 0755, true);
    }
    $log_file = $log_dir . '/app.log';
    $timestamp = date('Y-m-d H:i:s');
    $log_message = "[$timestamp] [$level] $message" . PHP_EOL;
    @file_put_contents($log_file, $log_message, FILE_APPEND);
}