<div class="card bg-dark text-white">
<div class="card-body text-center">
<img src="<?= $user["avatar"] ?? "https://ui-avatars.com/api/?name=" . urlencode($user["name"]) ?>" class="rounded-circle mb-2" width="80">
<h5><?= $user["name"] ?></h5>
<p class="text-muted"><?= $user["email"] ?></p>
</div>
</div>