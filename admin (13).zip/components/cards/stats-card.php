<div class="card stat-card shadow-sm">
    <div class="card-body text-center">
        <i class="<?= $icon ?> fa-3x mb-3 text-primary"></i>
        <h3><?= $value ?></h3>
        <p class="text-muted"><?= $label ?></p>
    </div>
</div>