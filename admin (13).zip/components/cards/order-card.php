<div class="card order-card">
    <div class="card-body">
        <div class="d-flex justify-content-between">
            <div>
                <h5>Order #<?= $order['id'] ?></h5>
                <p><?= $order['service_name'] ?></p>
            </div>
            <div>
                <span class="badge badge-<?= $order['status'] ?>"><?= $order['status'] ?></span>
            </div>
        </div>
        <hr>
        <p><strong>Rp <?= number_format($order['amount'], 0, ',', '.') ?></strong></p>
        <small class="text-muted"><?= date('d M Y', strtotime($order['created_at'])) ?></small>
    </div>
</div>