<style>
.sidebar {
    position: fixed;
    top: 0;
    left: 0;
    height: 100vh;
    width: 250px;
    background: linear-gradient(135deg, #1E5C99 0%, #0F3057 100%);
    padding: 20px;
    overflow-y: auto;
}
.sidebar a {
    display: block;
    color: rgba(255, 255, 255, 0.8);
    padding: 12px 15px;
    text-decoration: none;
    border-radius: 10px;
    margin-bottom: 5px;
}
.sidebar a:hover { background: rgba(255, 255, 255, 0.1); }
</style>
<div class="sidebar">
    <h4 class="text-white mb-4">SITUNEO</h4>
    <a href="/admin/dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
    <a href="/admin/users/list.php"><i class="bi bi-people"></i> Users</a>
    <a href="/admin/services/list.php"><i class="bi bi-grid"></i> Services</a>
    <a href="/admin/orders/list.php"><i class="bi bi-cart"></i> Orders</a>
    <a href="/admin/commissions/list.php"><i class="bi bi-cash"></i> Commissions</a>
    <a href="/admin/settings/general.php"><i class="bi bi-gear"></i> Settings</a>
    <a href="/logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a>
</div>
