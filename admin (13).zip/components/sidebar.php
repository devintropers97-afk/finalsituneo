<div class="sidebar">
    <ul class="nav flex-column">
        <li class="nav-item">
            <a class="nav-link" href="dashboard/"><i class="fas fa-home"></i> Dashboard</a>
        </li>
        <?php if(getCurrentUserRole() === 'admin'): ?>
        <li class="nav-item">
            <a class="nav-link" href="users/"><i class="fas fa-users"></i> Users</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="services/"><i class="fas fa-briefcase"></i> Services</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="orders/"><i class="fas fa-shopping-cart"></i> Orders</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="reports/"><i class="fas fa-chart-bar"></i> Reports</a>
        </li>
        <?php endif; ?>
    </ul>
</div>