<div class="stats-widget card">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h3 class="mb-0"><?= $value ?></h3>
                <p class="text-muted mb-0"><?= $label ?></p>
            </div>
            <div class="icon-box">
                <i class="<?= $icon ?>"></i>
            </div>
        </div>
        <?php if(isset($change)): ?>
        <small class="text-<?= $change >= 0 ? 'success' : 'danger' ?>">
            <?= $change >= 0 ? '+' : '' ?><?= $change ?>% from last month
        </small>
        <?php endif; ?>
    </div>
</div>