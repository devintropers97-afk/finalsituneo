<div class="revenue-widget card">
    <div class="card-header">
        <h5>Revenue Overview</h5>
    </div>
    <div class="card-body">
        <h2>Rp <?= number_format($total_revenue, 0, ',', '.') ?></h2>
        <canvas id="revenueChart"></canvas>
    </div>
</div>
<script>
new Chart(document.getElementById('revenueChart'), {
    type: 'line',
    data: { labels: <?= json_encode($labels) ?>, datasets: [{ data: <?= json_encode($data) ?> }] }
});
</script>