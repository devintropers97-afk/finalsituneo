<div class="notifications">
<?php foreach($notifications as $notif): ?>
<div class="notification-item <?= $notif["is_read"] ? "" : "unread" ?>">
<i class="bi <?= $notif["icon"] ?? "bi-bell" ?>"></i>
<div class="notification-content">
<p class="notification-title"><?= $notif["title"] ?></p>
<small class="text-muted"><?= formatRelativeTime($notif["created_at"]) ?></small>
</div>
</div>
<?php endforeach; ?>
</div>