<div class="sidebar">
<h4 class="text-white mb-4">Client Menu</h4>
<a href="/client/dashboard.php"><i class="bi bi-house"></i> Dashboard</a>
<a href="/client/services/browse.php"><i class="bi bi-grid"></i> Browse Services</a>
<a href="/client/cart/view.php"><i class="bi bi-cart"></i> My Cart</a>
<a href="/client/orders/list.php"><i class="bi bi-box"></i> My Orders</a>
<a href="/client/profile/edit.php"><i class="bi bi-person"></i> Profile</a>
<a href="/logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a>
</div>