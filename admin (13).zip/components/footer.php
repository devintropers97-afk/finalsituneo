<footer class="mt-5 py-4 bg-dark text-white">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <h5>SITUNEO</h5>
                <p>Platform digital services terpercaya di Indonesia</p>
            </div>
            <div class="col-md-4">
                <h5>Quick Links</h5>
                <ul class="list-unstyled">
                    <li><a href="/services" class="text-white">Services</a></li>
                    <li><a href="/about" class="text-white">About</a></li>
                    <li><a href="/contact" class="text-white">Contact</a></li>
                </ul>
            </div>
            <div class="col-md-4">
                <h5>Contact</h5>
                <p>Email: info@situneo.my.id<br>Phone: +62 831 7386 8915</p>
            </div>
        </div>
        <hr class="bg-white">
        <p class="text-center mb-0">&copy; <?= date('Y') ?> SITUNEO. All rights reserved.</p>
    </div>
</footer>
</body>
</html>