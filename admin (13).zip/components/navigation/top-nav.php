<nav class="navbar navbar-dark bg-dark">
<div class="container">
<a class="navbar-brand" href="/">SITUNEO</a>
<ul class="navbar-nav flex-row">
<li class="nav-item"><a class="nav-link" href="/pages/services.php">Services</a></li>
<li class="nav-item"><a class="nav-link" href="/pages/about.php">About</a></li>
<li class="nav-item"><a class="nav-link" href="/pages/contact.php">Contact</a></li>
<li class="nav-item"><a class="nav-link" href="/login.php">Login</a></li>
</ul>
</div>
</nav>