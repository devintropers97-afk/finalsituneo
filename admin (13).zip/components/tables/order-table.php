<table class="table table-dark table-striped">
<thead><tr><th>Order #</th><th>Amount</th><th>Status</th><th>Date</th><th>Actions</th></tr></thead>
<tbody>
<?php foreach($orders as $order): ?>
<tr>
<td><?= $order["order_number"] ?></td>
<td><?= formatRupiah($order["final_amount"]) ?></td>
<td><?= $order["status"] ?></td>
<td><?= formatDate($order["created_at"]) ?></td>
<td><a href="#" class="btn btn-sm btn-info">View</a></td>
</tr>
<?php endforeach; ?>
</tbody>
</table>