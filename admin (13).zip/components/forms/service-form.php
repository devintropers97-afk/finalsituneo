<form method="post" enctype="multipart/form-data">
<div class="mb-3"><label>Service Name</label><input name="name" class="form-control" required></div>
<div class="mb-3"><label>Category</label><select name="category_id" class="form-control"><?php foreach($categories as $cat): ?><option value="<?= $cat["id"] ?>"><?= $cat["name"] ?></option><?php endforeach; ?></select></div>
<div class="mb-3"><label>Description</label><textarea name="description" class="form-control" rows="4"></textarea></div>
<div class="row"><div class="col-md-6 mb-3"><label>Setup Price</label><input name="price_setup" type="number" class="form-control"></div><div class="col-md-6 mb-3"><label>Monthly Price</label><input name="price_monthly" type="number" class="form-control"></div></div>
<button type="submit" class="btn btn-primary">Save Service</button>
</form>