<?php
require_once "./config/database.php";
require_once "./includes/functions.php";

if(!isset($_GET['token'])) {
    redirectTo('/forgot-password.php');
}

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_GET['token'];
    $password = $_POST['password'];
    
    $user = $db->prepare("SELECT * FROM users WHERE reset_token=? AND reset_expires > NOW()")->execute([$token])->fetch();
    
    if($user) {
        $hashed = password_hash($password, PASSWORD_DEFAULT);
        $db->prepare("UPDATE users SET password=?, reset_token=NULL, reset_expires=NULL WHERE id=?")->execute([$hashed, $user['id']]);
        redirectTo('/login.php?msg=password_reset');
    }
}

include "./components/header.php";
?>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <h3>Reset Password</h3>
                    <form method="POST">
                        <div class="form-group">
                            <label>Password Baru</label>
                            <input type="password" name="password" class="form-control" required>
                        </div>
                        <button type="submit" class="btn btn-primary btn-block">Reset Password</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include "./components/footer.php"; ?>