<?php
require_once "./config/database.php";
require_once "./includes/functions.php";

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $user = $db->prepare("SELECT * FROM users WHERE email=?")->execute([$email])->fetch();
    
    if($user) {
        $token = bin2hex(random_bytes(32));
        $db->prepare("UPDATE users SET reset_token=?, reset_expires=DATE_ADD(NOW(), INTERVAL 1 HOUR) WHERE id=?")->execute([$token, $user['id']]);
        sendPasswordResetEmail($email, $token);
        $_SESSION['message'] = 'Reset link sent to your email';
    }
}

include "./components/header.php";
?>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <h3>Forgot Password</h3>
                    <form method="POST" class="mt-4">
                        <div class="form-group">
                            <label>Email:</label>
                            <input type="email" name="email" class="form-control" required>
                        </div>
                        <button class="btn btn-primary btn-block">Send Reset Link</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include "./components/footer.php"; ?>