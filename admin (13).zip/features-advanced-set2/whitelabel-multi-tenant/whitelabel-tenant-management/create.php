<?php
require_once "../../../config/database.php";
require_once "../../../includes/functions.php";
requireAdmin();

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $company_name = $_POST['company_name'];
    $subdomain = slugify($_POST['subdomain']);
    
    $db->prepare("INSERT INTO tenants (company_name, subdomain, created_at) VALUES (?, ?, NOW())")
       ->execute([$company_name, $subdomain]);
    
    redirectTo('/list.php');
}

include "../../../components/header.php";
?>
<div class="container-fluid">
    <h1>Create New Tenant</h1>
    <form method="POST" class="mt-4">
        <div class="form-group">
            <label>Company Name:</label>
            <input type="text" name="company_name" class="form-control" required>
        </div>
        <div class="form-group">
            <label>Subdomain:</label>
            <input type="text" name="subdomain" class="form-control" required>
        </div>
        <button class="btn btn-primary">Create Tenant</button>
    </form>
</div>
<?php include "../../../components/footer.php"; ?>