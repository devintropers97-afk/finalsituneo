<?php
require_once "../../../config/database.php";
require_once "../../../includes/functions.php";
requireAdmin();

$stages = $db->query("SELECT * FROM pipeline_stages ORDER BY order_num")->fetchAll();

include "../../../components/header.php";
?>
<div class="container-fluid">
    <h1>Pipeline Stages</h1>
    <a href="add-stage.php" class="btn btn-primary mb-3">Add Stage</a>
    <ul class="list-group">
        <?php foreach($stages as $stage): ?>
        <li class="list-group-item d-flex justify-content-between">
            <span><?= $stage['name'] ?> (<?= $stage['deal_count'] ?> deals)</span>
            <div>
                <a href="edit-stage.php?id=<?= $stage['id'] ?>">Edit</a>
                <a href="delete-stage.php?id=<?= $stage['id'] ?>" onclick="return confirm('Sure?')">Delete</a>
            </div>
        </li>
        <?php endforeach; ?>
    </ul>
</div>
<?php include "../../../components/footer.php"; ?>