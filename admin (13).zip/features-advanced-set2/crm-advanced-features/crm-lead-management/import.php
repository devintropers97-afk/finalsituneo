<?php
require_once "../../../config/database.php";
require_once "../../../includes/functions.php";
requireAdmin();

if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['csv'])) {
    $file = $_FILES['csv']['tmp_name'];
    $handle = fopen($file, 'r');
    $imported = 0;
    
    fgetcsv($handle); // Skip header
    while(($data = fgetcsv($handle)) !== FALSE) {
        $db->prepare("INSERT INTO leads (name, email, phone, source) VALUES (?,?,?,?)")
           ->execute([$data[0], $data[1], $data[2], 'import']);
        $imported++;
    }
    
    fclose($handle);
    $_SESSION['message'] = "Imported $imported leads";
    redirectTo('/list.php');
}

include "../../../components/header.php";
?>
<div class="container-fluid">
    <h1>Import Leads</h1>
    <form method="POST" enctype="multipart/form-data" class="mt-4">
        <div class="form-group">
            <label>Upload CSV File:</label>
            <input type="file" name="csv" class="form-control" accept=".csv" required>
        </div>
        <button class="btn btn-primary">Import</button>
    </form>
</div>
<?php include "../../../components/footer.php"; ?>