<?php
require_once "../../../config/database.php";
require_once "../../../includes/functions.php";
requireLogin();

$user_id = getCurrentUserId();

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $secret = generateTwoFactorSecret();
    $db->prepare("UPDATE users SET two_factor_secret=?, two_factor_enabled=1 WHERE id=?")->execute([$secret, $user_id]);
    redirectTo('/verify.php');
}

include "../../../components/header.php";
?>
<div class="container py-5">
    <h1>Enable Two-Factor Authentication</h1>
    <p>Scan this QR code with your authenticator app:</p>
    <img src="qr-code.php" alt="QR Code">
    <form method="POST" class="mt-4">
        <button class="btn btn-primary">Enable 2FA</button>
    </form>
</div>
<?php include "../../../components/footer.php"; ?>