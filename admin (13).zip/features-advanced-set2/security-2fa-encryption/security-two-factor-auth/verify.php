<?php
require_once "../../../config/database.php";
require_once "../../../includes/functions.php";
requireLogin();

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $code = $_POST['code'];
    if(verifyTwoFactorCode(getCurrentUserId(), $code)) {
        $_SESSION['2fa_verified'] = true;
        redirectTo('/dashboard');
    } else {
        $error = "Invalid code";
    }
}

include "../../../components/header.php";
?>
<div class="container py-5">
    <h1>Verify 2FA Code</h1>
    <?php if(isset($error)): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>
    <form method="POST">
        <div class="form-group">
            <label>Enter 6-digit code:</label>
            <input type="text" name="code" class="form-control" maxlength="6" required>
        </div>
        <button class="btn btn-primary">Verify</button>
    </form>
</div>
<?php include "../../../components/footer.php"; ?>