<?php
require_once "../../../config/database.php";
require_once "../../../includes/functions.php";
header('Content-Type: application/json');

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    $user_id = $data['user_id'];
    $device_token = $data['device_token'];
    $title = $data['title'];
    $message = $data['message'];
    
    $result = sendPushNotification($device_token, $title, $message);
    
    echo json_encode(['success' => $result]);
} else {
    echo json_encode(['error' => 'Method not allowed']);
}
?>