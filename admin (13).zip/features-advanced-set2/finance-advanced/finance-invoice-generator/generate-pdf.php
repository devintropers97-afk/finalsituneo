<?php
require_once "../../../config/database.php";
require_once "../../../includes/functions.php";
requireAdmin();

if(!isset($_GET['id'])) die('Invoice ID required');

$invoice_id = $_GET['id'];
$invoice = getInvoiceDetails($invoice_id);

require_once "../../../vendor/autoload.php";
$pdf = new TCPDF();
$pdf->AddPage();
$pdf->SetFont('helvetica', '', 12);

$html = generateInvoiceHTML($invoice);
$pdf->writeHTML($html, true, false, true, false, '');

$pdf->Output('invoice_' . $invoice_id . '.pdf', 'D');
?>