<?php
require_once "../../includes/init.php";
requireLogin();
?>
<h1>Marketing Materials</h1>
<p>Download banners, flyers, and promotional materials here</p>
<ul>
<li><a href="/assets/marketing/banner-1.jpg" download>Banner 1 (1920x1080)</a></li>
<li><a href="/assets/marketing/banner-2.jpg" download>Banner 2 (1200x628)</a></li>
<li><a href="/assets/marketing/flyer.pdf" download>Flyer PDF</a></li>
</ul>