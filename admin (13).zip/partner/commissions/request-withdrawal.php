<?php
require_once "../../includes/init.php";
requireLogin();
$user = getCurrentUser();
if($_SERVER["REQUEST_METHOD"] === "POST") {
$amount = $_POST["amount"];
$bank = $_POST["bank_name"];
$account = $_POST["account_number"];
$db->insert("withdrawal_requests", ["partner_id"=>$user["id"], "amount"=>$amount, "bank_name"=>$bank, "account_number"=>$account]);
setFlash("success", "Withdrawal request submitted");
redirect("list.php");
}