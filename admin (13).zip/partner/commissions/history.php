<?php
require_once "../../includes/init.php";
requireLogin();
$user = getCurrentUser();
$history = $db->fetchAll("SELECT * FROM commissions WHERE partner_id={$user['id']} ORDER BY created_at DESC");
?>
<h1>Commission History</h1>
<table class="table table-dark">
<tr><th>Order</th><th>Amount</th><th>Status</th><th>Date</th></tr>
<?php foreach($history as $h): ?>
<tr><td><?= $h['order_id'] ?></td><td><?= formatRupiah($h['commission_amount']) ?></td><td><?= $h['status'] ?></td><td><?= formatDate($h['created_at']) ?></td></tr>
<?php endforeach; ?>
</table>