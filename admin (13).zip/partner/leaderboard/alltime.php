<?php
require_once "../../config/database.php";
require_once "../../includes/functions.php";
requirePartner();

$leaders = $db->query("
    SELECT u.*, 
           COUNT(o.id) as total_orders,
           SUM(o.total_amount) as total_revenue,
           SUM(c.amount) as total_commission
    FROM users u
    LEFT JOIN orders o ON u.id = o.partner_id
    LEFT JOIN commissions c ON u.id = c.partner_id
    WHERE u.role = 'partner'
    GROUP BY u.id
    ORDER BY total_revenue DESC
    LIMIT 50
")->fetchAll();

include "../../components/header.php";
?>
<div class="container-fluid">
    <h1>All-Time Leaderboard</h1>
    <table class="table mt-4">
        <thead>
            <tr>
                <th>Rank</th>
                <th>Partner</th>
                <th>Orders</th>
                <th>Revenue</th>
                <th>Commission</th>
            </tr>
        </thead>
        <tbody>
            <?php $rank = 1; foreach($leaders as $leader): ?>
            <tr>
                <td><?= $rank++ ?></td>
                <td><?= $leader['name'] ?></td>
                <td><?= $leader['total_orders'] ?></td>
                <td>Rp <?= number_format($leader['total_revenue'], 0, ',', '.') ?></td>
                <td>Rp <?= number_format($leader['total_commission'], 0, ',', '.') ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php include "../../components/footer.php"; ?>