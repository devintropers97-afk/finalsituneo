<?php
require_once "../../config/database.php";
require_once "../../includes/functions.php";
requirePartner();

$partner_id = getCurrentUserId();
$stats = getReferralStats($partner_id);

include "../../components/header.php";
?>
<div class="container-fluid">
    <h1>Referral Statistics</h1>
    <div class="row mt-4">
        <div class="col-md-3">
            <div class="stat-card">
                <h3><?= $stats['total_referrals'] ?></h3>
                <p>Total Referrals</p>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stat-card">
                <h3><?= $stats['active_referrals'] ?></h3>
                <p>Active</p>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stat-card">
                <h3>Rp <?= number_format($stats['total_commission'], 0, ',', '.') ?></h3>
                <p>Total Commission</p>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stat-card">
                <h3><?= $stats['conversion_rate'] ?>%</h3>
                <p>Conversion Rate</p>
            </div>
        </div>
    </div>
</div>
<?php include "../../components/footer.php"; ?>