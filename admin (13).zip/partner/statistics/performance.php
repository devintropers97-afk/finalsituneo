<?php
require_once "../../config/database.php";
require_once "../../includes/functions.php";
requirePartner();

$partner_id = getCurrentUserId();
$stats = getPartnerPerformanceStats($partner_id);

include "../../components/header.php";
?>
<div class="container-fluid">
    <h1>Performance Statistics</h1>
    <div class="row mt-4">
        <div class="col-md-3">
            <div class="stat-card">
                <h3><?= $stats['conversion_rate'] ?>%</h3>
                <p>Conversion Rate</p>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stat-card">
                <h3><?= $stats['avg_order_value'] ?></h3>
                <p>Avg Order Value</p>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stat-card">
                <h3><?= $stats['customer_satisfaction'] ?>%</h3>
                <p>Customer Satisfaction</p>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stat-card">
                <h3><?= $stats['response_time'] ?>h</h3>
                <p>Avg Response Time</p>
            </div>
        </div>
    </div>
</div>
<?php include "../../components/footer.php"; ?>