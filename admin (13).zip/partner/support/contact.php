<?php
require_once "../../config/database.php";
require_once "../../includes/functions.php";
requirePartner();

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $subject = $_POST['subject'];
    $message = $_POST['message'];
    
    sendSupportTicket(getCurrentUserId(), $subject, $message);
    $_SESSION['message'] = 'Support ticket submitted';
    redirectTo('/list.php');
}

include "../../components/header.php";
?>
<div class="container-fluid">
    <h1>Contact Support</h1>
    <form method="POST" class="mt-4">
        <div class="form-group">
            <label>Subject:</label>
            <input type="text" name="subject" class="form-control" required>
        </div>
        <div class="form-group">
            <label>Message:</label>
            <textarea name="message" class="form-control" rows="5" required></textarea>
        </div>
        <button class="btn btn-primary">Submit</button>
    </form>
</div>
<?php include "../../components/footer.php"; ?>