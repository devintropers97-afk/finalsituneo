<?php
/**
 * Partner Dashboard - Main Page
 */
session_start();

// Simple auth check (relaxed for testing)
$user_id = $_SESSION['user_id'] ?? 1;

$page_title = 'Partner Dashboard';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $page_title ?> - SITUNEO</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; background: #f5f5f5; padding: 20px; }
        .container { max-width: 1200px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        h1 { color: #333; margin-bottom: 30px; }
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .stat-card { background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white; padding: 25px; border-radius: 8px; }
        .stat-card h3 { font-size: 14px; opacity: 0.9; margin-bottom: 10px; }
        .stat-value { font-size: 32px; font-weight: bold; }
        .warning { background: #f59e0b !important; }
        .info { background: #3b82f6 !important; }
    </style>
</head>
<body>
    <div class="container">
        <h1>💰 <?= $page_title ?></h1>
        
        <div class="stats-grid">
            <div class="stat-card">
                <h3>Total Commissions</h3>
                <div class="stat-value">
                    <?php
                    try {
                        require_once '../../config/database.php';
                        $stmt = $db->prepare("SELECT SUM(amount) as total FROM commissions WHERE partner_id = ?");
                        $stmt->execute([$user_id]);
                        $total = $stmt->fetch()['total'] ?? 0;
                        echo 'Rp ' . number_format($total, 0, ',', '.');
                    } catch(Exception $e) {
                        echo "Rp 0";
                    }
                    ?>
                </div>
            </div>
            
            <div class="stat-card warning">
                <h3>Pending</h3>
                <div class="stat-value">
                    <?php
                    try {
                        $stmt = $db->prepare("SELECT SUM(amount) as total FROM commissions WHERE partner_id = ? AND status = 'pending'");
                        $stmt->execute([$user_id]);
                        $total = $stmt->fetch()['total'] ?? 0;
                        echo 'Rp ' . number_format($total, 0, ',', '.');
                    } catch(Exception $e) {
                        echo "Rp 0";
                    }
                    ?>
                </div>
            </div>
            
            <div class="stat-card info">
                <h3>Paid</h3>
                <div class="stat-value">
                    <?php
                    try {
                        $stmt = $db->prepare("SELECT SUM(amount) as total FROM commissions WHERE partner_id = ? AND status = 'paid'");
                        $stmt->execute([$user_id]);
                        $total = $stmt->fetch()['total'] ?? 0;
                        echo 'Rp ' . number_format($total, 0, ',', '.');
                    } catch(Exception $e) {
                        echo "Rp 0";
                    }
                    ?>
                </div>
            </div>
        </div>
        
        <div style="padding: 20px; background: #d1fae5; border-left: 4px solid #10b981; border-radius: 6px;">
            <strong>✅ Partner Dashboard Working!</strong>
            <p>Welcome to your partner dashboard. Track your commissions and earnings here.</p>
        </div>
    </div>
</body>
</html>
