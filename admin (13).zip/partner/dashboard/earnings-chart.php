<?php
require_once "../../includes/init.php";
requireLogin();
$user = getCurrentUser();
$monthly = $db->fetchAll("SELECT DATE_FORMAT(created_at, '%Y-%m') as month, SUM(commission_amount) as total FROM commissions WHERE partner_id={$user['id']} AND status='paid' GROUP BY month");
echo json_encode($monthly);