<?php
require_once "../../config/database.php";
require_once "../../includes/functions.php";
requirePartner();

$partner_id = getCurrentUserId();
$orders = $db->prepare("
    SELECT o.*, u.name as client_name, s.name as service_name
    FROM orders o
    JOIN users u ON o.user_id = u.id
    JOIN services s ON o.service_id = s.id
    WHERE o.partner_id = ?
    ORDER BY o.created_at DESC
")->execute([$partner_id])->fetchAll();

include "../../components/header.php";
?>
<div class="container-fluid">
    <h1>My Orders</h1>
    <table class="table mt-4">
        <thead>
            <tr>
                <th>Order ID</th>
                <th>Client</th>
                <th>Service</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Date</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($orders as $order): ?>
            <tr>
                <td>#<?= $order['id'] ?></td>
                <td><?= $order['client_name'] ?></td>
                <td><?= $order['service_name'] ?></td>
                <td>Rp <?= number_format($order['total_amount'], 0, ',', '.') ?></td>
                <td><?= $order['status'] ?></td>
                <td><?= date('d M Y', strtotime($order['created_at'])) ?></td>
                <td><a href="detail.php?id=<?= $order['id'] ?>">View</a></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php include "../../components/footer.php"; ?>