<?php
require_once "../../includes/init.php";
requireLogin();
?>
<h1>Video Tutorials</h1>
<div class="row">
<div class="col-md-6"><iframe width="100%" height="315" src="https://www.youtube.com/embed/dQw4w9WgXcQ"></iframe><p>Getting Started</p></div>
<div class="col-md-6"><iframe width="100%" height="315" src="https://www.youtube.com/embed/dQw4w9WgXcQ"></iframe><p>Advanced Techniques</p></div>
</div>