<?php
require_once "../../config/database.php";
require_once "../../includes/functions.php";
requirePartner();

$resources = $db->query("SELECT * FROM training_resources ORDER BY category")->fetchAll();
include "../../components/header.php";
?>
<div class="container-fluid">
    <h1>Training Resources</h1>
    <div class="list-group mt-4">
        <?php foreach($resources as $resource): ?>
        <a href="<?= $resource['file_url'] ?>" class="list-group-item" target="_blank">
            <h5><?= $resource['title'] ?></h5>
            <p><?= $resource['description'] ?></p>
            <small>Category: <?= $resource['category'] ?></small>
        </a>
        <?php endforeach; ?>
    </div>
</div>
<?php include "../../components/footer.php"; ?>