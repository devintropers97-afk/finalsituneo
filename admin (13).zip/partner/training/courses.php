<?php
require_once "../../config/database.php";
require_once "../../includes/functions.php";
requirePartner();

$courses = $db->query("SELECT * FROM training_courses WHERE status='active'")->fetchAll();
include "../../components/header.php";
?>
<div class="container-fluid">
    <h1>Training Courses</h1>
    <div class="row mt-4">
        <?php foreach($courses as $course): ?>
        <div class="col-md-4 mb-4">
            <div class="card">
                <div class="card-body">
                    <h5><?= $course['title'] ?></h5>
                    <p><?= $course['description'] ?></p>
                    <a href="view.php?id=<?= $course['id'] ?>" class="btn btn-primary">Mulai Course</a>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php include "../../components/footer.php"; ?>