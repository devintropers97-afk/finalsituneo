<?php
require_once "../../config/database.php";
require_once "../../includes/functions.php";
requirePartner();

$partner_id = getCurrentUserId();
$points = getPartnerPoints($partner_id);
$history = getPointsHistory($partner_id);

include "../../components/header.php";
?>
<div class="container-fluid">
    <h1>Reward Points</h1>
    <div class="alert alert-info mt-4">
        <h3>Current Points: <?= number_format($points) ?></h3>
    </div>
    
    <h3 class="mt-4">Points History</h3>
    <table class="table">
        <thead>
            <tr>
                <th>Date</th>
                <th>Description</th>
                <th>Points</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($history as $item): ?>
            <tr>
                <td><?= date('d M Y', strtotime($item['created_at'])) ?></td>
                <td><?= $item['description'] ?></td>
                <td><?= $item['points'] > 0 ? '+' : '' ?><?= $item['points'] ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php include "../../components/footer.php"; ?>