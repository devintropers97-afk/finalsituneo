<?php
require_once "../../includes/init.php";
requireLogin();
$user = getCurrentUser();
$link = SITE_URL . "/?ref=" . base64_encode($user["id"]);
?>
<h1>QR Code</h1>
<p>Scan to register with your referral link</p>
<img src="https://api.qrserver.com/v1/create-qr-code/?data=<?= urlencode($link) ?>&size=300x300" alt="QR Code">