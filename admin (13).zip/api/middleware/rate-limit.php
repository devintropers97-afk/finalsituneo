<?php
function checkRateLimit($identifier) {
    global $db;
    
    $limit = 100; // requests per hour
    $count = $db->prepare("SELECT COUNT(*) FROM api_requests WHERE identifier=? AND created_at > DATE_SUB(NOW(), INTERVAL 1 HOUR)")->execute([$identifier])->fetchColumn();
    
    if($count >= $limit) {
        http_response_code(429);
        echo json_encode(['error' => 'Rate limit exceeded']);
        exit;
    }
    
    $db->prepare("INSERT INTO api_requests (identifier, created_at) VALUES (?, NOW())")->execute([$identifier]);
}
?>