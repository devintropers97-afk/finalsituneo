<?php
header("Content-Type: application/json");
require_once "../../../includes/init.php";
echo json_encode(["success"=>true,"message"=>"Order created"]);