<?php
header("Content-Type: application/json");
require_once "../../../includes/init.php";
$id = $_GET["id"];
$order = $db->fetchOne("SELECT status FROM orders WHERE id=$id");
echo json_encode(["success"=>true,"status"=>$order["status"]]);