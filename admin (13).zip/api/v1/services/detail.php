<?php
header("Content-Type: application/json");
require_once "../../../includes/init.php";
$id = $_GET["id"];
$service = $db->fetchOne("SELECT * FROM services WHERE id=$id");
echo json_encode(["success"=>true,"data"=>$service]);