<?php
header("Content-Type: application/json");
require_once "../../../includes/init.php";
$transaction_id = $_GET["transaction_id"];
$payment = $db->fetchOne("SELECT * FROM payments WHERE transaction_id='$transaction_id'");
echo json_encode(["success"=>true,"payment"=>$payment]);