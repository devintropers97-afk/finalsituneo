<?php
header("Content-Type: application/json");
require_once "../../../includes/init.php";
requireLogin();
$user = getCurrentUser();
$profile = $db->fetchOne("SELECT * FROM user_profiles WHERE user_id={$user['id']}");
echo json_encode(["success"=>true,"user"=>$user,"profile"=>$profile]);