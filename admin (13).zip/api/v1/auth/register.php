<?php
require_once "../../../config/database.php";
require_once "../../../includes/functions.php";
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);

if(createUser($data)) {
    echo json_encode(['success' => true, 'message' => 'User created']);
} else {
    echo json_encode(['error' => 'Registration failed']);
}
?>