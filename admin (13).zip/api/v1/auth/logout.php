<?php
require_once "../../../config/database.php";
require_once "../../../includes/functions.php";
header('Content-Type: application/json');

$token = $_POST['token'] ?? '';
if($token) {
    $db->prepare("DELETE FROM api_tokens WHERE token=?")->execute([$token]);
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['error' => 'Token required']);
}
?>