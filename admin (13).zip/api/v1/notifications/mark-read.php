<?php
header("Content-Type: application/json");
require_once "../../../includes/init.php";
$id = $_POST["id"];
$db->update("notifications", ["is_read"=>1], "id=$id");
echo json_encode(["success"=>true]);