<?php
header("Content-Type: application/json");
require_once "../../../includes/init.php";
$amount = $_GET["amount"];
$tier = $_GET["tier"] ?? "tier_1";
$rates = ["tier_1"=>0.3,"tier_2"=>0.4,"tier_3"=>0.5,"tier_max"=>0.55];
$commission = $amount * $rates[$tier];
echo json_encode(["success"=>true,"commission"=>$commission]);