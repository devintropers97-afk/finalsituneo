<?php
header("Content-Type: application/json");
require_once "../../../includes/init.php";
requireLogin();
$user = getCurrentUser();
$data = json_decode(file_get_contents("php://input"), true);
$db->update("users", ["name"=>$data["name"]], "id={$user['id']}");
echo json_encode(["success"=>true]);