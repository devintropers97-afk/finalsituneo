<?php
require_once "../../../config/database.php";
require_once "../../../includes/functions.php";
header('Content-Type: application/json');

$payload = ['event' => 'test', 'timestamp' => time(), 'data' => ['message' => 'Test webhook']];
echo json_encode($payload);
?>