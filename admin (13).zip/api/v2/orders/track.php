<?php
require_once "../../../config/database.php";
header('Content-Type: application/json');

$order_id = $_GET['id'] ?? 0;
$order = $db->prepare("SELECT * FROM orders WHERE id=?")->execute([$order_id])->fetch();

if($order) {
    $tracking = $db->prepare("SELECT * FROM order_tracking WHERE order_id=? ORDER BY created_at DESC")->execute([$order_id])->fetchAll();
    echo json_encode(['order' => $order, 'tracking' => $tracking]);
} else {
    http_response_code(404);
    echo json_encode(['error' => 'Order not found']);
}
?>