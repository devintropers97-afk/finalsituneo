<?php
require_once "../../../config/database.php";
require_once "../../../includes/functions.php";
header('Content-Type: application/json');

checkAuth();
$stats = getOrderStatistics();

echo json_encode($stats);
?>