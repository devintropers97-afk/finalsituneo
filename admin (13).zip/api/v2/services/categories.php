<?php
require_once "../../../config/database.php";
header('Content-Type: application/json');

$categories = $db->query("SELECT * FROM categories WHERE status='active' ORDER BY name")->fetchAll();
echo json_encode(['categories' => $categories]);
?>