<?php
require_once "../../../config/database.php";
require_once "../../../includes/functions.php";
header('Content-Type: application/json');

$refresh_token = $_POST['refresh_token'] ?? '';
if($refresh_token) {
    $new_token = refreshAccessToken($refresh_token);
    echo json_encode(['token' => $new_token]);
} else {
    http_response_code(400);
    echo json_encode(['error' => 'Refresh token required']);
}
?>