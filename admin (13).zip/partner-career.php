<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jadi Partner Situneo - Dapat Komisi hingga 30%!</title>
    <meta name="description" content="Bergabung jadi Partner Situneo dan dapatkan komisi hingga 30% dari setiap orderan yang Anda bawa. Gratis training, support 24/7, payment cepat!">
    
    <!-- Favicon -->
    <link rel="icon" type="image/png" href="https://situneo.my.id/logo">
    
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Plus+Jakarta+Sans:wght@400;600;700;800;900&display=swap" rel="stylesheet">
    
    <!-- CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    
    <style>
        :root {
            --primary-blue: #1E5C99;
            --dark-blue: #0F3057;
            --gold: #FFB400;
            --bright-gold: #FFD700;
            --white: #ffffff;
            --text-light: #e9ecef;
            --gradient-primary: linear-gradient(135deg, #1E5C99 0%, #0F3057 100%);
            --gradient-gold: linear-gradient(135deg, #FFD700 0%, #FFB400 100%);
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', sans-serif;
            background: var(--dark-blue);
            color: var(--white);
        }
        
        .hero-section {
            min-height: 100vh;
            display: flex;
            align-items: center;
            background: var(--gradient-primary);
            padding: 80px 20px;
            position: relative;
            overflow: hidden;
        }
        
        .hero-section::before {
            content: '';
            position: absolute;
            width: 600px;
            height: 600px;
            background: var(--gold);
            opacity: 0.1;
            border-radius: 50%;
            top: -300px;
            right: -300px;
        }
        
        .hero-content {
            max-width: 1200px;
            margin: 0 auto;
            text-align: center;
            position: relative;
            z-index: 2;
        }
        
        .hero-badge {
            display: inline-block;
            padding: 10px 25px;
            background: var(--gradient-gold);
            border-radius: 50px;
            font-weight: 600;
            font-size: 14px;
            color: var(--dark-blue);
            margin-bottom: 30px;
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.05); }
        }
        
        .hero-title {
            font-family: 'Plus Jakarta Sans', sans-serif;
            font-size: 3.5rem;
            font-weight: 900;
            margin-bottom: 20px;
            background: var(--gradient-gold);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .hero-subtitle {
            font-size: 1.5rem;
            margin-bottom: 40px;
            color: var(--text-light);
        }
        
        .benefits-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 30px;
            margin: 60px 0;
        }
        
        .benefit-card {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            padding: 30px;
            border-radius: 20px;
            border: 2px solid rgba(255, 180, 0, 0.3);
            text-align: center;
            transition: all 0.3s;
        }
        
        .benefit-card:hover {
            transform: translateY(-10px);
            border-color: var(--gold);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
        }
        
        .benefit-icon {
            font-size: 3rem;
            margin-bottom: 20px;
            color: var(--gold);
        }
        
        .benefit-title {
            font-size: 1.3rem;
            font-weight: 700;
            margin-bottom: 10px;
        }
        
        .benefit-desc {
            font-size: 0.95rem;
            color: var(--text-light);
        }
        
        .commission-section {
            background: rgba(15, 48, 87, 0.8);
            padding: 80px 20px;
        }
        
        .commission-container {
            max-width: 1000px;
            margin: 0 auto;
            text-align: center;
        }
        
        .commission-title {
            font-family: 'Plus Jakarta Sans', sans-serif;
            font-size: 2.5rem;
            font-weight: 800;
            margin-bottom: 20px;
        }
        
        .commission-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 30px;
            margin-top: 50px;
        }
        
        .commission-card {
            background: var(--gradient-primary);
            padding: 40px 30px;
            border-radius: 20px;
            border: 2px solid var(--gold);
            position: relative;
            overflow: hidden;
        }
        
        .commission-card.featured {
            transform: scale(1.05);
            border-width: 3px;
            box-shadow: 0 20px 60px rgba(255, 180, 0, 0.3);
        }
        
        .commission-card .badge {
            position: absolute;
            top: 15px;
            right: 15px;
            background: var(--gradient-gold);
            color: var(--dark-blue);
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 700;
        }
        
        .commission-percentage {
            font-size: 3.5rem;
            font-weight: 900;
            color: var(--gold);
            margin-bottom: 10px;
        }
        
        .commission-level {
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 20px;
        }
        
        .commission-requirements {
            text-align: left;
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid rgba(255, 180, 0, 0.3);
        }
        
        .commission-requirements li {
            padding: 8px 0;
            color: var(--text-light);
        }
        
        .process-section {
            padding: 80px 20px;
            background: var(--gradient-primary);
        }
        
        .process-container {
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .process-title {
            font-family: 'Plus Jakarta Sans', sans-serif;
            font-size: 2.5rem;
            font-weight: 800;
            text-align: center;
            margin-bottom: 60px;
        }
        
        .process-steps {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 40px;
        }
        
        .process-step {
            text-align: center;
            position: relative;
        }
        
        .step-number {
            width: 80px;
            height: 80px;
            background: var(--gradient-gold);
            color: var(--dark-blue);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
            font-weight: 900;
            margin: 0 auto 20px;
            box-shadow: 0 10px 30px rgba(255, 180, 0, 0.3);
        }
        
        .step-title {
            font-size: 1.3rem;
            font-weight: 700;
            margin-bottom: 10px;
        }
        
        .step-desc {
            color: var(--text-light);
        }
        
        .cta-section {
            background: rgba(15, 48, 87, 0.9);
            padding: 80px 20px;
            text-align: center;
        }
        
        .cta-container {
            max-width: 800px;
            margin: 0 auto;
        }
        
        .cta-title {
            font-family: 'Plus Jakarta Sans', sans-serif;
            font-size: 2.5rem;
            font-weight: 900;
            margin-bottom: 20px;
            background: var(--gradient-gold);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .cta-subtitle {
            font-size: 1.2rem;
            margin-bottom: 40px;
            color: var(--text-light);
        }
        
        .btn-primary {
            display: inline-block;
            padding: 18px 50px;
            background: var(--gradient-gold);
            color: var(--dark-blue);
            text-decoration: none;
            border-radius: 50px;
            font-size: 1.2rem;
            font-weight: 700;
            box-shadow: 0 10px 30px rgba(255, 180, 0, 0.4);
            transition: all 0.3s;
        }
        
        .btn-primary:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(255, 180, 0, 0.6);
        }
        
        .testimonial-section {
            padding: 80px 20px;
            background: var(--dark-blue);
        }
        
        .testimonial-container {
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .testimonial-title {
            font-family: 'Plus Jakarta Sans', sans-serif;
            font-size: 2.5rem;
            font-weight: 800;
            text-align: center;
            margin-bottom: 60px;
        }
        
        .testimonial-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
        }
        
        .testimonial-card {
            background: rgba(255, 255, 255, 0.05);
            padding: 30px;
            border-radius: 20px;
            border: 1px solid rgba(255, 180, 0, 0.2);
        }
        
        .testimonial-rating {
            color: var(--gold);
            margin-bottom: 15px;
        }
        
        .testimonial-text {
            font-style: italic;
            margin-bottom: 20px;
            line-height: 1.6;
        }
        
        .testimonial-author {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .author-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: var(--gradient-gold);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            color: var(--dark-blue);
        }
        
        .author-name {
            font-weight: 600;
        }
        
        .author-role {
            font-size: 0.9rem;
            color: var(--text-light);
        }
        
        @media (max-width: 768px) {
            .hero-title {
                font-size: 2rem;
            }
            
            .hero-subtitle {
                font-size: 1.1rem;
            }
            
            .commission-percentage {
                font-size: 2.5rem;
            }
        }
    </style>
</head>
<body>
    <!-- Hero Section -->
    <section class="hero-section">
        <div class="hero-content">
            <div class="hero-badge">
                <i class="bi bi-star-fill"></i> OPPORTUNITY TERBATAS
            </div>
            
            <h1 class="hero-title">
                🤝 Jadi Partner Situneo<br>
                Raih Penghasilan Tambahan!
            </h1>
            
            <p class="hero-subtitle">
                Dapat komisi hingga <strong>30%</strong> dari setiap orderan yang kamu bawa.<br>
                Kerja fleksibel, penghasilan unlimited!
            </p>
            
            <div class="benefits-grid">
                <div class="benefit-card">
                    <div class="benefit-icon">💰</div>
                    <div class="benefit-title">Komisi Besar</div>
                    <div class="benefit-desc">20-30% dari nilai project</div>
                </div>
                
                <div class="benefit-card">
                    <div class="benefit-icon">🎓</div>
                    <div class="benefit-title">Training Gratis</div>
                    <div class="benefit-desc">Materi lengkap & video tutorial</div>
                </div>
                
                <div class="benefit-card">
                    <div class="benefit-icon">⚡</div>
                    <div class="benefit-title">Payment Cepat</div>
                    <div class="benefit-desc">Transfer H+1 setelah project selesai</div>
                </div>
                
                <div class="benefit-card">
                    <div class="benefit-icon">📊</div>
                    <div class="benefit-title">Dashboard Canggih</div>
                    <div class="benefit-desc">Monitor earning & client secara realtime</div>
                </div>
                
                <div class="benefit-card">
                    <div class="benefit-icon">🛠️</div>
                    <div class="benefit-title">Support 24/7</div>
                    <div class="benefit-desc">Tim support siap bantu kapan saja</div>
                </div>
                
                <div class="benefit-card">
                    <div class="benefit-icon">🎨</div>
                    <div class="benefit-title">Marketing Kit</div>
                    <div class="benefit-desc">Banner, template, & konten siap pakai</div>
                </div>
            </div>
            
            <a href="/register.php?role=partner" class="btn-primary">
                <i class="bi bi-rocket-takeoff"></i> DAFTAR JADI PARTNER SEKARANG
            </a>
        </div>
    </section>
    
    <!-- Commission Tiers -->
    <section class="commission-section">
        <div class="commission-container">
            <h2 class="commission-title">💎 Struktur Komisi Partner</h2>
            <p class="hero-subtitle">Semakin banyak orderan, semakin besar komisi yang kamu dapat!</p>
            
            <div class="commission-cards">
                <div class="commission-card">
                    <div class="commission-percentage">20%</div>
                    <div class="commission-level">Bronze Partner</div>
                    <p>Untuk partner baru</p>
                    <ul class="commission-requirements">
                        <li>✅ 0-5 project/bulan</li>
                        <li>✅ Akses marketing kit</li>
                        <li>✅ Support email</li>
                        <li>✅ Payment H+3</li>
                    </ul>
                </div>
                
                <div class="commission-card featured">
                    <div class="badge">PALING POPULER</div>
                    <div class="commission-percentage">25%</div>
                    <div class="commission-level">Silver Partner</div>
                    <p>Partner aktif</p>
                    <ul class="commission-requirements">
                        <li>✅ 6-15 project/bulan</li>
                        <li>✅ Priority support</li>
                        <li>✅ Dedicated account manager</li>
                        <li>✅ Payment H+2</li>
                        <li>✅ Bonus reward</li>
                    </ul>
                </div>
                
                <div class="commission-card">
                    <div class="commission-percentage">30%</div>
                    <div class="commission-level">Gold Partner</div>
                    <p>Partner profesional</p>
                    <ul class="commission-requirements">
                        <li>✅ 16+ project/bulan</li>
                        <li>✅ VIP support 24/7</li>
                        <li>✅ Custom marketing materials</li>
                        <li>✅ Payment H+1</li>
                        <li>✅ Exclusive perks & rewards</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    
    <!-- How It Works -->
    <section class="process-section">
        <div class="process-container">
            <h2 class="process-title">🚀 Cara Kerja Partnership</h2>
            
            <div class="process-steps">
                <div class="process-step">
                    <div class="step-number">1</div>
                    <div class="step-title">Daftar Gratis</div>
                    <div class="step-desc">
                        Isi form pendaftaran simple (hanya 5 menit!). Langsung aktif, tidak ada biaya apapun.
                    </div>
                </div>
                
                <div class="process-step">
                    <div class="step-number">2</div>
                    <div class="step-title">Dapat Training</div>
                    <div class="step-desc">
                        Akses video tutorial, materi marketing, dan tips closing dari expert kami.
                    </div>
                </div>
                
                <div class="process-step">
                    <div class="step-number">3</div>
                    <div class="step-title">Mulai Promosi</div>
                    <div class="step-desc">
                        Promosikan layanan Situneo ke network kamu pakai marketing kit yang sudah ready.
                    </div>
                </div>
                
                <div class="process-step">
                    <div class="step-number">4</div>
                    <div class="step-title">Closing & Terima Komisi</div>
                    <div class="step-desc">
                        Setiap deal yang masuk, kamu langsung dapat komisi. Transfer cepat ke rekening!
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Testimonials -->
    <section class="testimonial-section">
        <div class="testimonial-container">
            <h2 class="testimonial-title">💬 Kata Partner Kami</h2>
            
            <div class="testimonial-grid">
                <div class="testimonial-card">
                    <div class="testimonial-rating">
                        ⭐⭐⭐⭐⭐
                    </div>
                    <p class="testimonial-text">
                        "Awalnya cuma coba-coba, eh ternyata beneran dapat komisi! Bulan pertama udah closing 3 project, dapat 4 juta lebih. Support nya responsive banget!"
                    </p>
                    <div class="testimonial-author">
                        <div class="author-avatar">AS</div>
                        <div>
                            <div class="author-name">Andi Saputra</div>
                            <div class="author-role">Partner - Jakarta</div>
                        </div>
                    </div>
                </div>
                
                <div class="testimonial-card">
                    <div class="testimonial-rating">
                        ⭐⭐⭐⭐⭐
                    </div>
                    <p class="testimonial-text">
                        "Sebagai freelancer, partnership ini ngebantu banget! Gak perlu ribet ngerjain website sendiri, cukup cariin client aja. Komisi nya gede pula!"
                    </p>
                    <div class="testimonial-author">
                        <div class="author-avatar">RS</div>
                        <div>
                            <div class="author-name">Rina Sari</div>
                            <div class="author-role">Partner - Surabaya</div>
                        </div>
                    </div>
                </div>
                
                <div class="testimonial-card">
                    <div class="testimonial-rating">
                        ⭐⭐⭐⭐⭐
                    </div>
                    <p class="testimonial-text">
                        "Dashboard nya keren, bisa pantau earning realtime. Payment juga cepet, H+1 langsung masuk. Recommended buat yang mau cari passive income!"
                    </p>
                    <div class="testimonial-author">
                        <div class="author-avatar">BH</div>
                        <div>
                            <div class="author-name">Budi Hermawan</div>
                            <div class="author-role">Partner - Bandung</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Final CTA -->
    <section class="cta-section">
        <div class="cta-container">
            <h2 class="cta-title">
                Siap Jadi Partner Situneo?
            </h2>
            <p class="cta-subtitle">
                Daftar sekarang, gratis! Mulai raih komisi dari hari pertama.<br>
                <strong>Tidak ada target, tidak ada tekanan!</strong>
            </p>
            
            <a href="/register.php?role=partner" class="btn-primary">
                <i class="bi bi-rocket-takeoff"></i> DAFTAR SEKARANG - 100% GRATIS
            </a>
            
            <p style="margin-top: 30px; color: var(--text-light);">
                Sudah punya akun? <a href="/login.php" style="color: var(--gold); font-weight: 600;">Login di sini</a>
            </p>
            
            <p style="margin-top: 20px; font-size: 0.9rem; color: var(--text-light);">
                Ada pertanyaan? WhatsApp kami: <a href="https://wa.me/6281234567890" style="color: var(--gold); font-weight: 600;">+62 812-3456-7890</a>
            </p>
        </div>
    </section>
    
    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
