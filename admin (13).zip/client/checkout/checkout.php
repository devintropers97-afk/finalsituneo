<?php
require_once "../../includes/init.php";
requireLogin();
?>
<h1>Checkout</h1>
<form method="post">
<button type="submit">Place Order</button>
</form>