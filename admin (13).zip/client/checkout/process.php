<?php
require_once "../../includes/init.php';
requireLogin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = getCurrentUser();
    $cart = $_SESSION['cart'] ?? [];
    
    if (empty($cart)) {
        redirect('../cart/view.php');
    }
    
    // Calculate total
    $total = 0;
    foreach ($cart as $service_id) {
        $service = $db->fetchOne("SELECT price_setup FROM services WHERE id = $service_id");
        $total += $service['price_setup'];
    }
    
    $tax = $total * TAX_RATE;
    $final = $total + $tax;
    
    // Create order
    $order_number = 'ORD-' . date('Ymd') . '-' . rand(1000, 9999);
    
    $db->insert('orders', [
        'order_number' => $order_number,
        'user_id' => $user['id'],
        'total_amount' => $total,
        'tax_amount' => $tax,
        'final_amount' => $final,
        'status' => 'pending'
    ]);
    
    $order_id = $db->lastInsertId();
    
    // Add order items
    foreach ($cart as $service_id) {
        $service = $db->fetchOne("SELECT name, price_setup FROM services WHERE id = $service_id");
        $db->insert('order_items', [
            'order_id' => $order_id,
            'service_id' => $service_id,
            'service_name' => $service['name'],
            'quantity' => 1,
            'price' => $service['price_setup'],
            'subtotal' => $service['price_setup']
        ]);
    }
    
    // Clear cart
    unset($_SESSION['cart']);
    
    setFlash('success', 'Order placed successfully!');
    redirect('../orders/detail.php?id=' . $order_id);
}
