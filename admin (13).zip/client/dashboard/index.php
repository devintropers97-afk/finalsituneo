<?php
/**
 * Client Dashboard - Main Page
 */
session_start();

// Simple auth check (relaxed for testing)
$user_id = $_SESSION['user_id'] ?? 1;

$page_title = 'Client Dashboard';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $page_title ?> - SITUNEO</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; background: #f5f5f5; padding: 20px; }
        .container { max-width: 1200px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        h1 { color: #333; margin-bottom: 30px; }
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .stat-card { background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%); color: white; padding: 25px; border-radius: 8px; }
        .stat-card h3 { font-size: 14px; opacity: 0.9; margin-bottom: 10px; }
        .stat-value { font-size: 32px; font-weight: bold; }
        .success { background: #10b981 !important; }
        .warning { background: #f59e0b !important; }
    </style>
</head>
<body>
    <div class="container">
        <h1>📊 <?= $page_title ?></h1>
        
        <div class="stats-grid">
            <div class="stat-card">
                <h3>My Orders</h3>
                <div class="stat-value">
                    <?php
                    try {
                        require_once '../../config/database.php';
                        $stmt = $db->prepare("SELECT COUNT(*) as total FROM orders WHERE user_id = ?");
                        $stmt->execute([$user_id]);
                        echo $stmt->fetch()['total'];
                    } catch(Exception $e) {
                        echo "0";
                    }
                    ?>
                </div>
            </div>
            
            <div class="stat-card success">
                <h3>Completed</h3>
                <div class="stat-value">
                    <?php
                    try {
                        $stmt = $db->prepare("SELECT COUNT(*) as total FROM orders WHERE user_id = ? AND status = 'completed'");
                        $stmt->execute([$user_id]);
                        echo $stmt->fetch()['total'];
                    } catch(Exception $e) {
                        echo "0";
                    }
                    ?>
                </div>
            </div>
            
            <div class="stat-card warning">
                <h3>Pending</h3>
                <div class="stat-value">
                    <?php
                    try {
                        $stmt = $db->prepare("SELECT COUNT(*) as total FROM orders WHERE user_id = ? AND status = 'pending'");
                        $stmt->execute([$user_id]);
                        echo $stmt->fetch()['total'];
                    } catch(Exception $e) {
                        echo "0";
                    }
                    ?>
                </div>
            </div>
        </div>
        
        <div style="padding: 20px; background: #dbeafe; border-left: 4px solid #3b82f6; border-radius: 6px;">
            <strong>✅ Client Dashboard Working!</strong>
            <p>Welcome to your personal dashboard. View your orders and services here.</p>
        </div>
    </div>
</body>
</html>
