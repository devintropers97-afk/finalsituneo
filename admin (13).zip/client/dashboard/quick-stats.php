<?php
require_once "../../includes/init.php";
requireLogin();
$user = getCurrentUser();
echo json_encode([
"total_orders" => $db->fetchOne("SELECT COUNT(*) as c FROM orders WHERE user_id={$user['id']}")["c"],
"total_spent" => $db->fetchOne("SELECT SUM(final_amount) as t FROM orders WHERE user_id={$user['id']}")["t"]
]);