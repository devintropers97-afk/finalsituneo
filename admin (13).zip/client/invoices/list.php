<?php
require_once "../../config/database.php";
require_once "../../includes/functions.php";
requireLogin();

$user_id = getCurrentUserId();
$invoices = $db->prepare("SELECT * FROM invoices WHERE user_id=? ORDER BY created_at DESC")->execute([$user_id])->fetchAll();

include "../../components/header.php";
?>
<div class="container-fluid">
    <h1>My Invoices</h1>
    <table class="table mt-4">
        <thead>
            <tr><th>Invoice#</th><th>Date</th><th>Amount</th><th>Status</th><th>Actions</th></tr>
        </thead>
        <tbody>
            <?php foreach($invoices as $inv): ?>
            <tr>
                <td>#<?= $inv['id'] ?></td>
                <td><?= date('d M Y', strtotime($inv['created_at'])) ?></td>
                <td>Rp <?= number_format($inv['amount'], 0, ',', '.') ?></td>
                <td><?= $inv['status'] ?></td>
                <td>
                    <a href="view.php?id=<?= $inv['id'] ?>">View</a>
                    <a href="download.php?id=<?= $inv['id'] ?>">Download</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php include "../../components/footer.php"; ?>