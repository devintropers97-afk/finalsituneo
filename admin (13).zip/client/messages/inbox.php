<?php
require_once "../../config/database.php";
require_once "../../includes/functions.php";
requireLogin();

$user_id = getCurrentUserId();
$messages = $db->prepare("SELECT * FROM messages WHERE recipient_id=? ORDER BY created_at DESC")->execute([$user_id])->fetchAll();

include "../../components/header.php";
?>
<div class="container-fluid">
    <h1>Inbox</h1>
    <table class="table mt-4">
        <thead>
            <tr><th>From</th><th>Subject</th><th>Date</th><th>Actions</th></tr>
        </thead>
        <tbody>
            <?php foreach($messages as $msg): ?>
            <tr class="<?= $msg['read'] ? '' : 'font-weight-bold' ?>">
                <td><?= $msg['sender_name'] ?></td>
                <td><?= $msg['subject'] ?></td>
                <td><?= date('d M Y', strtotime($msg['created_at'])) ?></td>
                <td><a href="view.php?id=<?= $msg['id'] ?>">Read</a></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php include "../../components/footer.php"; ?>