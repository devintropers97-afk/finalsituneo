<?php
require_once "../../includes/init.php';
requireLogin();

$user = getCurrentUser();
$service_id = (int)$_GET['service'];

if ($service_id > 0) {
    // Check if already in wishlist
    $existing = $db->fetchOne("SELECT id FROM wishlist WHERE user_id = {$user['id']} AND service_id = $service_id");
    
    if (!$existing) {
        $db->insert('wishlist', [
            'user_id' => $user['id'],
            'service_id' => $service_id
        ]);
        setFlash('success', 'Service added to wishlist!');
    } else {
        setFlash('info', 'Service already in your wishlist!');
    }
} else {
    setFlash('error', 'Invalid service!');
}

redirect('view.php');
?>