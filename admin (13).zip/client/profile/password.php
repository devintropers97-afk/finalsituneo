<?php
require_once "../../includes/init.php';
requireLogin();

$user = getCurrentUser();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $current = $_POST['current_password'];
    $new = $_POST['new_password'];
    $confirm = $_POST['confirm_password'];
    
    $user_data = $db->fetchOne("SELECT password FROM users WHERE id = {$user['id']}");
    
    if (password_verify($current, $user_data['password'])) {
        if ($new === $confirm) {
            $new_hash = password_hash($new, PASSWORD_BCRYPT);
            $db->update('users', ['password' => $new_hash], "id = {$user['id']}");
            setFlash('success', 'Password changed successfully');
        } else {
            setFlash('error', 'Passwords do not match');
        }
    } else {
        setFlash('error', 'Current password is incorrect');
    }
}
?>
<!DOCTYPE html>
<html>
<head><title>Change Password</title></head>
<body class="bg-dark text-white">
    <div class="container mt-4">
        <h1>Change Password</h1>
        <form method="post" class="mt-4" style="max-width: 500px;">
            <div class="mb-3">
                <label>Current Password</label>
                <input type="password" name="current_password" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>New Password</label>
                <input type="password" name="new_password" class="form-control" required minlength="8">
            </div>
            <div class="mb-3">
                <label>Confirm New Password</label>
                <input type="password" name="confirm_password" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">Change Password</button>
        </form>
    </div>
</body>
</html>
