<?php
require_once "../../includes/init.php";
requireLogin();
$user = getCurrentUser();
?>
<h1>Edit Profile</h1>
<form method="post">
<input name="name" value="<?= $user['name'] ?>">
<input name="email" value="<?= $user['email'] ?>">
<input name="phone" placeholder="Phone">
<button type="submit">Update</button>
</form>