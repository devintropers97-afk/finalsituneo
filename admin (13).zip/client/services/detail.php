<?php
require_once "../../includes/init.php";
$id = $_GET["id"];
$service = $db->fetchOne("SELECT * FROM services WHERE id=$id");
?>
<h1><?= $service['name'] ?></h1>
<p><?= $service['description'] ?></p>
<p>Price: <?= formatRupiah($service['price_setup']) ?></p>
<a href="../cart/add.php?service=<?= $id ?>">Add to Cart</a>