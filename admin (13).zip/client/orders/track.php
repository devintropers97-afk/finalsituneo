<?php
require_once "../../config/database.php";
require_once "../../includes/functions.php";
requireLogin();

$order_id = $_GET['id'] ?? 0;
$order = getOrderDetails($order_id);
$tracking = getOrderTracking($order_id);

include "../../components/header.php";
?>
<div class="container-fluid">
    <h1>Track Order #<?= $order_id ?></h1>
    <div class="card mt-4">
        <div class="card-body">
            <h5><?= $order['service_name'] ?></h5>
            <p>Status: <strong><?= $order['status'] ?></strong></p>
            
            <div class="tracking-timeline mt-4">
                <?php foreach($tracking as $item): ?>
                <div class="tracking-item">
                    <strong><?= $item['status'] ?></strong>
                    <p><?= $item['notes'] ?></p>
                    <small><?= date('d M Y H:i', strtotime($item['created_at'])) ?></small>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>
<?php include "../../components/footer.php"; ?>