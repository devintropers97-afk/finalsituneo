<?php
require_once "../../includes/init.php';
requireLogin();

$user = getCurrentUser();
$order_id = $_GET['id'];

// Verify ownership
$order = $db->fetchOne("SELECT * FROM orders WHERE id = $order_id AND user_id = {$user['id']}");

if ($order && $order['status'] === 'pending') {
    $db->update('orders', ['status' => 'cancelled'], "id = $order_id");
    setFlash('success', 'Order cancelled');
}

redirect('list.php');
