<?php
require_once "../../includes/init.php";
requireLogin();
$user = getCurrentUser();
$orders = $db->fetchAll("SELECT * FROM orders WHERE user_id={$user['id']}");
?>
<h1>My Orders</h1>
<?php foreach($orders as $o): ?>
<div><p>Order: <?= $o['order_number'] ?></p><p>Status: <?= $o['status'] ?></p></div>
<?php endforeach; ?>