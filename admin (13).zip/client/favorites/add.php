<?php
require_once "../../includes/init.php";
requireLogin();
$user = getCurrentUser();
$service_id = $_GET["service"];
$db->insert("favorites", ["user_id"=>$user["id"], "service_id"=>$service_id]);
redirect("list.php");