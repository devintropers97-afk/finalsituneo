<?php
require_once "../../includes/init.php";
requireLogin();
$user = getCurrentUser();
$favorites = $db->fetchAll("SELECT s.* FROM favorites f JOIN services s ON f.service_id=s.id WHERE f.user_id={$user['id']}");
?>
<h1>My Favorites</h1>
<?php foreach($favorites as $fav): ?>
<div class="card bg-dark mb-3"><div class="card-body">
<h5><?= $fav["name"] ?></h5>
<p><?= formatRupiah($fav["price_setup"]) ?></p>
</div></div>
<?php endforeach; ?>