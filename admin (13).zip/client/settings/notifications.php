<?php
require_once "../../includes/init.php";
requireLogin();
?>
<h1>Notification Settings</h1>
<form method="post">
<label><input type="checkbox" name="email_notifications" checked> Email Notifications</label><br>
<label><input type="checkbox" name="sms_notifications"> SMS Notifications</label><br>
<button type="submit" class="btn btn-primary mt-3">Save</button>
</form>