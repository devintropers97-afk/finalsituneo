<?php
require_once "../../includes/init.php';
requireLogin();

unset($_SESSION['cart']);
redirect('view.php');
