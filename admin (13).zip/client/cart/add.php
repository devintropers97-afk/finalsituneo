<?php
require_once "../../includes/init.php";
requireLogin();
$service_id = $_GET["service"];
// Add to session cart
$_SESSION["cart"][] = $service_id;
redirect("view.php");
?>