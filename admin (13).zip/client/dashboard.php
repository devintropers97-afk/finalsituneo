<?php
require_once "../includes/init.php';
requireLogin();

$user = getCurrentUser();
$my_orders = $db->fetchAll("SELECT * FROM orders WHERE user_id = {$user['id']} ORDER BY created_at DESC LIMIT 5");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Client Dashboard - SITUNEO</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #0F3057; color: white; font-family: 'Inter', sans-serif; }
        .card { background: rgba(15, 48, 87, 0.6); border: 1px solid rgba(255, 255, 255, 0.1); }
    </style>
</head>
<body>
    <div class="container mt-4">
        <h1>Welcome, <?= htmlspecialchars($user['name']) ?>!</h1>
        <div class="row mt-4">
            <div class="col-md-12">
                <div class="card p-4">
                    <h3>My Recent Orders</h3>
                    <?php if (empty($my_orders)): ?>
                        <p>No orders yet. <a href="../pages/services.php">Browse Services</a></p>
                    <?php else: ?>
                        <table class="table table-dark">
                            <thead>
                                <tr>
                                    <th>Order #</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($my_orders as $order): ?>
                                <tr>
                                    <td><?= $order['order_number'] ?></td>
                                    <td><?= formatRupiah($order['final_amount']) ?></td>
                                    <td><?= $order['status'] ?></td>
                                    <td><?= formatDate($order['created_at']) ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
