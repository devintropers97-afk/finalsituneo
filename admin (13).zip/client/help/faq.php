<?php
require_once "../../includes/init.php";
requireLogin();
?>
<h1>Frequently Asked Questions</h1>
<div class="accordion">
<div class="accordion-item bg-dark text-white">
<h2 class="accordion-header"><button class="accordion-button">How to place an order?</button></h2>
<div class="accordion-collapse"><p>Browse services, add to cart, and checkout!</p></div>
</div>
</div>