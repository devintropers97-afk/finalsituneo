# API Documentation

## Endpoints

### Authentication
- POST /api/v1/auth/login
- POST /api/v1/auth/register