# Installation Guide

1. Upload files
2. Import database
3. Configure settings