<?php
/**
 * URL Helper Functions
 * Fungsi-fungsi bantuan untuk URL
 */

function currentUrl() {
    $protocol = isset($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] === "on" ? "https" : "http";
    return $protocol . "://" . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"];
}

function baseUrl($path = "") {
    return SITE_URL . "/" . ltrim($path, "/");
}

function assetUrl($path) {
    return SITE_URL . "/assets/" . ltrim($path, "/");
}

function redirectTo($url) {
    header("Location: $url");
    exit;
}

function isCurrentUrl($url) {
    return strpos(currentUrl(), $url) !== false;
}

function buildQuery($params) {
    return http_build_query($params);
}

function parseUrl($url) {
    return parse_url($url);
}
?>