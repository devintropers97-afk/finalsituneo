<?php
/**
 * Currency Helper Functions
 * Fungsi-fungsi bantuan untuk konversi mata uang
 */

function convertCurrency($amount, $from = "IDR", $to = "USD") {
    $rates = [
        "IDR" => 1,
        "USD" => 15800,
        "EUR" => 17200,
        "SGD" => 11700,
        "MYR" => 3450,
        "JPY" => 145,
        "CNY" => 2200
    ];
    
    if($from === $to) return $amount;
    $idr = ($from === "IDR") ? $amount : $amount * $rates[$from];
    return ($to === "IDR") ? $idr : $idr / $rates[$to];
}

function formatCurrency($amount, $currency = "IDR") {
    $symbols = [
        "IDR" => "Rp",
        "USD" => "$",
        "EUR" => "€",
        "SGD" => "S$",
        "MYR" => "RM",
        "JPY" => "¥",
        "CNY" => "¥"
    ];
    
    $symbol = $symbols[$currency] ?? $currency;
    
    if($currency === "IDR") {
        return $symbol . " " . number_format($amount, 0, ",", ".");
    }
    return $symbol . " " . number_format($amount, 2, ".", ",");
}

function getCurrencySymbol($currency) {
    $symbols = ["IDR"=>"Rp","USD"=>"$","EUR"=>"€","SGD"=>"S$","MYR"=>"RM"];
    return $symbols[$currency] ?? $currency;
}
?>