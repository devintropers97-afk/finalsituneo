<?php
/**
 * Date Helper Functions
 * Fungsi-fungsi bantuan untuk format tanggal Indonesia
 */

function formatDateIndonesian($date) {
    $months = ["Januari","Februari","Maret","April","Mei","Juni",
                "Juli","Agustus","September","Oktober","November","Desember"];
    $timestamp = strtotime($date);
    return date("d", $timestamp) . " " . $months[date("n", $timestamp)-1] . " " . date("Y", $timestamp);
}

function formatDateTime($datetime) {
    return date("d M Y H:i", strtotime($datetime));
}

function timeAgo($datetime) {
    $diff = time() - strtotime($datetime);
    if($diff < 60) return "$diff detik lalu";
    if($diff < 3600) return floor($diff/60) . " menit lalu";
    if($diff < 86400) return floor($diff/3600) . " jam lalu";
    if($diff < 604800) return floor($diff/86400) . " hari lalu";
    return date("d M Y", strtotime($datetime));
}

function isToday($date) {
    return date("Y-m-d", strtotime($date)) === date("Y-m-d");
}

function getDayName($date) {
    $days = ["Minggu","Senin","Selasa","Rabu","Kamis","Jumat","Sabtu"];
    return $days[date("w", strtotime($date))];
}

function getDateRange($start, $end) {
    $dates = [];
    $current = strtotime($start);
    $end_time = strtotime($end);
    while($current <= $end_time) {
        $dates[] = date("Y-m-d", $current);
        $current = strtotime("+1 day", $current);
    }
    return $dates;
}
?>