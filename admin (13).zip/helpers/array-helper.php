<?php
/**
 * Array Helper Functions
 * Fungsi-fungsi bantuan untuk manipulasi array
 */

function arrayGet($array, $key, $default = null) {
    return isset($array[$key]) ? $array[$key] : $default;
}

function arrayFirst($array) {
    return reset($array);
}

function arrayLast($array) {
    return end($array);
}

function arrayPluck($array, $key) {
    return array_column($array, $key);
}

function arrayOnly($array, $keys) {
    return array_intersect_key($array, array_flip($keys));
}

function arrayExcept($array, $keys) {
    return array_diff_key($array, array_flip($keys));
}

function arrayWhere($array, $callback) {
    return array_filter($array, $callback);
}

function arrayMap($array, $callback) {
    return array_map($callback, $array);
}

function arrayFlatten($array) {
    $result = [];
    array_walk_recursive($array, function($value) use (&$result) {
        $result[] = $value;
    });
    return $result;
}
?>