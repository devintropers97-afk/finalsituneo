<?php
/**
 * String Helper Functions
 * Fungsi-fungsi bantuan untuk manipulasi string
 */

function slugify($text) {
    $text = strtolower($text);
    $text = preg_replace("/[^a-z0-9]+/", "-", $text);
    return trim($text, "-");
}

function truncate($text, $length = 100, $suffix = "...") {
    if(strlen($text) <= $length) return $text;
    return substr($text, 0, $length) . $suffix;
}

function generateRandomString($length = 10) {
    return bin2hex(random_bytes($length / 2));
}

function sanitizeFilename($filename) {
    return preg_replace("/[^a-zA-Z0-9_.-]/", "", $filename);
}

function excerpt($text, $length = 150) {
    return truncate(strip_tags($text), $length);
}

function strLimit($text, $limit = 100) {
    return truncate($text, $limit);
}

function strContains($haystack, $needle) {
    return strpos($haystack, $needle) !== false;
}

function strStartsWith($haystack, $needle) {
    return substr($haystack, 0, strlen($needle)) === $needle;
}

function strEndsWith($haystack, $needle) {
    return substr($haystack, -strlen($needle)) === $needle;
}
?>