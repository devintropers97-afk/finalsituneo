<?php
session_start();
require_once "./config/database.php";
require_once "./includes/functions.php";

logActivity(getCurrentUserId(), 'User logged out');

session_destroy();
setcookie('remember_token', '', time() - 3600, '/');

redirectTo('/login.php?msg=logged_out');
?>