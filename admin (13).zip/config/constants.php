<?php
/**
 * Site Constants
 */

define('SITE_NAME', 'SITUNEO');
define('SITE_URL', 'https://situneo.my.id');
define('ADMIN_EMAIL', 'admin@situneo.my.id');
define('COMPANY_PHONE', '6283173868915');
define('TIMEZONE', 'Asia/Jakarta');
date_default_timezone_set(TIMEZONE);

define('ROOT_PATH', __DIR__ . '/..');
define('UPLOAD_PATH', ROOT_PATH . '/uploads');
define('CACHE_PATH', ROOT_PATH . '/cache');
define('LOG_PATH', ROOT_PATH . '/logs');

define('MAX_UPLOAD_SIZE', 10485760);
define('ALLOWED_EXTENSIONS', 'jpg,jpeg,png,gif,pdf,doc,docx,xls,xlsx');

define('ENCRYPTION_KEY', 'ddae1754f8f447736113b118668ec97981bb9f070fd18309b4b7ba3123f59643');
define('SESSION_TIMEOUT', 7200);
?>