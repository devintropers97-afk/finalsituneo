<?php
/**
 * Session Configuration
 */

ini_set('session.cookie_lifetime', 7200); // 2 hours
ini_set('session.gc_maxlifetime', 7200);
ini_set('session.cookie_secure', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Lax');

define('SESSION_NAME', 'SITUNEO_SESSION');
define('SESSION_TIMEOUT', 7200);
?>