<?php
/**
 * Queue Configuration
 * For background job processing
 */

// Queue Driver: database, redis, sync
define('QUEUE_DRIVER', 'database');

// Default Queue Name
define('QUEUE_DEFAULT', 'default');

// Queue Connection
define('QUEUE_CONNECTION', [
    'database' => [
        'table' => 'jobs',
        'queue' => 'default',
        'expire' => 60
    ],
    'redis' => [
        'host' => '127.0.0.1',
        'port' => 6379,
        'database' => 0
    ]
]);

// Max Attempts
define('QUEUE_MAX_ATTEMPTS', 3);

// Retry After (seconds)
define('QUEUE_RETRY_AFTER', 90);
