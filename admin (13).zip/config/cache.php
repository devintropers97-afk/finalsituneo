<?php
/**
 * Cache Configuration
 */

define('CACHE_DRIVER', 'file');
define('CACHE_PATH', "../cache/');
define('CACHE_PREFIX', 'situneo_');
define('CACHE_DEFAULT_TTL', 3600); // 1 hour
?>