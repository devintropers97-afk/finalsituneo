<?php
/**
 * Logging Configuration
 */

define('LOG_LEVEL', 'debug'); // debug, info, warning, error
define('LOG_PATH', "../logs/');
define('LOG_MAX_FILES', 30);
define('LOG_CHANNEL', 'situneo');
?>