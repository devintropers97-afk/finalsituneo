<?php
require_once "../../config/database.php";
require_once "../../includes/functions.php";
requireAdmin();

$revenue_data = getRevenueAnalytics();

include "../../components/header.php";
?>
<div class="container-fluid">
    <h1>Revenue Analytics</h1>
    <?php include '../../components/widgets/revenue-widget.php'; ?>
</div>
<?php include "../../components/footer.php"; ?>