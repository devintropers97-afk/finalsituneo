<?php
require_once "../../config/database.php";
require_once "../../includes/functions.php";
requireAdmin();

$analytics = getAnalyticsOverview();

include "../../components/header.php";
?>
<div class="container-fluid">
    <h1>Analytics Overview</h1>
    <div class="row mt-4">
        <div class="col-md-3"><?php include '../../components/widgets/stats-widget.php'; ?></div>
        <div class="col-md-3"><?php include '../../components/widgets/stats-widget.php'; ?></div>
        <div class="col-md-3"><?php include '../../components/widgets/stats-widget.php'; ?></div>
        <div class="col-md-3"><?php include '../../components/widgets/stats-widget.php'; ?></div>
    </div>
    <div class="row mt-4">
        <div class="col-md-12">
            <canvas id="analyticsChart"></canvas>
        </div>
    </div>
</div>
<?php include "../../components/footer.php"; ?>