<?php
require_once "../../config/database.php";
require_once "../../includes/functions.php";
requireAdmin();

$user_analytics = getUserAnalytics();

include "../../components/header.php";
?>
<div class="container-fluid">
    <h1>User Analytics</h1>
    <div class="row mt-4">
        <div class="col-md-6">
            <canvas id="userGrowthChart"></canvas>
        </div>
        <div class="col-md-6">
            <canvas id="userTypeChart"></canvas>
        </div>
    </div>
</div>
<?php include "../../components/footer.php"; ?>