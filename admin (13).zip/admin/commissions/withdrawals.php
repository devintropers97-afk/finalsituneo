<?php
require_once "../../includes/init.php";
requireAdmin();
$withdrawals = $db->fetchAll("SELECT w.*, u.name FROM withdrawal_requests w JOIN users u ON w.partner_id = u.id");
?>
<h1>Withdrawal Requests</h1>
<table><tr><th>Partner</th><th>Amount</th><th>Status</th><th>Action</th></tr>
<?php foreach($withdrawals as $w): ?>
<tr><td><?= $w['name'] ?></td><td><?= formatRupiah($w['amount']) ?></td><td><?= $w['status'] ?></td><td><button>Approve</button></td></tr>
<?php endforeach; ?>
</table>