<?php
require_once "../../includes/init.php';
requireAdmin();

if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $db->update('commissions', ['status' => 'paid', 'paid_at' => date('Y-m-d H:i:s')], "id = $id");
    setFlash('success', 'Commission marked as paid');
    redirect('list.php');
}
