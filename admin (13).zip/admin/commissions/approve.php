<?php
require_once "../../config/database.php";
require_once "../../includes/functions.php";
requireAdmin();
if(isset($_GET['id'])) {
    $db->prepare("UPDATE commissions SET status='approved' WHERE id=?")->execute([$_GET['id']]);
    $_SESSION['message'] = 'Commission approved';
}
redirectTo('/list.php');
?>