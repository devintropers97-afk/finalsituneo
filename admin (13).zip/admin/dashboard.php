<?php
require_once "../includes/init.php';
requireAdmin();

// Get statistics
$total_users = $db->fetchOne("SELECT COUNT(*) as count FROM users")['count'];
$total_orders = $db->fetchOne("SELECT COUNT(*) as count FROM orders")['count'];
$total_revenue = $db->fetchOne("SELECT SUM(final_amount) as total FROM orders WHERE status='completed'")['total'] ?? 0;
$pending_orders = $db->fetchOne("SELECT COUNT(*) as count FROM orders WHERE status='pending'")['count'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - SITUNEO DIGITAL</title>
    <link rel="icon" href="<?= SITE_LOGO_URL ?>">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Plus+Jakarta+Sans:wght@400;600;700;800;900&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        :root {
            --primary-blue: #1E5C99;
            --dark-blue: #0F3057;
            --gold: #FFB400;
            --bright-gold: #FFD700;
        }
        body {
            font-family: 'Inter', sans-serif;
            background: var(--dark-blue);
            color: white;
        }
        .stats-card {
            background: rgba(15, 48, 87, 0.6);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 25px;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        .stats-value {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 5px;
        }
    </style>
</head>
<body>
    <?php include "../components/admin-sidebar.php'; ?>
    <div class="main-content" style="margin-left: 250px; padding: 20px;">
        <h1 class="mb-4">Dashboard Admin</h1>
        
        <div class="row">
            <div class="col-md-3">
                <div class="stats-card">
                    <div class="stats-value"><?= $total_users ?></div>
                    <div>Total Users</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <div class="stats-value"><?= $total_orders ?></div>
                    <div>Total Orders</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <div class="stats-value"><?= formatRupiah($total_revenue) ?></div>
                    <div>Total Revenue</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <div class="stats-value"><?= $pending_orders ?></div>
                    <div>Pending Orders</div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
