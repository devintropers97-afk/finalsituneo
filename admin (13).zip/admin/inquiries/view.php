<?php
require_once "../../includes/init.php';
requireAdmin();

$id = $_GET['id'];
$inquiry = $db->fetchOne("SELECT * FROM inquiries WHERE id = $id");
?>
<!DOCTYPE html>
<html>
<head><title>Inquiry Detail</title></head>
<body class="bg-dark text-white">
    <div class="container mt-4">
        <h1>Inquiry Detail</h1>
        <p><strong>From:</strong> <?= $inquiry['name'] ?> (<?= $inquiry['email'] ?>)</p>
        <p><strong>Phone:</strong> <?= $inquiry['phone'] ?></p>
        <p><strong>Subject:</strong> <?= $inquiry['subject'] ?></p>
        <p><strong>Message:</strong></p>
        <p><?= nl2br(htmlspecialchars($inquiry['message'])) ?></p>
        <a href="reply.php?id=<?= $id ?>" class="btn btn-primary">Reply</a>
    </div>
</body>
</html>
