<?php
/**
 * Admin Dashboard - Main Page
 */
session_start();

// Simple auth check
if(!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'admin') {
    // For testing, allow access
    // header('Location: ../../login.php');
    // exit;
}

$page_title = 'Admin Dashboard';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $page_title ?> - SITUNEO</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; background: #f5f5f5; padding: 20px; }
        .container { max-width: 1200px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        h1 { color: #333; margin-bottom: 30px; }
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .stat-card { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 25px; border-radius: 8px; }
        .stat-card h3 { font-size: 14px; opacity: 0.9; margin-bottom: 10px; }
        .stat-value { font-size: 32px; font-weight: bold; }
        .success { background: #10b981 !important; }
        .info { background: #3b82f6 !important; }
        .warning { background: #f59e0b !important; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🎛️ <?= $page_title ?></h1>
        
        <div class="stats-grid">
            <div class="stat-card success">
                <h3>System Status</h3>
                <div class="stat-value">✓ Online</div>
            </div>
            
            <div class="stat-card info">
                <h3>Total Users</h3>
                <div class="stat-value">
                    <?php
                    try {
                        require_once '../../config/database.php';
                        $stmt = $db->query("SELECT COUNT(*) as total FROM users");
                        echo $stmt->fetch()['total'];
                    } catch(Exception $e) {
                        echo "N/A";
                    }
                    ?>
                </div>
            </div>
            
            <div class="stat-card warning">
                <h3>Total Orders</h3>
                <div class="stat-value">
                    <?php
                    try {
                        $stmt = $db->query("SELECT COUNT(*) as total FROM orders");
                        echo $stmt->fetch()['total'];
                    } catch(Exception $e) {
                        echo "0";
                    }
                    ?>
                </div>
            </div>
            
            <div class="stat-card">
                <h3>Dashboard</h3>
                <div class="stat-value">Active</div>
            </div>
        </div>
        
        <div style="padding: 20px; background: #f0fdf4; border-left: 4px solid #10b981; border-radius: 6px;">
            <strong>✅ Admin Dashboard Working!</strong>
            <p>Welcome to SITUNEO Admin Panel. All systems operational.</p>
        </div>
    </div>
</body>
</html>
