<?php
require_once "../../includes/init.php';
requireAdmin();

$today_orders = $db->fetchOne("SELECT COUNT(*) as count FROM orders WHERE DATE(created_at) = CURDATE()")['count'];
$month_revenue = $db->fetchOne("SELECT SUM(final_amount) as total FROM orders WHERE MONTH(created_at) = MONTH(CURDATE())")['total'] ?? 0;

echo json_encode([
    'today_orders' => $today_orders,
    'month_revenue' => $month_revenue
]);
