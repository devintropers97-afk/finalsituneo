<?php
require_once "../../config/database.php";
require_once "../../includes/functions.php";
requireAdmin();
$file = $_GET['file'] ?? '';
$path = "../../database/backups/' . basename($file);
if(file_exists($path)) {
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . basename($file) . '"');
    readfile($path);
    exit;
}
?>