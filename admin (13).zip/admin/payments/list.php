<?php
require_once "../../includes/init.php";
requireAdmin();
$payments = $db->fetchAll("SELECT * FROM payments ORDER BY created_at DESC");
?>
<h1>Payments</h1>
<table><tr><th>Order ID</th><th>Amount</th><th>Method</th><th>Status</th></tr>
<?php foreach($payments as $p): ?>
<tr><td><?= $p['order_id'] ?></td><td><?= formatRupiah($p['amount']) ?></td><td><?= $p['payment_method'] ?></td><td><?= $p['status'] ?></td></tr>
<?php endforeach; ?>
</table>