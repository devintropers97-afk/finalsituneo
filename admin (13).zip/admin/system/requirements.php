<?php
require_once "../../config/database.php";
require_once "../../includes/functions.php";
requireAdmin();
$requirements = [
    'PHP >= 7.4' => version_compare(PHP_VERSION, '7.4.0', '>='),
    'MySQL' => extension_loaded('pdo_mysql'),
    'cURL' => extension_loaded('curl'),
    'GD' => extension_loaded('gd'),
    'mbstring' => extension_loaded('mbstring')
];
include "../../components/header.php";
?>
<div class="container-fluid">
    <h1>System Requirements</h1>
    <table class="table mt-4">
        <?php foreach($requirements as $req => $status): ?>
        <tr>
            <td><?= $req ?></td>
            <td><?= $status ? '<span class="badge badge-success">OK</span>' : '<span class="badge badge-danger">FAIL</span>' ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
</div>
<?php include "../../components/footer.php"; ?>