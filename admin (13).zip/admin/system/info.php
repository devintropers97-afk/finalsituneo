<?php
require_once "../../config/database.php";
require_once "../../includes/functions.php";
requireAdmin();
$info = [
    'php_version' => phpversion(),
    'server' => $_SERVER['SERVER_SOFTWARE'],
    'database' => DB_NAME,
    'version' => '1.0.0'
];
include "../../components/header.php";
?>
<div class="container-fluid">
    <h1>System Information</h1>
    <table class="table mt-4">
        <?php foreach($info as $key => $value): ?>
        <tr><th><?= ucfirst(str_replace('_', ' ', $key)) ?></th><td><?= $value ?></td></tr>
        <?php endforeach; ?>
    </table>
</div>
<?php include "../../components/footer.php"; ?>