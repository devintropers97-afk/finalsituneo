<?php
require_once "../../includes/init.php";
requireAdmin();
$id = $_GET["id"];
$service = $db->fetchOne("SELECT * FROM services WHERE id=$id");
?>
<h1>Edit Service</h1>
<form method="post">
<input name="name" value="<?= $service['name'] ?>">
<textarea name="description"><?= $service['description'] ?></textarea>
<button type="submit">Update</button>
</form>