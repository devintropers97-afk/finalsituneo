<?php
require_once "../../config/database.php";
require_once "../../includes/functions.php";
requireAdmin();
if(isset($_GET['id'])) {
    $db->prepare("DELETE FROM services WHERE id=?")->execute([$_GET['id']]);
    $_SESSION['message'] = 'Service deleted';
}
redirectTo('/list.php');
?>