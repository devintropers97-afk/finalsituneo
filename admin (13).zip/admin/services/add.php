<?php
require_once "../../includes/init.php";
requireAdmin();
?>
<h1>Add Service</h1>
<form method="post">
<input name="name" placeholder="Service Name" required>
<textarea name="description" placeholder="Description"></textarea>
<input name="price_setup" type="number" placeholder="Setup Price">
<input name="price_monthly" type="number" placeholder="Monthly Price">
<button type="submit">Add Service</button>
</form>