<?php
require_once "../../includes/init.php";
requireAdmin();
?>
<h1>Security Settings</h1>
<form method="post">
<div class="mb-3">
<label>Force HTTPS</label>
<input type="checkbox" name="force_https">
</div>
<div class="mb-3">
<label>Enable 2FA for Admin</label>
<input type="checkbox" name="admin_2fa">
</div>
<button type="submit" class="btn btn-primary">Save</button>
</form>