<?php
require_once "../../includes/init.php';
requireAdmin();
?>
<!DOCTYPE html>
<html>
<head><title>Commission Settings</title></head>
<body class="bg-dark text-white">
    <div class="container mt-4">
        <h1>Commission Tier Settings</h1>
        <form method="post">
            <h4>Tier 1 (Bronze)</h4>
            <div class="row">
                <div class="col-md-4">
                    <label>Min Orders</label>
                    <input type="number" name="tier1_min" class="form-control" value="0">
                </div>
                <div class="col-md-4">
                    <label>Max Orders</label>
                    <input type="number" name="tier1_max" class="form-control" value="9">
                </div>
                <div class="col-md-4">
                    <label>Rate (%)</label>
                    <input type="number" name="tier1_rate" class="form-control" value="30" step="0.1">
                </div>
            </div>
            
            <h4 class="mt-4">Tier 2 (Silver)</h4>
            <div class="row">
                <div class="col-md-4">
                    <label>Min Orders</label>
                    <input type="number" name="tier2_min" class="form-control" value="10">
                </div>
                <div class="col-md-4">
                    <label>Max Orders</label>
                    <input type="number" name="tier2_max" class="form-control" value="24">
                </div>
                <div class="col-md-4">
                    <label>Rate (%)</label>
                    <input type="number" name="tier2_rate" class="form-control" value="40" step="0.1">
                </div>
            </div>
            
            <button type="submit" class="btn btn-primary mt-4">Save Settings</button>
        </form>
    </div>
</body>
</html>
