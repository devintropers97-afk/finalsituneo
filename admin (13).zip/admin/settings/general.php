<?php
require_once "../../config/database.php";
require_once "../../includes/functions.php";
requireAdmin();

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    updateSettings($_POST);
    $_SESSION['message'] = 'Settings updated';
}

$settings = getSettings();
include "../../components/header.php";
?>
<div class="container-fluid">
    <h1>General Settings</h1>
    <form method="POST" class="mt-4">
        <div class="form-group">
            <label>Site Name:</label>
            <input type="text" name="site_name" class="form-control" value="<?= $settings['site_name'] ?>">
        </div>
        <div class="form-group">
            <label>Admin Email:</label>
            <input type="email" name="admin_email" class="form-control" value="<?= $settings['admin_email'] ?>">
        </div>
        <button class="btn btn-primary">Save Settings</button>
    </form>
</div>
<?php include "../../components/footer.php"; ?>