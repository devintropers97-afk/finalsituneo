<?php
require_once "../../config/database.php";
require_once "../../includes/functions.php";
requireAdmin();

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    generateNewAPIKey();
    $_SESSION['message'] = 'API Key generated';
}

$api_keys = getAPIKeys();
include "../../components/header.php";
?>
<div class="container-fluid">
    <h1>API Keys</h1>
    <button class="btn btn-primary mb-3" onclick="document.getElementById('genForm').submit()">Generate New Key</button>
    <form id="genForm" method="POST" style="display:none;"></form>
    <table class="table">
        <thead>
            <tr><th>Key</th><th>Created</th><th>Last Used</th><th>Actions</th></tr>
        </thead>
        <tbody>
            <?php foreach($api_keys as $key): ?>
            <tr>
                <td><?= substr($key['key'], 0, 20) ?>...</td>
                <td><?= date('d M Y', strtotime($key['created_at'])) ?></td>
                <td><?= $key['last_used'] ? date('d M Y', strtotime($key['last_used'])) : 'Never' ?></td>
                <td><a href="revoke.php?id=<?= $key['id'] ?>">Revoke</a></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php include "../../components/footer.php"; ?>