<?php
require_once "../../config/database.php";
require_once "../../includes/functions.php";
requireAdmin();
$logs = $db->query("SELECT * FROM access_logs ORDER BY created_at DESC LIMIT 100")->fetchAll();
include "../../components/header.php";
?>
<div class="container-fluid">
    <h1>Access Logs</h1>
    <table class="table mt-4">
        <thead><tr><th>Time</th><th>User</th><th>IP</th><th>Action</th></tr></thead>
        <tbody>
            <?php foreach($logs as $log): ?>
            <tr>
                <td><?= $log['created_at'] ?></td>
                <td><?= $log['user_id'] ?></td>
                <td><?= $log['ip_address'] ?></td>
                <td><?= $log['action'] ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php include "../../components/footer.php"; ?>