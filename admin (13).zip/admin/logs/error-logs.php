<?php
require_once "../../config/database.php";
require_once "../../includes/functions.php";
requireAdmin();
$logs = file("../../logs/error.log');
$logs = array_reverse($logs);
$logs = array_slice($logs, 0, 100);
include "../../components/header.php";
?>
<div class="container-fluid">
    <h1>Error Logs</h1>
    <pre class="mt-4"><?= htmlspecialchars(implode('', $logs)) ?></pre>
</div>
<?php include "../../components/footer.php"; ?>