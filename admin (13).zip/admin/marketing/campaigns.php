<?php
require_once "../../config/database.php";
require_once "../../includes/functions.php";
requireAdmin();

$campaigns = $db->query("SELECT * FROM marketing_campaigns ORDER BY created_at DESC")->fetchAll();

include "../../components/header.php";
?>
<div class="container-fluid">
    <h1>Marketing Campaigns</h1>
    <a href="create-campaign.php" class="btn btn-primary mb-3">Create Campaign</a>
    <table class="table">
        <thead>
            <tr><th>Name</th><th>Type</th><th>Status</th><th>Sent</th><th>Opened</th><th>Actions</th></tr>
        </thead>
        <tbody>
            <?php foreach($campaigns as $c): ?>
            <tr>
                <td><?= $c['name'] ?></td>
                <td><?= $c['type'] ?></td>
                <td><?= $c['status'] ?></td>
                <td><?= $c['sent_count'] ?></td>
                <td><?= $c['opened_count'] ?></td>
                <td><a href="edit.php?id=<?= $c['id'] ?>">Edit</a></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php include "../../components/footer.php"; ?>