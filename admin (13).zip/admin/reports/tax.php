<?php
require_once "../../config/database.php";
require_once "../../includes/functions.php";
requireAdmin();

$year = $_GET['year'] ?? date('Y');
$tax_data = calculateAnnualTax($year);

include "../../components/header.php";
?>
<div class="container-fluid">
    <h1>Tax Report <?= $year ?></h1>
    <div class="card mt-4">
        <div class="card-body">
            <h3>Total Revenue: Rp <?= number_format($tax_data['revenue'], 0, ',', '.') ?></h3>
            <h3>PPN 11%: Rp <?= number_format($tax_data['ppn'], 0, ',', '.') ?></h3>
            <h3>PPh: Rp <?= number_format($tax_data['pph'], 0, ',', '.') ?></h3>
        </div>
    </div>
</div>
<?php include "../../components/footer.php"; ?>