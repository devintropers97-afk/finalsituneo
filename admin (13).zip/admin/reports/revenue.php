<?php
require_once "../../includes/init.php';
requireAdmin();

$daily_revenue = $db->fetchAll("SELECT DATE(created_at) as date, SUM(final_amount) as revenue FROM orders WHERE status='completed' GROUP BY DATE(created_at) ORDER BY date DESC LIMIT 30");
?>
<!DOCTYPE html>
<html>
<head><title>Revenue Report</title></head>
<body class="bg-dark text-white">
    <div class="container mt-4">
        <h1>Revenue Report (Last 30 Days)</h1>
        <table class="table table-dark">
            <thead><tr><th>Date</th><th>Revenue</th></tr></thead>
            <tbody>
                <?php foreach ($daily_revenue as $row): ?>
                <tr>
                    <td><?= formatDate($row['date']) ?></td>
                    <td><?= formatRupiah($row['revenue']) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
