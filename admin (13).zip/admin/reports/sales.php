<?php
require_once "../../config/database.php";
require_once "../../includes/functions.php";
requireAdmin();

$period = $_GET['period'] ?? 'monthly';
$sales_data = getSalesReport($period);

include "../../components/header.php";
?>
<div class="container-fluid">
    <h1>Sales Report</h1>
    <div class="row mt-4">
        <div class="col-md-12">
            <canvas id="salesChart" height="100"></canvas>
        </div>
    </div>
    <div class="table-responsive mt-4">
        <?php include '../../components/tables/sales-table.php'; ?>
    </div>
</div>
<script>
new Chart(document.getElementById('salesChart'), {
    type: 'bar',
    data: { labels: <?= json_encode(array_column($sales_data, 'period')) ?>,
            datasets: [{ label: 'Sales', data: <?= json_encode(array_column($sales_data, 'amount')) ?> }] }
});
</script>
<?php include "../../components/footer.php"; ?>