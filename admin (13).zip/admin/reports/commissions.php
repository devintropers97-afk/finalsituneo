<?php
require_once "../../config/database.php";
require_once "../../includes/functions.php";
requireAdmin();

$commissions = $db->query("
    SELECT c.*, u.name as partner_name, o.id as order_id
    FROM commissions c
    JOIN users u ON c.partner_id = u.id
    JOIN orders o ON c.order_id = o.id
    ORDER BY c.created_at DESC
")->fetchAll();

include "../../components/header.php";
?>
<div class="container-fluid">
    <h1>Commission Report</h1>
    <table class="table mt-4">
        <thead>
            <tr><th>Date</th><th>Partner</th><th>Order</th><th>Amount</th><th>Status</th></tr>
        </thead>
        <tbody>
            <?php foreach($commissions as $c): ?>
            <tr>
                <td><?= date('d M Y', strtotime($c['created_at'])) ?></td>
                <td><?= $c['partner_name'] ?></td>
                <td>#<?= $c['order_id'] ?></td>
                <td>Rp <?= number_format($c['amount'], 0, ',', '.') ?></td>
                <td><?= $c['status'] ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php include "../../components/footer.php"; ?>