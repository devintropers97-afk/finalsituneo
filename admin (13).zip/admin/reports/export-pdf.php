<?php
require_once "../../config/database.php";
require_once "../../includes/functions.php";
require_once "../../vendor/autoload.php";
requireAdmin();

$type = $_GET['type'];
$report_data = getReportData($type);

$pdf = new TCPDF();
$pdf->AddPage();
$pdf->SetFont('helvetica', '', 12);
$html = generateReportHTML($report_data);
$pdf->writeHTML($html, true, false, true, false, '');
$pdf->Output('report_' . $type . '_' . date('Y-m-d') . '.pdf', 'D');
?>