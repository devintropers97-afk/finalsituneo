<?php
require_once "../../config/database.php";
require_once "../../includes/functions.php";
requireAdmin();

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    clearCache();
    $_SESSION['message'] = 'Cache cleared';
}

include "../../components/header.php";
?>
<div class="container-fluid">
    <h1>Clear Cache</h1>
    <form method="POST" class="mt-4">
        <p>This will clear all cached files and data.</p>
        <button class="btn btn-danger" onclick="return confirm('Are you sure?')">Clear Cache</button>
    </form>
</div>
<?php include "../../components/footer.php"; ?>