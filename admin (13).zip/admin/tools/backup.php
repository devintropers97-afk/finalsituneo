<?php
require_once "../../config/database.php";
require_once "../../includes/functions.php";
requireAdmin();

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    createBackup();
    $_SESSION['message'] = 'Backup created';
}

$backups = getBackupList();
include "../../components/header.php";
?>
<div class="container-fluid">
    <h1>Backup Management</h1>
    <form method="POST" class="mb-4">
        <button class="btn btn-primary">Create Backup Now</button>
    </form>
    <table class="table">
        <thead>
            <tr><th>Filename</th><th>Size</th><th>Date</th><th>Actions</th></tr>
        </thead>
        <tbody>
            <?php foreach($backups as $backup): ?>
            <tr>
                <td><?= $backup['filename'] ?></td>
                <td><?= formatBytes($backup['size']) ?></td>
                <td><?= date('d M Y H:i', $backup['time']) ?></td>
                <td><a href="download.php?file=<?= $backup['filename'] ?>">Download</a></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php include "../../components/footer.php"; ?>