<?php
require_once "../../config/database.php";
require_once "../../includes/functions.php";
requireAdmin();

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $mode = $_POST['mode'];
    setMaintenanceMode($mode === 'on');
    $_SESSION['message'] = 'Maintenance mode ' . $mode;
}

$is_maintenance = isMaintenanceMode();
include "../../components/header.php";
?>
<div class="container-fluid">
    <h1>Maintenance Mode</h1>
    <div class="alert alert-<?= $is_maintenance ? 'warning' : 'success' ?>">
        Status: <?= $is_maintenance ? 'ON' : 'OFF' ?>
    </div>
    <form method="POST">
        <input type="hidden" name="mode" value="<?= $is_maintenance ? 'off' : 'on' ?>">
        <button class="btn btn-<?= $is_maintenance ? 'success' : 'warning' ?>">
            Turn <?= $is_maintenance ? 'OFF' : 'ON' ?>
        </button>
    </form>
</div>
<?php include "../../components/footer.php"; ?>