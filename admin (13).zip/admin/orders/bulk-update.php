<?php
require_once "../../includes/init.php";
requireAdmin();
if($_SERVER["REQUEST_METHOD"] === "POST") {
$ids = $_POST["order_ids"];
$status = $_POST["status"];
foreach($ids as $id) $db->update("orders", ["status"=>$status], "id=$id");
setFlash("success", "Orders updated");
redirect("list.php");
}