<?php
require_once "../../config/database.php";
require_once "../../includes/functions.php";
requireAdmin();
$q = $_GET['q'] ?? '';
$users = $db->prepare("SELECT * FROM users WHERE name LIKE ? OR email LIKE ?")->execute(["%$q%", "%$q%"])->fetchAll();
include "../../components/header.php";
?>
<div class="container-fluid">
    <h1>Search Results</h1>
    <table class="table mt-4">
        <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Actions</th></tr></thead>
        <tbody>
            <?php foreach($users as $u): ?>
            <tr>
                <td><?= $u['name'] ?></td>
                <td><?= $u['email'] ?></td>
                <td><?= $u['role'] ?></td>
                <td><a href="edit.php?id=<?= $u['id'] ?>">Edit</a></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php include "../../components/footer.php"; ?>