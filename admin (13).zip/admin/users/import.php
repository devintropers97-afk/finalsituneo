<?php
require_once "../../includes/init.php";
requireAdmin();
?>
<!DOCTYPE html>
<html><head><title>Import Users</title></head>
<body class="bg-dark text-white">
<div class="container mt-4">
<h1>Import Users from CSV</h1>
<form method="post" enctype="multipart/form-data">
<input type="file" name="csv" accept=".csv" class="form-control mb-3">
<button type="submit" class="btn btn-primary">Import</button>
</form>
</div>
</body></html>