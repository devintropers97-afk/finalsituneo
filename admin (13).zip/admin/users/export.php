<?php
require_once "../../includes/init.php";
requireAdmin();
header("Content-Type: text/csv");
header("Content-Disposition: attachment; filename=users.csv");
$users = $db->fetchAll("SELECT * FROM users");
echo "ID,Name,Email,Role,Status\n";
foreach($users as $u) echo "{$u['id']},{$u['name']},{$u['email']},{$u['role']},{$u['status']}\n";