<?php
require_once "../../includes/init.php';
requireAdmin();

$activities = $db->fetchAll("SELECT a.*, u.name FROM activity_logs a LEFT JOIN users u ON a.user_id = u.id ORDER BY a.created_at DESC LIMIT 100");
?>
<!DOCTYPE html>
<html>
<head><title>Activity Logs</title></head>
<body class="bg-dark text-white">
    <div class="container mt-4">
        <h1>System Activity Logs</h1>
        <table class="table table-dark table-sm">
            <thead><tr><th>User</th><th>Action</th><th>Details</th><th>Time</th></tr></thead>
            <tbody>
                <?php foreach ($activities as $act): ?>
                <tr>
                    <td><?= $act['name'] ?? 'System' ?></td>
                    <td><?= $act['action'] ?></td>
                    <td><?= $act['details'] ?></td>
                    <td><?= formatDate($act['created_at']) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
