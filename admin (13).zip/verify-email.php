<?php
require_once 'config/database.php';
require_once 'includes/functions.php';

$token = $_GET['token'] ?? '';

if($token) {
    $user = $db->prepare("SELECT * FROM users WHERE verification_token = ?")->execute([$token])->fetch();
    
    if($user) {
        $db->prepare("UPDATE users SET email_verified = 1, verification_token = NULL WHERE id = ?")->execute([$user['id']]);
        
        $_SESSION['success'] = 'Email verified successfully! You can now login.';
        header('Location: /login.php');
        exit;
    } else {
        $_SESSION['error'] = 'Invalid verification token';
    }
} else {
    $_SESSION['error'] = 'No verification token provided';
}

header('Location: /login.php');
exit;
?>
