<?php
require_once "../config/database.php";
require_once "../includes/functions.php";

// Calculate and distribute commissions
$completed = $db->query("SELECT * FROM orders WHERE status='completed' AND commission_paid=0")->fetchAll();

foreach($completed as $order) {
    calculateCommission($order['id']);
    echo "Commission calculated for order #{$order['id']}\n";
}

logActivity('system', 'Commission calculation completed: ' . count($completed));
?>