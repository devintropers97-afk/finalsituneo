<?php
require_once "../config/database.php";
require_once "../includes/functions.php";

// Generate daily reports
$stats = [
    'orders' => $db->query("SELECT COUNT(*) FROM orders WHERE DATE(created_at) = CURDATE()")->fetchColumn(),
    'revenue' => $db->query("SELECT SUM(total_amount) FROM orders WHERE DATE(created_at) = CURDATE() AND status='completed'")->fetchColumn(),
    'new_users' => $db->query("SELECT COUNT(*) FROM users WHERE DATE(created_at) = CURDATE()")->fetchColumn()
];

sendDailyReport($stats);
echo "Daily report sent\n";
?>