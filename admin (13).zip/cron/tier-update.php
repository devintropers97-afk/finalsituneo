<?php
require_once "../config/database.php";
require_once "../includes/functions.php";

// Update partner tiers based on performance
$partners = $db->query("SELECT id, total_orders FROM users WHERE role='partner'")->fetchAll();

foreach($partners as $partner) {
    $tier = determineTier($partner['total_orders']);
    $db->prepare("UPDATE users SET tier=? WHERE id=?")->execute([$tier, $partner['id']]);
    echo "Updated partner #{$partner['id']} to tier $tier\n";
}

logActivity('system', 'Tier update cron completed');
?>