<?php
require_once "../config/database.php";
require_once "../includes/functions.php";

// Send payment reminders for pending invoices
$pending = $db->query("SELECT * FROM orders WHERE status='pending' AND created_at < DATE_SUB(NOW(), INTERVAL 3 DAY)")->fetchAll();

foreach($pending as $order) {
    sendPaymentReminder($order['id']);
    echo "Reminder sent for order #{$order['id']}\n";
}

echo "Total reminders sent: " . count($pending) . "\n";
?>