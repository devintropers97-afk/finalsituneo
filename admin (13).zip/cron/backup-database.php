<?php
require_once "../config/database.php";

$filename = 'backup_' . date('Y-m-d_H-i-s') . '.sql';
$backup_path = "../database/backups/' . $filename;

$command = "mysqldump -u " . DB_USER . " -p" . DB_PASS . " " . DB_NAME . " > " . $backup_path;
exec($command);

echo "Database backed up: $filename\n";
?>