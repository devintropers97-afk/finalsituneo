<?php include "../components/header.php"; ?>
<div class="container py-5">
    <h1>Kebijakan Privasi</h1>
    <div class="mt-4">
        <h3>1. Informasi yang Kami Kumpulkan</h3>
        <p>Kami mengumpulkan informasi yang Anda berikan saat mendaftar...</p>
        
        <h3>2. Bagaimana Kami Menggunakan Informasi</h3>
        <p>Informasi yang dikumpulkan digunakan untuk...</p>
        
        <h3>3. Keamanan Data</h3>
        <p>Kami menggunakan enkripsi dan praktik keamanan terbaik...</p>
    </div>
</div>
<?php include "../components/footer.php"; ?>