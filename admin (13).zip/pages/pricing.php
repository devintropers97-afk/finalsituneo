<?php include "../components/header.php"; ?>
<div class="container py-5">
    <h1 class="text-center">Harga & Paket</h1>
    <div class="row mt-5">
        <div class="col-md-4">
            <div class="card text-center">
                <div class="card-body">
                    <h3>Basic</h3>
                    <h2 class="my-4">Rp 350K</h2>
                    <ul class="list-unstyled">
                        <li>✓ 1 Layanan</li>
                        <li>✓ Email Support</li>
                    </ul>
                    <button class="btn btn-primary">Pilih Paket</button>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card text-center border-primary">
                <div class="card-body">
                    <h3>Pro</h3>
                    <h2 class="my-4">Rp 1.5M</h2>
                    <ul class="list-unstyled">
                        <li>✓ 5 Layanan</li>
                        <li>✓ Priority Support</li>
                    </ul>
                    <button class="btn btn-primary">Pilih Paket</button>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card text-center">
                <div class="card-body">
                    <h3>Enterprise</h3>
                    <h2 class="my-4">Custom</h2>
                    <ul class="list-unstyled">
                        <li>✓ Unlimited</li>
                        <li>✓ 24/7 Support</li>
                    </ul>
                    <button class="btn btn-primary">Hubungi Kami</button>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include "../components/footer.php"; ?>