<?php include "../components/header.php"; ?>
<div class="container py-5">
    <h1>Syarat & Ketentuan</h1>
    <div class="mt-4">
        <h3>1. Penerimaan Syarat</h3>
        <p>Dengan menggunakan layanan kami, Anda setuju dengan...</p>
        
        <h3>2. Layanan</h3>
        <p>SITUNEO menyediakan platform untuk...</p>
        
        <h3>3. Pembayaran</h3>
        <p>Semua pembayaran harus dilakukan sesuai dengan...</p>
    </div>
</div>
<?php include "../components/footer.php"; ?>