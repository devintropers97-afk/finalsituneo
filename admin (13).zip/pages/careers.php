<?php
require_once "../config/database.php";
$jobs = $db->query("SELECT * FROM job_openings WHERE status='active'")->fetchAll();
include "../components/header.php";
?>
<div class="container py-5">
    <h1>Karir di SITUNEO</h1>
    <p class="lead">Bergabunglah dengan tim kami!</p>
    <div class="row mt-4">
        <?php foreach($jobs as $job): ?>
        <div class="col-md-6 mb-4">
            <div class="card">
                <div class="card-body">
                    <h5><?= $job['title'] ?></h5>
                    <p><?= $job['department'] ?> • <?= $job['location'] ?></p>
                    <a href="/careers/apply?job=<?= $job['id'] ?>" class="btn btn-primary">Lamar Sekarang</a>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php include "../components/footer.php"; ?>