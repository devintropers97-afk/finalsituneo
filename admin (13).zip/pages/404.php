<?php include "../components/header.php"; ?>
<div class="container text-center py-5">
    <h1 class="display-1">404</h1>
    <h2>Halaman Tidak Ditemukan</h2>
    <p>Maaf, halaman yang Anda cari tidak ditemukan.</p>
    <a href="/" class="btn btn-primary">Kembali ke Beranda</a>
</div>
<?php include "../components/footer.php"; ?>