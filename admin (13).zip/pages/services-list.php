<?php
require_once "../config/database.php";
$services = $db->query("SELECT * FROM services WHERE status='active' ORDER BY name")->fetchAll();
include "../components/header.php";
?>
<div class="container py-5">
    <h1>Semua Layanan Kami</h1>
    <div class="row mt-4">
        <?php foreach($services as $service): ?>
        <div class="col-md-4 mb-4">
            <div class="card">
                <div class="card-body">
                    <h5><?= $service['name'] ?></h5>
                    <p><?= excerpt($service['description'], 100) ?></p>
                    <p class="text-primary"><strong>Rp <?= number_format($service['price'], 0, ',', '.') ?></strong></p>
                    <a href="/services/<?= $service['slug'] ?>" class="btn btn-primary">Detail</a>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php include "../components/footer.php"; ?>