<?php require_once "../includes/init.php"; ?>
<h1>Our Portfolio</h1>
<div class="row">
<div class="col-md-4"><img src="https://via.placeholder.com/300" class="img-fluid"><p>Project 1</p></div>
<div class="col-md-4"><img src="https://via.placeholder.com/300" class="img-fluid"><p>Project 2</p></div>
<div class="col-md-4"><img src="https://via.placeholder.com/300" class="img-fluid"><p>Project 3</p></div>
</div>