<?php include "../components/header.php"; ?>
<div class="container py-5">
    <h1>Price Calculator</h1>
    <div class="card mt-4">
        <div class="card-body">
            <form id="calculatorForm">
                <div class="form-group">
                    <label>Select Service:</label>
                    <select id="service" class="form-control">
                        <option value="">Choose...</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Quantity:</label>
                    <input type="number" id="quantity" class="form-control" value="1" min="1">
                </div>
                <div class="alert alert-info mt-3">
                    <h4>Estimated Price: <span id="totalPrice">Rp 0</span></h4>
                </div>
            </form>
        </div>
    </div>
</div>
<?php include "../components/footer.php"; ?>