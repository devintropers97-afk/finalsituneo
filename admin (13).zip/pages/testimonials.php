<?php
require_once "../config/database.php";
$testimonials = $db->query("SELECT * FROM testimonials WHERE status='approved' ORDER BY created_at DESC")->fetchAll();
include "../components/header.php";
?>
<div class="container py-5">
    <h1 class="text-center">Testimoni Klien</h1>
    <div class="row mt-5">
        <?php foreach($testimonials as $t): ?>
        <div class="col-md-4 mb-4">
            <div class="card">
                <div class="card-body">
                    <p>"<?= htmlspecialchars($t['message']) ?>"</p>
                    <hr>
                    <strong><?= $t['client_name'] ?></strong><br>
                    <small><?= $t['company'] ?></small>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php include "../components/footer.php"; ?>