<?php require_once "../includes/init.php"; ?>
<h1>FAQ</h1>
<div class="accordion">
<div class="accordion-item bg-dark text-white">
<h2 class="accordion-header"><button class="accordion-button bg-dark text-white">How to order?</button></h2>
<div class="accordion-collapse collapse show"><div class="accordion-body">Just browse services and add to cart!</div></div>
</div>
</div>