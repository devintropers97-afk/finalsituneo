<?php
require_once "../config/database.php";
$posts = $db->query("SELECT * FROM blog_posts ORDER BY created_at DESC LIMIT 12")->fetchAll();
include "../components/header.php";
?>
<div class="container py-5">
    <h1>Blog & Artikel</h1>
    <div class="row mt-4">
        <?php foreach($posts as $post): ?>
        <div class="col-md-4 mb-4">
            <div class="card">
                <img src="<?= $post['image'] ?>" class="card-img-top" alt="<?= $post['title'] ?>">
                <div class="card-body">
                    <h5><?= htmlspecialchars($post['title']) ?></h5>
                    <p><?= excerpt($post['content'], 100) ?></p>
                    <a href="/blog/<?= $post['slug'] ?>" class="btn btn-primary">Baca Selengkapnya</a>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php include "../components/footer.php"; ?>