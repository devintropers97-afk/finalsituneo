<?php
require_once "../includes/init.php';
$services = $db->fetchAll("SELECT s.*, c.name as category FROM services s LEFT JOIN service_categories c ON s.category_id = c.id WHERE s.status='active'");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Our Services - SITUNEO DIGITAL</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #0F3057; color: white; }
        .service-card { background: rgba(15, 48, 87, 0.6); border-radius: 15px; padding: 20px; margin-bottom: 20px; }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center mb-5">Our Services</h1>
        <div class="row">
            <?php foreach ($services as $service): ?>
            <div class="col-md-4">
                <div class="service-card">
                    <h4><?= htmlspecialchars($service['name']) ?></h4>
                    <p class="text-muted"><?= htmlspecialchars($service['category']) ?></p>
                    <p><?= htmlspecialchars(substr($service['description'], 0, 100)) ?>...</p>
                    <div class="d-flex justify-content-between align-items-center">
                        <span class="text-warning fw-bold"><?= formatRupiah($service['price_setup']) ?></span>
                        <a href="service-detail.php?id=<?= $service['id'] ?>" class="btn btn-sm btn-warning">Detail</a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</body>
</html>
