<?php include "../components/header.php"; ?>
<div class="container text-center py-5">
    <h1 class="display-1">500</h1>
    <h2>Internal Server Error</h2>
    <p>Maaf, terjadi kesalahan pada server kami.</p>
    <a href="/" class="btn btn-primary">Kembali ke Beranda</a>
</div>
<?php include "../components/footer.php"; ?>